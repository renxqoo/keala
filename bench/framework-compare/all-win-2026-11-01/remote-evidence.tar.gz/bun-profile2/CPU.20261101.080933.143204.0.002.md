# CPU Profile

| Duration | Samples | Interval | Functions |
|----------|---------|----------|----------|
| 239.9ms | 38 | 1.0ms | 69 |

**Top 10:** `matchRoute` 41.8%, `(module)` 25.1%, `anonymous` 11.1%, `defineProperty` 10.4%, `reallyExit` 1.8%, `send` 1.1%, `replace` 0.9%, `call` 0.6%, `internal:streams/operators` 0.5%, `node:fs/promises` 0.5%

## Hot Functions (Self Time)

| Self% | Self | Total% | Total | Function | Location |
|------:|-----:|-------:|------:|----------|----------|
| 41.8% | 100.4ms | 41.8% | 100.4ms | `matchRoute` | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/router/match.js` |
| 25.1% | 60.2ms | 25.1% | 60.2ms | `(module)` | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/router/trie.js:148` |
| 11.1% | 26.7ms | 50.9% | 122.3ms | `anonymous` | `[native code]` |
| 10.4% | 25.1ms | 10.4% | 25.1ms | `defineProperty` | `[native code]` |
| 1.8% | 4.4ms | 1.8% | 4.4ms | `reallyExit` | `[native code]` |
| 1.1% | 2.6ms | 1.1% | 2.6ms | `send` | `[native code]` |
| 0.9% | 2.3ms | 0.9% | 2.3ms | `replace` | `[native code]` |
| 0.6% | 1.4ms | 0.6% | 1.4ms | `call` | `[native code]` |
| 0.5% | 1.3ms | 0.5% | 1.3ms | `internal:streams/operators` | `internal:streams/operators:2` |
| 0.5% | 1.2ms | 0.5% | 1.2ms | `node:fs/promises` | `node:fs/promises:8` |
| 0.5% | 1.2ms | 0.5% | 1.2ms | `lazyModule` | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/utils/node-lazy.js` |
| 0.5% | 1.2ms | 0.5% | 1.2ms | `WriteStream` | `internal:fs/streams:238` |
| 0.5% | 1.2ms | 0.5% | 1.2ms | `uncurryThis` | `internal:primordials` |
| 0.4% | 1.0ms | 0.4% | 1.0ms | `registerDef` | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/router/router.js` |
| 0.4% | 1.0ms | 0.4% | 1.0ms | `parseListenArgs` | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/core/listen.js` |
| 0.4% | 1.0ms | 0.4% | 1.0ms | `createTarget` | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/router/trie.js` |
| 0.4% | 1.0ms | 0.4% | 1.0ms | `hideFromStack` | `internal:shared` |
| 0.4% | 1.0ms | 0.4% | 1.0ms | `Keala` | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/core/app.js:61` |
| 0.4% | 1.0ms | 0.4% | 1.0ms | `makeBitMapDescriptor` | `internal:streams/writable` |
| 0.4% | 986us | 0.4% | 986us | `methodNotAllowed` | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/core/respond.js` |
| 0.4% | 975us | 0.4% | 975us | `@lazy` | `[native code]` |
| 0.3% | 926us | 0.3% | 926us | `(anonymous)` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/_chunks/_url.mjs` |
| 0.3% | 916us | 0.3% | 916us | `serve` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/adapters/bun.mjs` |

## Call Tree (Total Time)

| Total% | Total | Self% | Self | Function | Location |
|-------:|------:|------:|-----:|----------|----------|
| 50.9% | 122.3ms | 11.1% | 26.7ms | `anonymous` | `[native code]` |
| 42.2% | 101.4ms | 0.0% | 0us | `(anonymous)` | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/adapters/bun.js:55` |
| 42.2% | 101.4ms | 0.0% | 0us | `#serve` | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/core/app.js:220` |
| 41.8% | 100.4ms | 41.8% | 100.4ms | `matchRoute` | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/router/match.js` |
| 41.8% | 100.4ms | 0.0% | 0us | `dispatchRequest` | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/core/dispatch.js:216` |
| 25.1% | 60.2ms | 25.1% | 60.2ms | `(module)` | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/router/trie.js:148` |
| 10.6% | 25.5ms | 0.0% | 0us | `(anonymous)` | `[native code]` |
| 10.6% | 25.5ms | 0.0% | 0us | `(module)` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/_chunks/_utils.mjs:6` |
| 10.6% | 25.5ms | 0.0% | 0us | `(anonymous)` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/_chunks/_utils.mjs:6` |
| 10.4% | 25.1ms | 0.0% | 0us | `(anonymous)` | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/adapters/bun.js:43` |
| 10.4% | 25.1ms | 10.4% | 25.1ms | `defineProperty` | `[native code]` |
| 8.8% | 21.1ms | 0.0% | 0us | `get WriteStream` | `node:fs:644` |
| 7.4% | 17.7ms | 0.0% | 0us | `internal:fs/streams` | `internal:fs/streams:2` |
| 6.0% | 14.5ms | 0.0% | 0us | `node:stream` | `node:stream:2` |
| 6.0% | 14.5ms | 0.0% | 0us | `internal:stream` | `internal:stream:2` |
| 4.9% | 11.9ms | 0.0% | 0us | `internal:streams/compose` | `internal:streams/compose:2` |
| 4.5% | 10.9ms | 0.0% | 0us | `internal:streams/pipeline` | `internal:streams/pipeline:2` |
| 4.4% | 10.7ms | 0.0% | 0us | `node:url` | `node:url:2` |
| 3.4% | 8.2ms | 0.0% | 0us | `internal:streams/duplex` | `internal:streams/duplex:2` |
| 1.8% | 4.4ms | 0.0% | 0us | `exit` | `[native code]` |
| 1.8% | 4.4ms | 1.8% | 4.4ms | `reallyExit` | `[native code]` |
| 1.1% | 2.6ms | 0.0% | 0us | `internal:errors` | `internal:errors:2` |
| 1.1% | 2.6ms | 0.0% | 0us | `internal:streams/destroy` | `internal:streams/destroy:2` |
| 1.1% | 2.6ms | 1.1% | 2.6ms | `send` | `[native code]` |
| 1.1% | 2.6ms | 0.0% | 0us | `(module)` | `/tmp/keala-all-win.cDctk1/epsilon/bench/framework-compare/server.mjs:128` |
| 0.9% | 2.3ms | 0.0% | 0us | `(module)` | `/tmp/keala-all-win.cDctk1/epsilon/bench/framework-compare/server.mjs:22` |
| 0.9% | 2.3ms | 0.0% | 0us | `createFileURL` | `node:url:689` |
| 0.9% | 2.3ms | 0.9% | 2.3ms | `replace` | `[native code]` |
| 0.8% | 2.1ms | 0.0% | 0us | `(module)` | `/tmp/keala-all-win.cDctk1/epsilon/bench/framework-compare/server.mjs:26` |
| 0.8% | 2.1ms | 0.0% | 0us | `routeShortcut` | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/core/registration.js:29` |
| 0.8% | 1.9ms | 0.0% | 0us | `(module)` | `/tmp/keala-all-win.cDctk1/epsilon/bench/framework-compare/server.mjs:42` |
| 0.7% | 1.8ms | 0.0% | 0us | `internal:streams/legacy` | `internal:streams/legacy:2` |
| 0.6% | 1.4ms | 0.6% | 1.4ms | `call` | `[native code]` |
| 0.6% | 1.4ms | 0.0% | 0us | `internal:primordials` | `internal:primordials:83` |
| 0.6% | 1.4ms | 0.0% | 0us | `bound call` | `[native code]` |
| 0.6% | 1.4ms | 0.0% | 0us | `makeSafe` | `internal:primordials:35` |
| 0.5% | 1.3ms | 0.5% | 1.3ms | `internal:streams/operators` | `internal:streams/operators:2` |
| 0.5% | 1.2ms | 0.5% | 1.2ms | `node:fs/promises` | `node:fs/promises:8` |
| 0.5% | 1.2ms | 0.0% | 0us | `(module)` | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/utils/node-lazy.js:20` |
| 0.5% | 1.2ms | 0.5% | 1.2ms | `lazyModule` | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/utils/node-lazy.js` |
| 0.5% | 1.2ms | 0.5% | 1.2ms | `WriteStream` | `internal:fs/streams:238` |
| 0.5% | 1.2ms | 0.0% | 0us | `internal:primordials` | `internal:primordials:54` |
| 0.5% | 1.2ms | 0.5% | 1.2ms | `uncurryThis` | `internal:primordials` |
| 0.4% | 1.1ms | 0.0% | 0us | `internal:streams/readable` | `internal:streams/readable:14` |
| 0.4% | 1.0ms | 0.4% | 1.0ms | `registerDef` | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/router/router.js` |
| 0.4% | 1.0ms | 0.4% | 1.0ms | `parseListenArgs` | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/core/listen.js` |
| 0.4% | 1.0ms | 0.0% | 0us | `listen` | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/core/app.js:251` |
| 0.4% | 1.0ms | 0.0% | 0us | `indexPattern` | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/router/router.js:85` |
| 0.4% | 1.0ms | 0.0% | 0us | `registerDef` | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/router/router.js:313` |
| 0.4% | 1.0ms | 0.0% | 0us | `bindDef` | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/router/router.js:131` |
| 0.4% | 1.0ms | 0.4% | 1.0ms | `createTarget` | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/router/trie.js` |
| 0.4% | 1.0ms | 0.4% | 1.0ms | `hideFromStack` | `internal:shared` |
| 0.4% | 1.0ms | 0.0% | 0us | `internal:validators` | `internal:validators:67` |
| 0.4% | 1.0ms | 0.0% | 0us | `(module)` | `/tmp/keala-all-win.cDctk1/epsilon/bench/framework-compare/server.mjs:24` |
| 0.4% | 1.0ms | 0.4% | 1.0ms | `Keala` | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/core/app.js:61` |
| 0.4% | 1.0ms | 0.0% | 0us | `internal:streams/writable` | `internal:streams/writable:33` |
| 0.4% | 1.0ms | 0.4% | 1.0ms | `makeBitMapDescriptor` | `internal:streams/writable` |
| 0.4% | 986us | 0.0% | 0us | `finalize` | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/core/respond.js:270` |
| 0.4% | 986us | 0.4% | 986us | `methodNotAllowed` | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/core/respond.js` |
| 0.4% | 986us | 0.0% | 0us | `finalizeGuarded` | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/core/dispatch.js:24` |
| 0.4% | 975us | 0.0% | 0us | `internal:fs/binding` | `internal:fs/binding:3` |
| 0.4% | 975us | 0.0% | 0us | `node:fs` | `node:fs:8` |
| 0.4% | 975us | 0.4% | 975us | `@lazy` | `[native code]` |
| 0.3% | 926us | 0.0% | 0us | `(module)` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/_chunks/_url.mjs:185` |
| 0.3% | 926us | 0.3% | 926us | `(anonymous)` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/_chunks/_url.mjs` |
| 0.3% | 916us | 0.0% | 0us | `startBunServer` | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/adapters/bun.js:222` |
| 0.3% | 916us | 0.3% | 916us | `serve` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/adapters/bun.mjs` |
| 0.3% | 916us | 0.0% | 0us | `(anonymous)` | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/adapters/bun.js:26` |
| 0.3% | 916us | 0.0% | 0us | `listen` | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/core/app.js:253` |

## Function Details

### `matchRoute`
`/tmp/keala-all-win.cDctk1/epsilon/before/dist/router/match.js` | Self: 41.8% (100.4ms) | Total: 41.8% (100.4ms) | Samples: 1

**Called by:**
- `dispatchRequest` (1)

### `(module)`
`/tmp/keala-all-win.cDctk1/epsilon/before/dist/router/trie.js:148` | Self: 25.1% (60.2ms) | Total: 25.1% (60.2ms) | Samples: 1

### `anonymous`
`[native code]` | Self: 11.1% (26.7ms) | Total: 50.9% (122.3ms) | Samples: 16

**Called by:**
- `get WriteStream` (18)
- `internal:fs/streams` (16)
- `internal:stream` (13)
- `node:stream` (13)
- `internal:streams/compose` (11)
- `internal:streams/pipeline` (10)
- `internal:streams/duplex` (8)
- `(anonymous)` (3)
- `node:url` (2)
- `internal:streams/destroy` (2)
- `internal:errors` (2)
- `internal:streams/legacy` (2)
- `internal:streams/readable` (1)
- `node:fs` (1)

**Calls:**
- `internal:fs/streams` (16)
- `internal:stream` (13)
- `node:stream` (13)
- `internal:streams/compose` (11)
- `internal:streams/pipeline` (10)
- `internal:streams/duplex` (8)
- `internal:streams/destroy` (2)
- `internal:errors` (2)
- `internal:streams/legacy` (2)
- `internal:fs/binding` (1)
- `internal:validators` (1)
- `node:fs/promises` (1)
- `internal:streams/writable` (1)
- `internal:streams/operators` (1)
- `node:fs` (1)
- `internal:streams/readable` (1)
- `internal:primordials` (1)
- `internal:primordials` (1)

### `defineProperty`
`[native code]` | Self: 10.4% (25.1ms) | Total: 10.4% (25.1ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `reallyExit`
`[native code]` | Self: 1.8% (4.4ms) | Total: 1.8% (4.4ms) | Samples: 1

**Called by:**
- `exit` (1)

### `send`
`[native code]` | Self: 1.1% (2.6ms) | Total: 1.1% (2.6ms) | Samples: 1

**Called by:**
- `(module)` (1)

### `replace`
`[native code]` | Self: 0.9% (2.3ms) | Total: 0.9% (2.3ms) | Samples: 1

**Called by:**
- `createFileURL` (1)

### `call`
`[native code]` | Self: 0.6% (1.4ms) | Total: 0.6% (1.4ms) | Samples: 1

**Called by:**
- `bound call` (1)

### `internal:streams/operators`
`internal:streams/operators:2` | Self: 0.5% (1.3ms) | Total: 0.5% (1.3ms) | Samples: 1

**Called by:**
- `anonymous` (1)

### `node:fs/promises`
`node:fs/promises:8` | Self: 0.5% (1.2ms) | Total: 0.5% (1.2ms) | Samples: 1

**Called by:**
- `anonymous` (1)

### `lazyModule`
`/tmp/keala-all-win.cDctk1/epsilon/before/dist/utils/node-lazy.js` | Self: 0.5% (1.2ms) | Total: 0.5% (1.2ms) | Samples: 1

**Called by:**
- `(module)` (1)

### `WriteStream`
`internal:fs/streams:238` | Self: 0.5% (1.2ms) | Total: 0.5% (1.2ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `uncurryThis`
`internal:primordials` | Self: 0.5% (1.2ms) | Total: 0.5% (1.2ms) | Samples: 1

**Called by:**
- `internal:primordials` (1)

### `registerDef`
`/tmp/keala-all-win.cDctk1/epsilon/before/dist/router/router.js` | Self: 0.4% (1.0ms) | Total: 0.4% (1.0ms) | Samples: 1

**Called by:**
- `routeShortcut` (1)

### `parseListenArgs`
`/tmp/keala-all-win.cDctk1/epsilon/before/dist/core/listen.js` | Self: 0.4% (1.0ms) | Total: 0.4% (1.0ms) | Samples: 1

**Called by:**
- `listen` (1)

### `createTarget`
`/tmp/keala-all-win.cDctk1/epsilon/before/dist/router/trie.js` | Self: 0.4% (1.0ms) | Total: 0.4% (1.0ms) | Samples: 1

**Called by:**
- `indexPattern` (1)

### `hideFromStack`
`internal:shared` | Self: 0.4% (1.0ms) | Total: 0.4% (1.0ms) | Samples: 1

**Called by:**
- `internal:validators` (1)

### `Keala`
`/tmp/keala-all-win.cDctk1/epsilon/before/dist/core/app.js:61` | Self: 0.4% (1.0ms) | Total: 0.4% (1.0ms) | Samples: 1

**Called by:**
- `(module)` (1)

### `makeBitMapDescriptor`
`internal:streams/writable` | Self: 0.4% (1.0ms) | Total: 0.4% (1.0ms) | Samples: 1

**Called by:**
- `internal:streams/writable` (1)

### `methodNotAllowed`
`/tmp/keala-all-win.cDctk1/epsilon/before/dist/core/respond.js` | Self: 0.4% (986us) | Total: 0.4% (986us) | Samples: 1

**Called by:**
- `finalize` (1)

### `@lazy`
`[native code]` | Self: 0.4% (975us) | Total: 0.4% (975us) | Samples: 1

**Called by:**
- `internal:fs/binding` (1)

### `(anonymous)`
`/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/_chunks/_url.mjs` | Self: 0.3% (926us) | Total: 0.3% (926us) | Samples: 1

**Called by:**
- `(module)` (1)

### `serve`
`/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/adapters/bun.mjs` | Self: 0.3% (916us) | Total: 0.3% (916us) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `#serve`
`/tmp/keala-all-win.cDctk1/epsilon/before/dist/core/app.js:220` | Self: 0.0% (0us) | Total: 42.2% (101.4ms) | Samples: 0

**Called by:**
- `(anonymous)` (2)

**Calls:**
- `finalizeGuarded` (1)
- `dispatchRequest` (1)

### `(module)`
`/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/_chunks/_url.mjs:185` | Self: 0.0% (0us) | Total: 0.3% (926us) | Samples: 0

**Calls:**
- `(anonymous)` (1)

### `(module)`
`/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/_chunks/_utils.mjs:6` | Self: 0.0% (0us) | Total: 10.6% (25.5ms) | Samples: 0

**Calls:**
- `(anonymous)` (22)

### `(anonymous)`
`/tmp/keala-all-win.cDctk1/epsilon/before/dist/adapters/bun.js:55` | Self: 0.0% (0us) | Total: 42.2% (101.4ms) | Samples: 0

**Calls:**
- `#serve` (2)

### `internal:streams/destroy`
`internal:streams/destroy:2` | Self: 0.0% (0us) | Total: 1.1% (2.6ms) | Samples: 0

**Called by:**
- `anonymous` (2)

**Calls:**
- `anonymous` (2)

### `internal:streams/pipeline`
`internal:streams/pipeline:2` | Self: 0.0% (0us) | Total: 4.5% (10.9ms) | Samples: 0

**Called by:**
- `anonymous` (10)

**Calls:**
- `anonymous` (10)

### `registerDef`
`/tmp/keala-all-win.cDctk1/epsilon/before/dist/router/router.js:313` | Self: 0.0% (0us) | Total: 0.4% (1.0ms) | Samples: 0

**Called by:**
- `routeShortcut` (1)

**Calls:**
- `bindDef` (1)

### `(anonymous)`
`[native code]` | Self: 0.0% (0us) | Total: 10.6% (25.5ms) | Samples: 0

**Called by:**
- `(anonymous)` (22)

**Calls:**
- `get WriteStream` (18)
- `anonymous` (3)
- `WriteStream` (1)

### `internal:primordials`
`internal:primordials:54` | Self: 0.0% (0us) | Total: 0.5% (1.2ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `uncurryThis` (1)

### `(module)`
`/tmp/keala-all-win.cDctk1/epsilon/bench/framework-compare/server.mjs:42` | Self: 0.0% (0us) | Total: 0.8% (1.9ms) | Samples: 0

**Calls:**
- `listen` (1)
- `listen` (1)

### `startBunServer`
`/tmp/keala-all-win.cDctk1/epsilon/before/dist/adapters/bun.js:222` | Self: 0.0% (0us) | Total: 0.3% (916us) | Samples: 0

**Called by:**
- `listen` (1)

**Calls:**
- `(anonymous)` (1)

### `indexPattern`
`/tmp/keala-all-win.cDctk1/epsilon/before/dist/router/router.js:85` | Self: 0.0% (0us) | Total: 0.4% (1.0ms) | Samples: 0

**Called by:**
- `bindDef` (1)

**Calls:**
- `createTarget` (1)

### `get WriteStream`
`node:fs:644` | Self: 0.0% (0us) | Total: 8.8% (21.1ms) | Samples: 0

**Called by:**
- `(anonymous)` (18)

**Calls:**
- `anonymous` (18)

### `(module)`
`/tmp/keala-all-win.cDctk1/epsilon/bench/framework-compare/server.mjs:26` | Self: 0.0% (0us) | Total: 0.8% (2.1ms) | Samples: 0

**Calls:**
- `routeShortcut` (2)

### `internal:streams/writable`
`internal:streams/writable:33` | Self: 0.0% (0us) | Total: 0.4% (1.0ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `makeBitMapDescriptor` (1)

### `routeShortcut`
`/tmp/keala-all-win.cDctk1/epsilon/before/dist/core/registration.js:29` | Self: 0.0% (0us) | Total: 0.8% (2.1ms) | Samples: 0

**Called by:**
- `(module)` (2)

**Calls:**
- `registerDef` (1)
- `registerDef` (1)

### `(module)`
`/tmp/keala-all-win.cDctk1/epsilon/bench/framework-compare/server.mjs:128` | Self: 0.0% (0us) | Total: 1.1% (2.6ms) | Samples: 0

**Calls:**
- `send` (1)

### `(module)`
`/tmp/keala-all-win.cDctk1/epsilon/before/dist/utils/node-lazy.js:20` | Self: 0.0% (0us) | Total: 0.5% (1.2ms) | Samples: 0

**Calls:**
- `lazyModule` (1)

### `(anonymous)`
`/tmp/keala-all-win.cDctk1/epsilon/before/dist/adapters/bun.js:43` | Self: 0.0% (0us) | Total: 10.4% (25.1ms) | Samples: 0

**Calls:**
- `defineProperty` (1)

### `internal:streams/duplex`
`internal:streams/duplex:2` | Self: 0.0% (0us) | Total: 3.4% (8.2ms) | Samples: 0

**Called by:**
- `anonymous` (8)

**Calls:**
- `anonymous` (8)

### `node:url`
`node:url:2` | Self: 0.0% (0us) | Total: 4.4% (10.7ms) | Samples: 0

**Calls:**
- `anonymous` (2)

### `internal:fs/streams`
`internal:fs/streams:2` | Self: 0.0% (0us) | Total: 7.4% (17.7ms) | Samples: 0

**Called by:**
- `anonymous` (16)

**Calls:**
- `anonymous` (16)

### `finalize`
`/tmp/keala-all-win.cDctk1/epsilon/before/dist/core/respond.js:270` | Self: 0.0% (0us) | Total: 0.4% (986us) | Samples: 0

**Called by:**
- `finalizeGuarded` (1)

**Calls:**
- `methodNotAllowed` (1)

### `makeSafe`
`internal:primordials:35` | Self: 0.0% (0us) | Total: 0.6% (1.4ms) | Samples: 0

**Called by:**
- `internal:primordials` (1)

**Calls:**
- `bound call` (1)

### `internal:errors`
`internal:errors:2` | Self: 0.0% (0us) | Total: 1.1% (2.6ms) | Samples: 0

**Called by:**
- `anonymous` (2)

**Calls:**
- `anonymous` (2)

### `internal:streams/readable`
`internal:streams/readable:14` | Self: 0.0% (0us) | Total: 0.4% (1.1ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `anonymous` (1)

### `finalizeGuarded`
`/tmp/keala-all-win.cDctk1/epsilon/before/dist/core/dispatch.js:24` | Self: 0.0% (0us) | Total: 0.4% (986us) | Samples: 0

**Called by:**
- `#serve` (1)

**Calls:**
- `finalize` (1)

### `internal:streams/compose`
`internal:streams/compose:2` | Self: 0.0% (0us) | Total: 4.9% (11.9ms) | Samples: 0

**Called by:**
- `anonymous` (11)

**Calls:**
- `anonymous` (11)

### `node:stream`
`node:stream:2` | Self: 0.0% (0us) | Total: 6.0% (14.5ms) | Samples: 0

**Called by:**
- `anonymous` (13)

**Calls:**
- `anonymous` (13)

### `exit`
`[native code]` | Self: 0.0% (0us) | Total: 1.8% (4.4ms) | Samples: 0

**Calls:**
- `reallyExit` (1)

### `internal:stream`
`internal:stream:2` | Self: 0.0% (0us) | Total: 6.0% (14.5ms) | Samples: 0

**Called by:**
- `anonymous` (13)

**Calls:**
- `anonymous` (13)

### `node:fs`
`node:fs:8` | Self: 0.0% (0us) | Total: 0.4% (975us) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `anonymous` (1)

### `bindDef`
`/tmp/keala-all-win.cDctk1/epsilon/before/dist/router/router.js:131` | Self: 0.0% (0us) | Total: 0.4% (1.0ms) | Samples: 0

**Called by:**
- `registerDef` (1)

**Calls:**
- `indexPattern` (1)

### `internal:streams/legacy`
`internal:streams/legacy:2` | Self: 0.0% (0us) | Total: 0.7% (1.8ms) | Samples: 0

**Called by:**
- `anonymous` (2)

**Calls:**
- `anonymous` (2)

### `createFileURL`
`node:url:689` | Self: 0.0% (0us) | Total: 0.9% (2.3ms) | Samples: 0

**Called by:**
- `(module)` (1)

**Calls:**
- `replace` (1)

### `internal:validators`
`internal:validators:67` | Self: 0.0% (0us) | Total: 0.4% (1.0ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `hideFromStack` (1)

### `internal:fs/binding`
`internal:fs/binding:3` | Self: 0.0% (0us) | Total: 0.4% (975us) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `@lazy` (1)

### `listen`
`/tmp/keala-all-win.cDctk1/epsilon/before/dist/core/app.js:251` | Self: 0.0% (0us) | Total: 0.4% (1.0ms) | Samples: 0

**Called by:**
- `(module)` (1)

**Calls:**
- `parseListenArgs` (1)

### `dispatchRequest`
`/tmp/keala-all-win.cDctk1/epsilon/before/dist/core/dispatch.js:216` | Self: 0.0% (0us) | Total: 41.8% (100.4ms) | Samples: 0

**Called by:**
- `#serve` (1)

**Calls:**
- `matchRoute` (1)

### `(module)`
`/tmp/keala-all-win.cDctk1/epsilon/bench/framework-compare/server.mjs:24` | Self: 0.0% (0us) | Total: 0.4% (1.0ms) | Samples: 0

**Calls:**
- `Keala` (1)

### `(anonymous)`
`/tmp/keala-all-win.cDctk1/epsilon/before/dist/adapters/bun.js:26` | Self: 0.0% (0us) | Total: 0.3% (916us) | Samples: 0

**Called by:**
- `startBunServer` (1)

**Calls:**
- `serve` (1)

### `listen`
`/tmp/keala-all-win.cDctk1/epsilon/before/dist/core/app.js:253` | Self: 0.0% (0us) | Total: 0.3% (916us) | Samples: 0

**Called by:**
- `(module)` (1)

**Calls:**
- `startBunServer` (1)

### `(anonymous)`
`/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/_chunks/_utils.mjs:6` | Self: 0.0% (0us) | Total: 10.6% (25.5ms) | Samples: 0

**Called by:**
- `(module)` (22)

**Calls:**
- `(anonymous)` (22)

### `(module)`
`/tmp/keala-all-win.cDctk1/epsilon/bench/framework-compare/server.mjs:22` | Self: 0.0% (0us) | Total: 0.9% (2.3ms) | Samples: 0

**Calls:**
- `createFileURL` (1)

### `internal:primordials`
`internal:primordials:83` | Self: 0.0% (0us) | Total: 0.6% (1.4ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `makeSafe` (1)

### `bound call`
`[native code]` | Self: 0.0% (0us) | Total: 0.6% (1.4ms) | Samples: 0

**Called by:**
- `makeSafe` (1)

**Calls:**
- `call` (1)

## Files

| Self% | Self | File |
|------:|-----:|------|
| 41.8% | 100.4ms | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/router/match.js` |
| 26.6% | 63.8ms | `[native code]` |
| 25.5% | 61.3ms | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/router/trie.js` |
| 0.5% | 1.3ms | `internal:streams/operators` |
| 0.5% | 1.2ms | `node:fs/promises` |
| 0.5% | 1.2ms | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/utils/node-lazy.js` |
| 0.5% | 1.2ms | `internal:fs/streams` |
| 0.5% | 1.2ms | `internal:primordials` |
| 0.4% | 1.0ms | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/router/router.js` |
| 0.4% | 1.0ms | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/core/listen.js` |
| 0.4% | 1.0ms | `internal:shared` |
| 0.4% | 1.0ms | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/core/app.js` |
| 0.4% | 1.0ms | `internal:streams/writable` |
| 0.4% | 986us | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/core/respond.js` |
| 0.3% | 926us | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/_chunks/_url.mjs` |
| 0.3% | 916us | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/adapters/bun.mjs` |
