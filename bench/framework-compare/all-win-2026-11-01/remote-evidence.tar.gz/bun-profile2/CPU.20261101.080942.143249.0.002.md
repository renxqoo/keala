# CPU Profile

| Duration | Samples | Interval | Functions |
|----------|---------|----------|----------|
| 4.12s | 434 | 1.0ms | 108 |

**Top 10:** `sourceUrl` 22.0%, `(anonymous)` 18.2%, `Response` 17.4%, `(anonymous)` 7.2%, `(anonymous)` 5.8%, `sourceMethod` 2.9%, `primeRequestUrl` 2.7%, `primeRequestUrl` 2.7%, `primeRequestUrl` 2.2%, `settleNativeHandle` 1.4%

## Hot Functions (Self Time)

| Self% | Self | Total% | Total | Function | Location |
|------:|-----:|-------:|------:|----------|----------|
| 22.0% | 911.4ms | 22.0% | 911.4ms | `sourceUrl` | `/tmp/keala-all-win.cDctk1/epsilon/dist/core/request-source.js:11` |
| 18.2% | 753.5ms | 18.3% | 757.7ms | `(anonymous)` | `/tmp/keala-all-win.cDctk1/epsilon/dist/adapters/bun.js:43` |
| 17.4% | 718.9ms | 17.4% | 718.9ms | `Response` | `[native code]` |
| 7.2% | 299.1ms | 7.2% | 299.1ms | `(anonymous)` | `/tmp/keala-all-win.cDctk1/epsilon/dist/adapters/bun.js:48` |
| 5.8% | 243.2ms | 5.8% | 243.2ms | `(anonymous)` | `/tmp/keala-all-win.cDctk1/epsilon/dist/adapters/bun.js:44` |
| 2.9% | 120.9ms | 2.9% | 120.9ms | `sourceMethod` | `/tmp/keala-all-win.cDctk1/epsilon/dist/core/request-source.js:10` |
| 2.7% | 113.0ms | 2.7% | 113.0ms | `primeRequestUrl` | `/tmp/keala-all-win.cDctk1/epsilon/dist/core/request-url.js:14` |
| 2.7% | 112.0ms | 2.7% | 112.0ms | `primeRequestUrl` | `/tmp/keala-all-win.cDctk1/epsilon/dist/core/request-url.js:6` |
| 2.2% | 92.9ms | 2.2% | 92.9ms | `primeRequestUrl` | `/tmp/keala-all-win.cDctk1/epsilon/dist/core/request-url.js:5` |
| 1.4% | 59.4ms | 1.4% | 59.4ms | `settleNativeHandle` | `/tmp/keala-all-win.cDctk1/epsilon/dist/core/dispatch.js:47` |
| 1.3% | 55.9ms | 17.4% | 721.2ms | `textResponse` | `/tmp/keala-all-win.cDctk1/epsilon/dist/core/context/sugar.js:38` |
| 1.3% | 55.6ms | 1.9% | 80.2ms | `finishDirect` | `/tmp/keala-all-win.cDctk1/epsilon/dist/core/dispatch.js:159` |
| 1.3% | 54.9ms | 1.3% | 54.9ms | `BoundContext` | `/tmp/keala-all-win.cDctk1/epsilon/dist/core/context/context.js:166` |
| 1.1% | 47.4ms | 1.1% | 47.4ms | `matchRoute` | `/tmp/keala-all-win.cDctk1/epsilon/dist/router/match.js` |
| 1.1% | 46.6ms | 66.0% | 2.72s | `(anonymous)` | `/tmp/keala-all-win.cDctk1/epsilon/dist/adapters/bun.js:55` |
| 1.0% | 42.7ms | 59.8% | 2.47s | `#serve` | `/tmp/keala-all-win.cDctk1/epsilon/dist/core/app.js:224` |
| 1.0% | 42.5ms | 1.0% | 42.5ms | `finishDirect` | `/tmp/keala-all-win.cDctk1/epsilon/dist/core/dispatch.js` |
| 1.0% | 41.7ms | 1.0% | 41.7ms | `[keala.handleRequestSource]` | `/tmp/keala-all-win.cDctk1/epsilon/dist/core/app.js` |
| 0.9% | 37.2ms | 0.9% | 37.2ms | `dispatchRequest` | `/tmp/keala-all-win.cDctk1/epsilon/dist/core/dispatch.js:224` |
| 0.8% | 33.3ms | 19.2% | 793.4ms | `dispatchDirect` | `/tmp/keala-all-win.cDctk1/epsilon/dist/core/dispatch.js:171` |
| 0.6% | 27.3ms | 2.8% | 115.5ms | `anonymous` | `[native code]` |
| 0.6% | 25.9ms | 3.7% | 155.3ms | `dispatchDirect` | `/tmp/keala-all-win.cDctk1/epsilon/dist/core/dispatch.js:174` |
| 0.5% | 24.5ms | 0.5% | 24.5ms | `isEmptyStatus` | `/tmp/keala-all-win.cDctk1/epsilon/dist/http/status.js` |
| 0.5% | 22.8ms | 0.5% | 22.8ms | `#serve` | `/tmp/keala-all-win.cDctk1/epsilon/dist/core/app.js:217` |
| 0.4% | 18.1ms | 0.4% | 18.1ms | `fetch` | `/tmp/keala-all-win.cDctk1/epsilon/dist/adapters/bun.js` |
| 0.4% | 17.2ms | 0.4% | 17.2ms | `primeRequestUrl` | `/tmp/keala-all-win.cDctk1/epsilon/dist/core/request-url.js:13` |
| 0.2% | 9.5ms | 1.4% | 59.2ms | `dispatchRequest` | `/tmp/keala-all-win.cDctk1/epsilon/dist/core/dispatch.js:214` |
| 0.2% | 9.0ms | 0.2% | 9.0ms | `clearStagedInPlace` | `/tmp/keala-all-win.cDctk1/epsilon/dist/core/context/sugar.js:118` |
| 0.2% | 8.9ms | 0.2% | 8.9ms | `primeRequestUrl` | `/tmp/keala-all-win.cDctk1/epsilon/dist/core/request-url.js` |
| 0.2% | 8.6ms | 0.2% | 8.6ms | `publishMatch` | `/tmp/keala-all-win.cDctk1/epsilon/dist/core/dispatch.js:195` |
| 0.1% | 7.8ms | 0.1% | 7.8ms | `dispatchDirect` | `/tmp/keala-all-win.cDctk1/epsilon/dist/core/dispatch.js:172` |
| 0.1% | 7.5ms | 0.1% | 7.5ms | `sugarText` | `/tmp/keala-all-win.cDctk1/epsilon/dist/core/context/sugar.js` |
| 0.1% | 6.6ms | 0.1% | 6.6ms | `finishDirect` | `/tmp/keala-all-win.cDctk1/epsilon/dist/core/dispatch.js:148` |
| 0.1% | 5.7ms | 0.1% | 5.7ms | `sugarText` | `/tmp/keala-all-win.cDctk1/epsilon/dist/core/context/sugar.js:191` |
| 0.1% | 4.6ms | 0.1% | 4.6ms | `dispatchRequest` | `/tmp/keala-all-win.cDctk1/epsilon/dist/core/dispatch.js` |
| 0.1% | 4.2ms | 0.1% | 4.2ms | `defineProperty` | `[native code]` |
| 0.0% | 4.0ms | 0.0% | 4.0ms | `[keala.handleRequestSource]` | `/tmp/keala-all-win.cDctk1/epsilon/dist/core/app.js:200` |
| 0.0% | 2.7ms | 0.0% | 2.7ms | `BoundContext` | `/tmp/keala-all-win.cDctk1/epsilon/dist/core/context/context.js` |
| 0.0% | 2.2ms | 0.0% | 2.2ms | `matchRoute` | `/tmp/keala-all-win.cDctk1/epsilon/dist/router/match.js:105` |
| 0.0% | 2.2ms | 0.0% | 2.2ms | `importModule` | `[native code]` |
| 0.0% | 2.1ms | 0.0% | 2.1ms | `nativeBunResponse` | `/tmp/keala-all-win.cDctk1/epsilon/dist/adapters/bun.js:17` |
| 0.0% | 2.0ms | 0.0% | 2.0ms | `createRouterState` | `/tmp/keala-all-win.cDctk1/epsilon/dist/router/router.js` |
| 0.0% | 2.0ms | 0.0% | 2.0ms | `[keala.handleRequestSource]` | `/tmp/keala-all-win.cDctk1/epsilon/dist/core/app.js:203` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `bindDef` | `/tmp/keala-all-win.cDctk1/epsilon/dist/router/router.js` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `@lazy` | `[native code]` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `(module)` | `/tmp/keala-all-win.cDctk1/epsilon/dist/core/lifecycle-admission.js:19` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `directResponse` | `/tmp/keala-all-win.cDctk1/epsilon/dist/core/context/sugar.js:31` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `node:events` | `node:events:10` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `node:url` | `node:url:7` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `copyObject` | `internal:fs/streams` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `isServerConfig` | `bun:main` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `makeSafe` | `internal:primordials:38` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `primeRequestUrl` | `/tmp/keala-all-win.cDctk1/epsilon/dist/core/request-url.js:15` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `setName` | `node:fs:673` |
| 0.0% | 998us | 0.0% | 998us | `BunServer` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/adapters/bun.mjs` |
| 0.0% | 967us | 0.0% | 967us | `startBunServer` | `/tmp/keala-all-win.cDctk1/epsilon/dist/adapters/bun.js` |
| 0.0% | 963us | 0.0% | 963us | `paramChainFor` | `/tmp/keala-all-win.cDctk1/epsilon/dist/router/chains.js` |
| 0.0% | 942us | 0.0% | 942us | `publishMatch` | `/tmp/keala-all-win.cDctk1/epsilon/dist/core/dispatch.js` |
| 0.0% | 935us | 0.0% | 935us | `serve` | `[native code]` |
| 0.0% | 927us | 0.0% | 927us | `lazyInherit` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/_chunks/_url.mjs:11` |

## Call Tree (Total Time)

| Total% | Total | Self% | Self | Function | Location |
|-------:|------:|------:|-----:|----------|----------|
| 66.0% | 2.72s | 1.1% | 46.6ms | `(anonymous)` | `/tmp/keala-all-win.cDctk1/epsilon/dist/adapters/bun.js:55` |
| 59.8% | 2.47s | 1.0% | 42.7ms | `#serve` | `/tmp/keala-all-win.cDctk1/epsilon/dist/core/app.js:224` |
| 30.4% | 1.25s | 0.0% | 0us | `dispatchRequest` | `/tmp/keala-all-win.cDctk1/epsilon/dist/core/dispatch.js:213` |
| 22.0% | 911.4ms | 22.0% | 911.4ms | `sourceUrl` | `/tmp/keala-all-win.cDctk1/epsilon/dist/core/request-source.js:11` |
| 19.3% | 798.2ms | 0.0% | 0us | `dispatchRequest` | `/tmp/keala-all-win.cDctk1/epsilon/dist/core/dispatch.js:229` |
| 19.2% | 793.4ms | 0.8% | 33.3ms | `dispatchDirect` | `/tmp/keala-all-win.cDctk1/epsilon/dist/core/dispatch.js:171` |
| 18.3% | 757.7ms | 18.2% | 753.5ms | `(anonymous)` | `/tmp/keala-all-win.cDctk1/epsilon/dist/adapters/bun.js:43` |
| 17.8% | 737.7ms | 0.0% | 0us | `sugarText` | `/tmp/keala-all-win.cDctk1/epsilon/dist/core/context/sugar.js:189` |
| 17.4% | 721.2ms | 1.3% | 55.9ms | `textResponse` | `/tmp/keala-all-win.cDctk1/epsilon/dist/core/context/sugar.js:38` |
| 17.4% | 718.9ms | 17.4% | 718.9ms | `Response` | `[native code]` |
| 7.2% | 299.1ms | 7.2% | 299.1ms | `(anonymous)` | `/tmp/keala-all-win.cDctk1/epsilon/dist/adapters/bun.js:48` |
| 5.8% | 243.2ms | 5.8% | 243.2ms | `(anonymous)` | `/tmp/keala-all-win.cDctk1/epsilon/dist/adapters/bun.js:44` |
| 3.7% | 155.3ms | 0.6% | 25.9ms | `dispatchDirect` | `/tmp/keala-all-win.cDctk1/epsilon/dist/core/dispatch.js:174` |
| 2.9% | 120.9ms | 2.9% | 120.9ms | `sourceMethod` | `/tmp/keala-all-win.cDctk1/epsilon/dist/core/request-source.js:10` |
| 2.8% | 115.5ms | 0.6% | 27.3ms | `anonymous` | `[native code]` |
| 2.7% | 113.0ms | 2.7% | 113.0ms | `primeRequestUrl` | `/tmp/keala-all-win.cDctk1/epsilon/dist/core/request-url.js:14` |
| 2.7% | 112.0ms | 2.7% | 112.0ms | `primeRequestUrl` | `/tmp/keala-all-win.cDctk1/epsilon/dist/core/request-url.js:6` |
| 2.5% | 105.6ms | 0.0% | 0us | `dispatchRequest` | `/tmp/keala-all-win.cDctk1/epsilon/dist/core/dispatch.js:221` |
| 2.2% | 92.9ms | 2.2% | 92.9ms | `primeRequestUrl` | `/tmp/keala-all-win.cDctk1/epsilon/dist/core/request-url.js:5` |
| 1.9% | 80.2ms | 1.3% | 55.6ms | `finishDirect` | `/tmp/keala-all-win.cDctk1/epsilon/dist/core/dispatch.js:159` |
| 1.4% | 59.4ms | 1.4% | 59.4ms | `settleNativeHandle` | `/tmp/keala-all-win.cDctk1/epsilon/dist/core/dispatch.js:47` |
| 1.4% | 59.2ms | 0.2% | 9.5ms | `dispatchRequest` | `/tmp/keala-all-win.cDctk1/epsilon/dist/core/dispatch.js:214` |
| 1.3% | 57.7ms | 0.0% | 0us | `#serve` | `/tmp/keala-all-win.cDctk1/epsilon/dist/core/app.js:222` |
| 1.3% | 54.9ms | 1.3% | 54.9ms | `BoundContext` | `/tmp/keala-all-win.cDctk1/epsilon/dist/core/context/context.js:166` |
| 1.2% | 53.6ms | 0.0% | 0us | `(module)` | `/tmp/keala-all-win.cDctk1/epsilon/dist/core/response-plan.js:15` |
| 1.1% | 47.4ms | 1.1% | 47.4ms | `matchRoute` | `/tmp/keala-all-win.cDctk1/epsilon/dist/router/match.js` |
| 1.0% | 42.5ms | 1.0% | 42.5ms | `finishDirect` | `/tmp/keala-all-win.cDctk1/epsilon/dist/core/dispatch.js` |
| 1.0% | 41.7ms | 1.0% | 41.7ms | `[keala.handleRequestSource]` | `/tmp/keala-all-win.cDctk1/epsilon/dist/core/app.js` |
| 0.9% | 37.2ms | 0.9% | 37.2ms | `dispatchRequest` | `/tmp/keala-all-win.cDctk1/epsilon/dist/core/dispatch.js:224` |
| 0.5% | 24.5ms | 0.5% | 24.5ms | `isEmptyStatus` | `/tmp/keala-all-win.cDctk1/epsilon/dist/http/status.js` |
| 0.5% | 24.4ms | 0.0% | 0us | `(anonymous)` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/_chunks/_utils.mjs:6` |
| 0.5% | 24.4ms | 0.0% | 0us | `(anonymous)` | `[native code]` |
| 0.5% | 24.4ms | 0.0% | 0us | `(module)` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/_chunks/_utils.mjs:6` |
| 0.5% | 22.8ms | 0.5% | 22.8ms | `#serve` | `/tmp/keala-all-win.cDctk1/epsilon/dist/core/app.js:217` |
| 0.4% | 18.1ms | 0.4% | 18.1ms | `fetch` | `/tmp/keala-all-win.cDctk1/epsilon/dist/adapters/bun.js` |
| 0.4% | 17.9ms | 0.0% | 0us | `get WriteStream` | `node:fs:644` |
| 0.4% | 17.2ms | 0.4% | 17.2ms | `primeRequestUrl` | `/tmp/keala-all-win.cDctk1/epsilon/dist/core/request-url.js:13` |
| 0.4% | 16.8ms | 0.0% | 0us | `internal:fs/streams` | `internal:fs/streams:2` |
| 0.3% | 13.7ms | 0.0% | 0us | `node:stream` | `node:stream:2` |
| 0.2% | 12.3ms | 0.0% | 0us | `internal:stream` | `internal:stream:2` |
| 0.2% | 11.0ms | 0.0% | 0us | `internal:streams/compose` | `internal:streams/compose:2` |
| 0.2% | 9.9ms | 0.0% | 0us | `internal:streams/pipeline` | `internal:streams/pipeline:2` |
| 0.2% | 9.6ms | 0.0% | 0us | `dispatchRequest` | `/tmp/keala-all-win.cDctk1/epsilon/dist/core/dispatch.js:220` |
| 0.2% | 9.0ms | 0.2% | 9.0ms | `clearStagedInPlace` | `/tmp/keala-all-win.cDctk1/epsilon/dist/core/context/sugar.js:118` |
| 0.2% | 9.0ms | 0.0% | 0us | `sugarText` | `/tmp/keala-all-win.cDctk1/epsilon/dist/core/context/sugar.js:190` |
| 0.2% | 8.9ms | 0.2% | 8.9ms | `primeRequestUrl` | `/tmp/keala-all-win.cDctk1/epsilon/dist/core/request-url.js` |
| 0.2% | 8.6ms | 0.2% | 8.6ms | `publishMatch` | `/tmp/keala-all-win.cDctk1/epsilon/dist/core/dispatch.js:195` |
| 0.2% | 8.6ms | 0.0% | 0us | `node:url` | `node:url:2` |
| 0.1% | 7.8ms | 0.1% | 7.8ms | `dispatchDirect` | `/tmp/keala-all-win.cDctk1/epsilon/dist/core/dispatch.js:172` |
| 0.1% | 7.5ms | 0.1% | 7.5ms | `sugarText` | `/tmp/keala-all-win.cDctk1/epsilon/dist/core/context/sugar.js` |
| 0.1% | 6.7ms | 0.0% | 0us | `internal:streams/duplex` | `internal:streams/duplex:2` |
| 0.1% | 6.6ms | 0.1% | 6.6ms | `finishDirect` | `/tmp/keala-all-win.cDctk1/epsilon/dist/core/dispatch.js:148` |
| 0.1% | 5.7ms | 0.1% | 5.7ms | `sugarText` | `/tmp/keala-all-win.cDctk1/epsilon/dist/core/context/sugar.js:191` |
| 0.1% | 4.6ms | 0.1% | 4.6ms | `dispatchRequest` | `/tmp/keala-all-win.cDctk1/epsilon/dist/core/dispatch.js` |
| 0.1% | 4.2ms | 0.1% | 4.2ms | `defineProperty` | `[native code]` |
| 0.0% | 4.0ms | 0.0% | 4.0ms | `[keala.handleRequestSource]` | `/tmp/keala-all-win.cDctk1/epsilon/dist/core/app.js:200` |
| 0.0% | 2.9ms | 0.0% | 0us | `(module)` | `/tmp/keala-all-win.cDctk1/epsilon/bench/framework-compare/server.mjs:42` |
| 0.0% | 2.9ms | 0.0% | 0us | `listen` | `/tmp/keala-all-win.cDctk1/epsilon/dist/core/app.js:257` |
| 0.0% | 2.7ms | 0.0% | 2.7ms | `BoundContext` | `/tmp/keala-all-win.cDctk1/epsilon/dist/core/context/context.js` |
| 0.0% | 2.3ms | 0.0% | 0us | `registerDef` | `/tmp/keala-all-win.cDctk1/epsilon/dist/router/router.js:313` |
| 0.0% | 2.3ms | 0.0% | 0us | `(module)` | `/tmp/keala-all-win.cDctk1/epsilon/bench/framework-compare/server.mjs:26` |
| 0.0% | 2.3ms | 0.0% | 0us | `routeShortcut` | `/tmp/keala-all-win.cDctk1/epsilon/dist/core/registration.js:29` |
| 0.0% | 2.3ms | 0.0% | 0us | `internal:streams/legacy` | `internal:streams/legacy:2` |
| 0.0% | 2.2ms | 0.0% | 0us | `internal:errors` | `internal:errors:2` |
| 0.0% | 2.2ms | 0.0% | 0us | `internal:streams/destroy` | `internal:streams/destroy:2` |
| 0.0% | 2.2ms | 0.0% | 2.2ms | `matchRoute` | `/tmp/keala-all-win.cDctk1/epsilon/dist/router/match.js:105` |
| 0.0% | 2.2ms | 0.0% | 0us | `(module)` | `/tmp/keala-all-win.cDctk1/epsilon/bench/framework-compare/server.mjs:21` |
| 0.0% | 2.2ms | 0.0% | 2.2ms | `importModule` | `[native code]` |
| 0.0% | 2.1ms | 0.0% | 2.1ms | `nativeBunResponse` | `/tmp/keala-all-win.cDctk1/epsilon/dist/adapters/bun.js:17` |
| 0.0% | 2.0ms | 0.0% | 0us | `Keala` | `/tmp/keala-all-win.cDctk1/epsilon/dist/core/app.js:70` |
| 0.0% | 2.0ms | 0.0% | 2.0ms | `createRouterState` | `/tmp/keala-all-win.cDctk1/epsilon/dist/router/router.js` |
| 0.0% | 2.0ms | 0.0% | 0us | `(module)` | `/tmp/keala-all-win.cDctk1/epsilon/bench/framework-compare/server.mjs:24` |
| 0.0% | 2.0ms | 0.0% | 2.0ms | `[keala.handleRequestSource]` | `/tmp/keala-all-win.cDctk1/epsilon/dist/core/app.js:203` |
| 0.0% | 1.9ms | 0.0% | 0us | `startBunServer` | `/tmp/keala-all-win.cDctk1/epsilon/dist/adapters/bun.js:222` |
| 0.0% | 1.4ms | 0.0% | 1.4ms | `bindDef` | `/tmp/keala-all-win.cDctk1/epsilon/dist/router/router.js` |
| 0.0% | 1.2ms | 0.0% | 0us | `internal:streams/operators` | `internal:streams/operators:2` |
| 0.0% | 1.2ms | 0.0% | 0us | `internal:streams/end-of-stream` | `internal:streams/end-of-stream:17` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `@lazy` | `[native code]` |
| 0.0% | 1.2ms | 0.0% | 0us | `internal:fs/binding` | `internal:fs/binding:3` |
| 0.0% | 1.2ms | 0.0% | 0us | `node:fs` | `node:fs:8` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `(module)` | `/tmp/keala-all-win.cDctk1/epsilon/dist/core/lifecycle-admission.js:19` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `directResponse` | `/tmp/keala-all-win.cDctk1/epsilon/dist/core/context/sugar.js:31` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `node:events` | `node:events:10` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `node:url` | `node:url:7` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `copyObject` | `internal:fs/streams` |
| 0.0% | 1.1ms | 0.0% | 0us | `WriteStream` | `internal:fs/streams:201` |
| 0.0% | 1.1ms | 0.0% | 0us | `(module)` | `bun:main:14` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `isServerConfig` | `bun:main` |
| 0.0% | 1.0ms | 0.0% | 0us | `internal:primordials` | `internal:primordials:83` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `makeSafe` | `internal:primordials:38` |
| 0.0% | 1.0ms | 0.0% | 0us | `internal:validators` | `internal:validators:2` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `primeRequestUrl` | `/tmp/keala-all-win.cDctk1/epsilon/dist/core/request-url.js:15` |
| 0.0% | 1.0ms | 0.0% | 0us | `internal:streams/readable` | `internal:streams/readable:2` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `setName` | `node:fs:673` |
| 0.0% | 1.0ms | 0.0% | 0us | `node:fs` | `node:fs:716` |
| 0.0% | 998us | 0.0% | 0us | `serve` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/adapters/bun.mjs:7` |
| 0.0% | 998us | 0.0% | 0us | `(anonymous)` | `/tmp/keala-all-win.cDctk1/epsilon/dist/adapters/bun.js:26` |
| 0.0% | 998us | 0.0% | 998us | `BunServer` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/adapters/bun.mjs` |
| 0.0% | 967us | 0.0% | 967us | `startBunServer` | `/tmp/keala-all-win.cDctk1/epsilon/dist/adapters/bun.js` |
| 0.0% | 963us | 0.0% | 0us | `bindDef` | `/tmp/keala-all-win.cDctk1/epsilon/dist/router/router.js:154` |
| 0.0% | 963us | 0.0% | 963us | `paramChainFor` | `/tmp/keala-all-win.cDctk1/epsilon/dist/router/chains.js` |
| 0.0% | 942us | 0.0% | 942us | `publishMatch` | `/tmp/keala-all-win.cDctk1/epsilon/dist/core/dispatch.js` |
| 0.0% | 935us | 0.0% | 0us | `serve` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/adapters/bun.mjs:72` |
| 0.0% | 935us | 0.0% | 0us | `(anonymous)` | `/tmp/keala-all-win.cDctk1/epsilon/dist/adapters/bun.js:57` |
| 0.0% | 935us | 0.0% | 935us | `serve` | `[native code]` |
| 0.0% | 927us | 0.0% | 927us | `lazyInherit` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/_chunks/_url.mjs:11` |
| 0.0% | 927us | 0.0% | 0us | `(anonymous)` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/_chunks/_url.mjs:78` |
| 0.0% | 927us | 0.0% | 0us | `(module)` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/_chunks/_url.mjs:185` |

## Function Details

### `sourceUrl`
`/tmp/keala-all-win.cDctk1/epsilon/dist/core/request-source.js:11` | Self: 22.0% (911.4ms) | Total: 22.0% (911.4ms) | Samples: 86

**Called by:**
- `dispatchRequest` (86)

### `(anonymous)`
`/tmp/keala-all-win.cDctk1/epsilon/dist/adapters/bun.js:43` | Self: 18.2% (753.5ms) | Total: 18.3% (757.7ms) | Samples: 70

**Calls:**
- `defineProperty` (1)

### `Response`
`[native code]` | Self: 17.4% (718.9ms) | Total: 17.4% (718.9ms) | Samples: 73

**Called by:**
- `textResponse` (72)
- `(module)` (1)

### `(anonymous)`
`/tmp/keala-all-win.cDctk1/epsilon/dist/adapters/bun.js:48` | Self: 7.2% (299.1ms) | Total: 7.2% (299.1ms) | Samples: 29

### `(anonymous)`
`/tmp/keala-all-win.cDctk1/epsilon/dist/adapters/bun.js:44` | Self: 5.8% (243.2ms) | Total: 5.8% (243.2ms) | Samples: 25

### `sourceMethod`
`/tmp/keala-all-win.cDctk1/epsilon/dist/core/request-source.js:10` | Self: 2.9% (120.9ms) | Total: 2.9% (120.9ms) | Samples: 8

**Called by:**
- `dispatchRequest` (7)
- `sugarText` (1)

### `primeRequestUrl`
`/tmp/keala-all-win.cDctk1/epsilon/dist/core/request-url.js:14` | Self: 2.7% (113.0ms) | Total: 2.7% (113.0ms) | Samples: 8

**Called by:**
- `dispatchRequest` (8)

### `primeRequestUrl`
`/tmp/keala-all-win.cDctk1/epsilon/dist/core/request-url.js:6` | Self: 2.7% (112.0ms) | Total: 2.7% (112.0ms) | Samples: 9

**Called by:**
- `dispatchRequest` (9)

### `primeRequestUrl`
`/tmp/keala-all-win.cDctk1/epsilon/dist/core/request-url.js:5` | Self: 2.2% (92.9ms) | Total: 2.2% (92.9ms) | Samples: 11

**Called by:**
- `dispatchRequest` (11)

### `settleNativeHandle`
`/tmp/keala-all-win.cDctk1/epsilon/dist/core/dispatch.js:47` | Self: 1.4% (59.4ms) | Total: 1.4% (59.4ms) | Samples: 3

**Called by:**
- `(anonymous)` (3)

### `textResponse`
`/tmp/keala-all-win.cDctk1/epsilon/dist/core/context/sugar.js:38` | Self: 1.3% (55.9ms) | Total: 17.4% (721.2ms) | Samples: 3

**Called by:**
- `sugarText` (75)

**Calls:**
- `Response` (72)

### `finishDirect`
`/tmp/keala-all-win.cDctk1/epsilon/dist/core/dispatch.js:159` | Self: 1.3% (55.6ms) | Total: 1.9% (80.2ms) | Samples: 3

**Called by:**
- `dispatchDirect` (4)

**Calls:**
- `isEmptyStatus` (1)

### `BoundContext`
`/tmp/keala-all-win.cDctk1/epsilon/dist/core/context/context.js:166` | Self: 1.3% (54.9ms) | Total: 1.3% (54.9ms) | Samples: 3

**Called by:**
- `#serve` (3)

### `matchRoute`
`/tmp/keala-all-win.cDctk1/epsilon/dist/router/match.js` | Self: 1.1% (47.4ms) | Total: 1.1% (47.4ms) | Samples: 7

**Called by:**
- `dispatchRequest` (7)

### `(anonymous)`
`/tmp/keala-all-win.cDctk1/epsilon/dist/adapters/bun.js:55` | Self: 1.1% (46.6ms) | Total: 66.0% (2.72s) | Samples: 4

**Calls:**
- `#serve` (246)
- `#serve` (7)
- `#serve` (4)
- `[keala.handleRequestSource]` (3)
- `settleNativeHandle` (3)
- `fetch` (2)
- `[keala.handleRequestSource]` (2)
- `[keala.handleRequestSource]` (1)

### `#serve`
`/tmp/keala-all-win.cDctk1/epsilon/dist/core/app.js:224` | Self: 1.0% (42.7ms) | Total: 59.8% (2.47s) | Samples: 3

**Called by:**
- `(anonymous)` (246)

**Calls:**
- `dispatchRequest` (121)
- `dispatchRequest` (74)
- `dispatchDirect` (20)
- `dispatchRequest` (10)
- `dispatchRequest` (7)
- `dispatchDirect` (4)
- `dispatchRequest` (3)
- `dispatchRequest` (2)
- `dispatchRequest` (1)
- `dispatchDirect` (1)

### `finishDirect`
`/tmp/keala-all-win.cDctk1/epsilon/dist/core/dispatch.js` | Self: 1.0% (42.5ms) | Total: 1.0% (42.5ms) | Samples: 3

**Called by:**
- `dispatchDirect` (3)

### `[keala.handleRequestSource]`
`/tmp/keala-all-win.cDctk1/epsilon/dist/core/app.js` | Self: 1.0% (41.7ms) | Total: 1.0% (41.7ms) | Samples: 2

**Called by:**
- `(anonymous)` (2)

### `dispatchRequest`
`/tmp/keala-all-win.cDctk1/epsilon/dist/core/dispatch.js:224` | Self: 0.9% (37.2ms) | Total: 0.9% (37.2ms) | Samples: 3

**Called by:**
- `#serve` (3)

### `dispatchDirect`
`/tmp/keala-all-win.cDctk1/epsilon/dist/core/dispatch.js:171` | Self: 0.8% (33.3ms) | Total: 19.2% (793.4ms) | Samples: 5

**Called by:**
- `dispatchRequest` (67)
- `#serve` (20)

**Calls:**
- `sugarText` (77)
- `sugarText` (2)
- `sugarText` (2)
- `sugarText` (1)

### `anonymous`
`[native code]` | Self: 0.6% (27.3ms) | Total: 2.8% (115.5ms) | Samples: 19

**Called by:**
- `get WriteStream` (16)
- `internal:fs/streams` (15)
- `node:stream` (12)
- `internal:stream` (11)
- `internal:streams/compose` (10)
- `internal:streams/pipeline` (9)
- `internal:streams/duplex` (6)
- `(anonymous)` (5)
- `internal:streams/destroy` (2)
- `internal:errors` (2)
- `internal:streams/legacy` (2)
- `node:url` (2)
- `internal:validators` (1)
- `internal:streams/readable` (1)
- `node:fs` (1)
- `internal:streams/operators` (1)
- `internal:streams/end-of-stream` (1)

**Calls:**
- `internal:fs/streams` (15)
- `node:stream` (12)
- `internal:stream` (11)
- `internal:streams/compose` (10)
- `internal:streams/pipeline` (9)
- `internal:streams/duplex` (6)
- `internal:streams/destroy` (2)
- `internal:errors` (2)
- `internal:streams/legacy` (2)
- `internal:fs/binding` (1)
- `node:fs` (1)
- `internal:streams/end-of-stream` (1)
- `internal:streams/operators` (1)
- `node:fs` (1)
- `internal:primordials` (1)
- `node:events` (1)
- `internal:streams/readable` (1)
- `internal:validators` (1)

### `dispatchDirect`
`/tmp/keala-all-win.cDctk1/epsilon/dist/core/dispatch.js:174` | Self: 0.6% (25.9ms) | Total: 3.7% (155.3ms) | Samples: 3

**Called by:**
- `dispatchRequest` (7)
- `#serve` (4)

**Calls:**
- `finishDirect` (4)
- `finishDirect` (3)
- `finishDirect` (1)

### `isEmptyStatus`
`/tmp/keala-all-win.cDctk1/epsilon/dist/http/status.js` | Self: 0.5% (24.5ms) | Total: 0.5% (24.5ms) | Samples: 1

**Called by:**
- `finishDirect` (1)

### `#serve`
`/tmp/keala-all-win.cDctk1/epsilon/dist/core/app.js:217` | Self: 0.5% (22.8ms) | Total: 0.5% (22.8ms) | Samples: 7

**Called by:**
- `(anonymous)` (7)

### `fetch`
`/tmp/keala-all-win.cDctk1/epsilon/dist/adapters/bun.js` | Self: 0.4% (18.1ms) | Total: 0.4% (18.1ms) | Samples: 2

**Called by:**
- `(anonymous)` (2)

### `primeRequestUrl`
`/tmp/keala-all-win.cDctk1/epsilon/dist/core/request-url.js:13` | Self: 0.4% (17.2ms) | Total: 0.4% (17.2ms) | Samples: 3

**Called by:**
- `dispatchRequest` (3)

### `dispatchRequest`
`/tmp/keala-all-win.cDctk1/epsilon/dist/core/dispatch.js:214` | Self: 0.2% (9.5ms) | Total: 1.4% (59.2ms) | Samples: 2

**Called by:**
- `#serve` (10)

**Calls:**
- `matchRoute` (7)
- `matchRoute` (1)

### `clearStagedInPlace`
`/tmp/keala-all-win.cDctk1/epsilon/dist/core/context/sugar.js:118` | Self: 0.2% (9.0ms) | Total: 0.2% (9.0ms) | Samples: 2

**Called by:**
- `sugarText` (2)

### `primeRequestUrl`
`/tmp/keala-all-win.cDctk1/epsilon/dist/core/request-url.js` | Self: 0.2% (8.9ms) | Total: 0.2% (8.9ms) | Samples: 3

**Called by:**
- `dispatchRequest` (3)

### `publishMatch`
`/tmp/keala-all-win.cDctk1/epsilon/dist/core/dispatch.js:195` | Self: 0.2% (8.6ms) | Total: 0.2% (8.6ms) | Samples: 1

**Called by:**
- `dispatchRequest` (1)

### `dispatchDirect`
`/tmp/keala-all-win.cDctk1/epsilon/dist/core/dispatch.js:172` | Self: 0.1% (7.8ms) | Total: 0.1% (7.8ms) | Samples: 1

**Called by:**
- `#serve` (1)

### `sugarText`
`/tmp/keala-all-win.cDctk1/epsilon/dist/core/context/sugar.js` | Self: 0.1% (7.5ms) | Total: 0.1% (7.5ms) | Samples: 2

**Called by:**
- `dispatchDirect` (2)

### `finishDirect`
`/tmp/keala-all-win.cDctk1/epsilon/dist/core/dispatch.js:148` | Self: 0.1% (6.6ms) | Total: 0.1% (6.6ms) | Samples: 1

**Called by:**
- `dispatchDirect` (1)

### `sugarText`
`/tmp/keala-all-win.cDctk1/epsilon/dist/core/context/sugar.js:191` | Self: 0.1% (5.7ms) | Total: 0.1% (5.7ms) | Samples: 1

**Called by:**
- `dispatchDirect` (1)

### `dispatchRequest`
`/tmp/keala-all-win.cDctk1/epsilon/dist/core/dispatch.js` | Self: 0.1% (4.6ms) | Total: 0.1% (4.6ms) | Samples: 1

**Called by:**
- `#serve` (1)

### `defineProperty`
`[native code]` | Self: 0.1% (4.2ms) | Total: 0.1% (4.2ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `[keala.handleRequestSource]`
`/tmp/keala-all-win.cDctk1/epsilon/dist/core/app.js:200` | Self: 0.0% (4.0ms) | Total: 0.0% (4.0ms) | Samples: 3

**Called by:**
- `(anonymous)` (3)

### `BoundContext`
`/tmp/keala-all-win.cDctk1/epsilon/dist/core/context/context.js` | Self: 0.0% (2.7ms) | Total: 0.0% (2.7ms) | Samples: 1

**Called by:**
- `#serve` (1)

### `matchRoute`
`/tmp/keala-all-win.cDctk1/epsilon/dist/router/match.js:105` | Self: 0.0% (2.2ms) | Total: 0.0% (2.2ms) | Samples: 1

**Called by:**
- `dispatchRequest` (1)

### `importModule`
`[native code]` | Self: 0.0% (2.2ms) | Total: 0.0% (2.2ms) | Samples: 1

**Called by:**
- `(module)` (1)

### `nativeBunResponse`
`/tmp/keala-all-win.cDctk1/epsilon/dist/adapters/bun.js:17` | Self: 0.0% (2.1ms) | Total: 0.0% (2.1ms) | Samples: 1

### `createRouterState`
`/tmp/keala-all-win.cDctk1/epsilon/dist/router/router.js` | Self: 0.0% (2.0ms) | Total: 0.0% (2.0ms) | Samples: 1

**Called by:**
- `Keala` (1)

### `[keala.handleRequestSource]`
`/tmp/keala-all-win.cDctk1/epsilon/dist/core/app.js:203` | Self: 0.0% (2.0ms) | Total: 0.0% (2.0ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `bindDef`
`/tmp/keala-all-win.cDctk1/epsilon/dist/router/router.js` | Self: 0.0% (1.4ms) | Total: 0.0% (1.4ms) | Samples: 1

**Called by:**
- `registerDef` (1)

### `@lazy`
`[native code]` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `internal:fs/binding` (1)

### `(module)`
`/tmp/keala-all-win.cDctk1/epsilon/dist/core/lifecycle-admission.js:19` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

### `directResponse`
`/tmp/keala-all-win.cDctk1/epsilon/dist/core/context/sugar.js:31` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `sugarText` (1)

### `node:events`
`node:events:10` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `anonymous` (1)

### `node:url`
`node:url:7` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

### `copyObject`
`internal:fs/streams` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `WriteStream` (1)

### `isServerConfig`
`bun:main` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `(module)` (1)

### `makeSafe`
`internal:primordials:38` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `internal:primordials` (1)

### `primeRequestUrl`
`/tmp/keala-all-win.cDctk1/epsilon/dist/core/request-url.js:15` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `dispatchRequest` (1)

### `setName`
`node:fs:673` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `node:fs` (1)

### `BunServer`
`/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/adapters/bun.mjs` | Self: 0.0% (998us) | Total: 0.0% (998us) | Samples: 1

**Called by:**
- `serve` (1)

### `startBunServer`
`/tmp/keala-all-win.cDctk1/epsilon/dist/adapters/bun.js` | Self: 0.0% (967us) | Total: 0.0% (967us) | Samples: 1

**Called by:**
- `listen` (1)

### `paramChainFor`
`/tmp/keala-all-win.cDctk1/epsilon/dist/router/chains.js` | Self: 0.0% (963us) | Total: 0.0% (963us) | Samples: 1

**Called by:**
- `bindDef` (1)

### `publishMatch`
`/tmp/keala-all-win.cDctk1/epsilon/dist/core/dispatch.js` | Self: 0.0% (942us) | Total: 0.0% (942us) | Samples: 1

**Called by:**
- `dispatchRequest` (1)

### `serve`
`[native code]` | Self: 0.0% (935us) | Total: 0.0% (935us) | Samples: 1

**Called by:**
- `serve` (1)

### `lazyInherit`
`/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/_chunks/_url.mjs:11` | Self: 0.0% (927us) | Total: 0.0% (927us) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `registerDef`
`/tmp/keala-all-win.cDctk1/epsilon/dist/router/router.js:313` | Self: 0.0% (0us) | Total: 0.0% (2.3ms) | Samples: 0

**Called by:**
- `routeShortcut` (2)

**Calls:**
- `bindDef` (1)
- `bindDef` (1)

### `(anonymous)`
`/tmp/keala-all-win.cDctk1/epsilon/dist/adapters/bun.js:57` | Self: 0.0% (0us) | Total: 0.0% (935us) | Samples: 0

**Called by:**
- `startBunServer` (1)

**Calls:**
- `serve` (1)

### `(module)`
`bun:main:14` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Calls:**
- `isServerConfig` (1)

### `(module)`
`/tmp/keala-all-win.cDctk1/epsilon/bench/framework-compare/server.mjs:24` | Self: 0.0% (0us) | Total: 0.0% (2.0ms) | Samples: 0

**Calls:**
- `Keala` (1)

### `Keala`
`/tmp/keala-all-win.cDctk1/epsilon/dist/core/app.js:70` | Self: 0.0% (0us) | Total: 0.0% (2.0ms) | Samples: 0

**Called by:**
- `(module)` (1)

**Calls:**
- `createRouterState` (1)

### `internal:stream`
`internal:stream:2` | Self: 0.0% (0us) | Total: 0.2% (12.3ms) | Samples: 0

**Called by:**
- `anonymous` (11)

**Calls:**
- `anonymous` (11)

### `(anonymous)`
`/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/_chunks/_utils.mjs:6` | Self: 0.0% (0us) | Total: 0.5% (24.4ms) | Samples: 0

**Called by:**
- `(module)` (22)

**Calls:**
- `(anonymous)` (22)

### `internal:primordials`
`internal:primordials:83` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `makeSafe` (1)

### `bindDef`
`/tmp/keala-all-win.cDctk1/epsilon/dist/router/router.js:154` | Self: 0.0% (0us) | Total: 0.0% (963us) | Samples: 0

**Called by:**
- `registerDef` (1)

**Calls:**
- `paramChainFor` (1)

### `internal:streams/legacy`
`internal:streams/legacy:2` | Self: 0.0% (0us) | Total: 0.0% (2.3ms) | Samples: 0

**Called by:**
- `anonymous` (2)

**Calls:**
- `anonymous` (2)

### `internal:fs/binding`
`internal:fs/binding:3` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `@lazy` (1)

### `internal:validators`
`internal:validators:2` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `anonymous` (1)

### `#serve`
`/tmp/keala-all-win.cDctk1/epsilon/dist/core/app.js:222` | Self: 0.0% (0us) | Total: 1.3% (57.7ms) | Samples: 0

**Called by:**
- `(anonymous)` (4)

**Calls:**
- `BoundContext` (3)
- `BoundContext` (1)

### `(module)`
`/tmp/keala-all-win.cDctk1/epsilon/bench/framework-compare/server.mjs:42` | Self: 0.0% (0us) | Total: 0.0% (2.9ms) | Samples: 0

**Calls:**
- `listen` (3)

### `dispatchRequest`
`/tmp/keala-all-win.cDctk1/epsilon/dist/core/dispatch.js:229` | Self: 0.0% (0us) | Total: 19.3% (798.2ms) | Samples: 0

**Called by:**
- `#serve` (74)

**Calls:**
- `dispatchDirect` (67)
- `dispatchDirect` (7)

### `listen`
`/tmp/keala-all-win.cDctk1/epsilon/dist/core/app.js:257` | Self: 0.0% (0us) | Total: 0.0% (2.9ms) | Samples: 0

**Called by:**
- `(module)` (3)

**Calls:**
- `startBunServer` (2)
- `startBunServer` (1)

### `get WriteStream`
`node:fs:644` | Self: 0.0% (0us) | Total: 0.4% (17.9ms) | Samples: 0

**Called by:**
- `(anonymous)` (16)

**Calls:**
- `anonymous` (16)

### `WriteStream`
`internal:fs/streams:201` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `(anonymous)` (1)

**Calls:**
- `copyObject` (1)

### `node:fs`
`node:fs:716` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `setName` (1)

### `internal:streams/destroy`
`internal:streams/destroy:2` | Self: 0.0% (0us) | Total: 0.0% (2.2ms) | Samples: 0

**Called by:**
- `anonymous` (2)

**Calls:**
- `anonymous` (2)

### `(anonymous)`
`[native code]` | Self: 0.0% (0us) | Total: 0.5% (24.4ms) | Samples: 0

**Called by:**
- `(anonymous)` (22)

**Calls:**
- `get WriteStream` (16)
- `anonymous` (5)
- `WriteStream` (1)

### `(module)`
`/tmp/keala-all-win.cDctk1/epsilon/bench/framework-compare/server.mjs:26` | Self: 0.0% (0us) | Total: 0.0% (2.3ms) | Samples: 0

**Calls:**
- `routeShortcut` (2)

### `serve`
`/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/adapters/bun.mjs:7` | Self: 0.0% (0us) | Total: 0.0% (998us) | Samples: 0

**Called by:**
- `(anonymous)` (1)

**Calls:**
- `BunServer` (1)

### `sugarText`
`/tmp/keala-all-win.cDctk1/epsilon/dist/core/context/sugar.js:189` | Self: 0.0% (0us) | Total: 17.8% (737.7ms) | Samples: 0

**Called by:**
- `dispatchDirect` (77)

**Calls:**
- `textResponse` (75)
- `sourceMethod` (1)
- `directResponse` (1)

### `(module)`
`/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/_chunks/_url.mjs:185` | Self: 0.0% (0us) | Total: 0.0% (927us) | Samples: 0

**Calls:**
- `(anonymous)` (1)

### `node:url`
`node:url:2` | Self: 0.0% (0us) | Total: 0.2% (8.6ms) | Samples: 0

**Calls:**
- `anonymous` (2)

### `internal:fs/streams`
`internal:fs/streams:2` | Self: 0.0% (0us) | Total: 0.4% (16.8ms) | Samples: 0

**Called by:**
- `anonymous` (15)

**Calls:**
- `anonymous` (15)

### `internal:errors`
`internal:errors:2` | Self: 0.0% (0us) | Total: 0.0% (2.2ms) | Samples: 0

**Called by:**
- `anonymous` (2)

**Calls:**
- `anonymous` (2)

### `dispatchRequest`
`/tmp/keala-all-win.cDctk1/epsilon/dist/core/dispatch.js:221` | Self: 0.0% (0us) | Total: 2.5% (105.6ms) | Samples: 0

**Called by:**
- `#serve` (7)

**Calls:**
- `sourceMethod` (7)

### `internal:streams/operators`
`internal:streams/operators:2` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `anonymous` (1)

### `internal:streams/compose`
`internal:streams/compose:2` | Self: 0.0% (0us) | Total: 0.2% (11.0ms) | Samples: 0

**Called by:**
- `anonymous` (10)

**Calls:**
- `anonymous` (10)

### `serve`
`/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/adapters/bun.mjs:72` | Self: 0.0% (0us) | Total: 0.0% (935us) | Samples: 0

**Called by:**
- `(anonymous)` (1)

**Calls:**
- `serve` (1)

### `(module)`
`/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/_chunks/_utils.mjs:6` | Self: 0.0% (0us) | Total: 0.5% (24.4ms) | Samples: 0

**Calls:**
- `(anonymous)` (22)

### `(anonymous)`
`/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/_chunks/_url.mjs:78` | Self: 0.0% (0us) | Total: 0.0% (927us) | Samples: 0

**Called by:**
- `(module)` (1)

**Calls:**
- `lazyInherit` (1)

### `node:stream`
`node:stream:2` | Self: 0.0% (0us) | Total: 0.3% (13.7ms) | Samples: 0

**Called by:**
- `anonymous` (12)

**Calls:**
- `anonymous` (12)

### `dispatchRequest`
`/tmp/keala-all-win.cDctk1/epsilon/dist/core/dispatch.js:220` | Self: 0.0% (0us) | Total: 0.2% (9.6ms) | Samples: 0

**Called by:**
- `#serve` (2)

**Calls:**
- `publishMatch` (1)
- `publishMatch` (1)

### `dispatchRequest`
`/tmp/keala-all-win.cDctk1/epsilon/dist/core/dispatch.js:213` | Self: 0.0% (0us) | Total: 30.4% (1.25s) | Samples: 0

**Called by:**
- `#serve` (121)

**Calls:**
- `sourceUrl` (86)
- `primeRequestUrl` (11)
- `primeRequestUrl` (9)
- `primeRequestUrl` (8)
- `primeRequestUrl` (3)
- `primeRequestUrl` (3)
- `primeRequestUrl` (1)

### `startBunServer`
`/tmp/keala-all-win.cDctk1/epsilon/dist/adapters/bun.js:222` | Self: 0.0% (0us) | Total: 0.0% (1.9ms) | Samples: 0

**Called by:**
- `listen` (2)

**Calls:**
- `(anonymous)` (1)
- `(anonymous)` (1)

### `internal:streams/readable`
`internal:streams/readable:2` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `anonymous` (1)

### `(module)`
`/tmp/keala-all-win.cDctk1/epsilon/bench/framework-compare/server.mjs:21` | Self: 0.0% (0us) | Total: 0.0% (2.2ms) | Samples: 0

**Calls:**
- `importModule` (1)

### `sugarText`
`/tmp/keala-all-win.cDctk1/epsilon/dist/core/context/sugar.js:190` | Self: 0.0% (0us) | Total: 0.2% (9.0ms) | Samples: 0

**Called by:**
- `dispatchDirect` (2)

**Calls:**
- `clearStagedInPlace` (2)

### `routeShortcut`
`/tmp/keala-all-win.cDctk1/epsilon/dist/core/registration.js:29` | Self: 0.0% (0us) | Total: 0.0% (2.3ms) | Samples: 0

**Called by:**
- `(module)` (2)

**Calls:**
- `registerDef` (2)

### `node:fs`
`node:fs:8` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `anonymous` (1)

### `internal:streams/end-of-stream`
`internal:streams/end-of-stream:17` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `anonymous` (1)

### `internal:streams/duplex`
`internal:streams/duplex:2` | Self: 0.0% (0us) | Total: 0.1% (6.7ms) | Samples: 0

**Called by:**
- `anonymous` (6)

**Calls:**
- `anonymous` (6)

### `(anonymous)`
`/tmp/keala-all-win.cDctk1/epsilon/dist/adapters/bun.js:26` | Self: 0.0% (0us) | Total: 0.0% (998us) | Samples: 0

**Called by:**
- `startBunServer` (1)

**Calls:**
- `serve` (1)

### `internal:streams/pipeline`
`internal:streams/pipeline:2` | Self: 0.0% (0us) | Total: 0.2% (9.9ms) | Samples: 0

**Called by:**
- `anonymous` (9)

**Calls:**
- `anonymous` (9)

### `(module)`
`/tmp/keala-all-win.cDctk1/epsilon/dist/core/response-plan.js:15` | Self: 0.0% (0us) | Total: 1.2% (53.6ms) | Samples: 0

**Calls:**
- `Response` (1)

## Files

| Self% | Self | File |
|------:|-----:|------|
| 33.0% | 1.36s | `/tmp/keala-all-win.cDctk1/epsilon/dist/adapters/bun.js` |
| 25.0% | 1.03s | `/tmp/keala-all-win.cDctk1/epsilon/dist/core/request-source.js` |
| 18.2% | 754.9ms | `[native code]` |
| 8.3% | 345.3ms | `/tmp/keala-all-win.cDctk1/epsilon/dist/core/request-url.js` |
| 7.0% | 292.5ms | `/tmp/keala-all-win.cDctk1/epsilon/dist/core/dispatch.js` |
| 2.7% | 113.4ms | `/tmp/keala-all-win.cDctk1/epsilon/dist/core/app.js` |
| 1.9% | 79.4ms | `/tmp/keala-all-win.cDctk1/epsilon/dist/core/context/sugar.js` |
| 1.3% | 57.7ms | `/tmp/keala-all-win.cDctk1/epsilon/dist/core/context/context.js` |
| 1.2% | 49.6ms | `/tmp/keala-all-win.cDctk1/epsilon/dist/router/match.js` |
| 0.5% | 24.5ms | `/tmp/keala-all-win.cDctk1/epsilon/dist/http/status.js` |
| 0.0% | 3.4ms | `/tmp/keala-all-win.cDctk1/epsilon/dist/router/router.js` |
| 0.0% | 1.2ms | `/tmp/keala-all-win.cDctk1/epsilon/dist/core/lifecycle-admission.js` |
| 0.0% | 1.1ms | `node:events` |
| 0.0% | 1.1ms | `node:url` |
| 0.0% | 1.1ms | `internal:fs/streams` |
| 0.0% | 1.1ms | `bun:main` |
| 0.0% | 1.0ms | `internal:primordials` |
| 0.0% | 1.0ms | `node:fs` |
| 0.0% | 998us | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/adapters/bun.mjs` |
| 0.0% | 963us | `/tmp/keala-all-win.cDctk1/epsilon/dist/router/chains.js` |
| 0.0% | 927us | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/_chunks/_url.mjs` |
