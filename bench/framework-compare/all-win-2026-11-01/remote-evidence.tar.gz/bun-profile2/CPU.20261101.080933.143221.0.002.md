# CPU Profile

| Duration | Samples | Interval | Functions |
|----------|---------|----------|----------|
| 39.7ms | 7 | 1.0ms | 18 |

**Top 10:** `TrieRouter` 50.1%, `Trie` 19.3%, `anonymous` 14.5%, `importModule` 7.8%, `internal:shared` 2.7%, `isServerConfig` 2.6%, `buildAllMatchers` 2.6%

## Hot Functions (Self Time)

| Self% | Self | Total% | Total | Function | Location |
|------:|-----:|-------:|------:|----------|----------|
| 50.1% | 19.9ms | 50.1% | 19.9ms | `TrieRouter` | `[native code]` |
| 19.3% | 7.7ms | 19.3% | 7.7ms | `Trie` | `[native code]` |
| 14.5% | 5.8ms | 20.1% | 8.0ms | `anonymous` | `[native code]` |
| 7.8% | 3.1ms | 7.8% | 3.1ms | `importModule` | `[native code]` |
| 2.7% | 1.0ms | 2.7% | 1.0ms | `internal:shared` | `internal:shared:294` |
| 2.6% | 1.0ms | 2.6% | 1.0ms | `isServerConfig` | `bun:main` |
| 2.6% | 1.0ms | 2.6% | 1.0ms | `buildAllMatchers` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/hono/dist/router/reg-exp-router/router.js` |

## Call Tree (Total Time)

| Total% | Total | Self% | Self | Function | Location |
|-------:|------:|------:|-----:|----------|----------|
| 50.1% | 19.9ms | 0.0% | 0us | `(module)` | `/tmp/keala-all-win.cDctk1/epsilon/bench/framework-compare/server.mjs:53` |
| 50.1% | 19.9ms | 0.0% | 0us | `Hono` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/hono/dist/hono.js:15` |
| 50.1% | 19.9ms | 50.1% | 19.9ms | `TrieRouter` | `[native code]` |
| 22.0% | 8.7ms | 0.0% | 0us | `#dispatch` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/hono/dist/hono-base.js:283` |
| 20.1% | 8.0ms | 14.5% | 5.8ms | `anonymous` | `[native code]` |
| 19.3% | 7.7ms | 0.0% | 0us | `add` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/hono/dist/router/reg-exp-router/router.js:58` |
| 19.3% | 7.7ms | 0.0% | 0us | `match` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/hono/dist/router/smart-router/router.js:29` |
| 19.3% | 7.7ms | 19.3% | 7.7ms | `Trie` | `[native code]` |
| 17.3% | 6.9ms | 0.0% | 0us | `node:url` | `node:url:2` |
| 7.8% | 3.1ms | 7.8% | 3.1ms | `importModule` | `[native code]` |
| 7.8% | 3.1ms | 0.0% | 0us | `(module)` | `/tmp/keala-all-win.cDctk1/epsilon/bench/framework-compare/server.mjs:52` |
| 2.7% | 1.0ms | 0.0% | 0us | `internal:validators` | `internal:validators:2` |
| 2.7% | 1.0ms | 2.7% | 1.0ms | `internal:shared` | `internal:shared:294` |
| 2.6% | 1.0ms | 0.0% | 0us | `(module)` | `bun:main:14` |
| 2.6% | 1.0ms | 2.6% | 1.0ms | `isServerConfig` | `bun:main` |
| 2.6% | 1.0ms | 0.0% | 0us | `match` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/hono/dist/router/smart-router/router.js:31` |
| 2.6% | 1.0ms | 0.0% | 0us | `match` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/hono/dist/router/reg-exp-router/matcher.js:5` |
| 2.6% | 1.0ms | 2.6% | 1.0ms | `buildAllMatchers` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/hono/dist/router/reg-exp-router/router.js` |

## Function Details

### `TrieRouter`
`[native code]` | Self: 50.1% (19.9ms) | Total: 50.1% (19.9ms) | Samples: 1

**Called by:**
- `Hono` (1)

### `Trie`
`[native code]` | Self: 19.3% (7.7ms) | Total: 19.3% (7.7ms) | Samples: 1

**Called by:**
- `add` (1)

### `anonymous`
`[native code]` | Self: 14.5% (5.8ms) | Total: 20.1% (8.0ms) | Samples: 1

**Called by:**
- `node:url` (2)
- `internal:validators` (1)

**Calls:**
- `internal:shared` (1)
- `internal:validators` (1)

### `importModule`
`[native code]` | Self: 7.8% (3.1ms) | Total: 7.8% (3.1ms) | Samples: 1

**Called by:**
- `(module)` (1)

### `internal:shared`
`internal:shared:294` | Self: 2.7% (1.0ms) | Total: 2.7% (1.0ms) | Samples: 1

**Called by:**
- `anonymous` (1)

### `isServerConfig`
`bun:main` | Self: 2.6% (1.0ms) | Total: 2.6% (1.0ms) | Samples: 1

**Called by:**
- `(module)` (1)

### `buildAllMatchers`
`/tmp/keala-all-win.cDctk1/epsilon/node_modules/hono/dist/router/reg-exp-router/router.js` | Self: 2.6% (1.0ms) | Total: 2.6% (1.0ms) | Samples: 1

**Called by:**
- `match` (1)

### `Hono`
`/tmp/keala-all-win.cDctk1/epsilon/node_modules/hono/dist/hono.js:15` | Self: 0.0% (0us) | Total: 50.1% (19.9ms) | Samples: 0

**Called by:**
- `(module)` (1)

**Calls:**
- `TrieRouter` (1)

### `#dispatch`
`/tmp/keala-all-win.cDctk1/epsilon/node_modules/hono/dist/hono-base.js:283` | Self: 0.0% (0us) | Total: 22.0% (8.7ms) | Samples: 0

**Calls:**
- `match` (1)
- `match` (1)

### `(module)`
`bun:main:14` | Self: 0.0% (0us) | Total: 2.6% (1.0ms) | Samples: 0

**Calls:**
- `isServerConfig` (1)

### `(module)`
`/tmp/keala-all-win.cDctk1/epsilon/bench/framework-compare/server.mjs:52` | Self: 0.0% (0us) | Total: 7.8% (3.1ms) | Samples: 0

**Calls:**
- `importModule` (1)

### `match`
`/tmp/keala-all-win.cDctk1/epsilon/node_modules/hono/dist/router/smart-router/router.js:29` | Self: 0.0% (0us) | Total: 19.3% (7.7ms) | Samples: 0

**Called by:**
- `#dispatch` (1)

**Calls:**
- `add` (1)

### `internal:validators`
`internal:validators:2` | Self: 0.0% (0us) | Total: 2.7% (1.0ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `anonymous` (1)

### `node:url`
`node:url:2` | Self: 0.0% (0us) | Total: 17.3% (6.9ms) | Samples: 0

**Calls:**
- `anonymous` (2)

### `add`
`/tmp/keala-all-win.cDctk1/epsilon/node_modules/hono/dist/router/reg-exp-router/router.js:58` | Self: 0.0% (0us) | Total: 19.3% (7.7ms) | Samples: 0

**Called by:**
- `match` (1)

**Calls:**
- `Trie` (1)

### `(module)`
`/tmp/keala-all-win.cDctk1/epsilon/bench/framework-compare/server.mjs:53` | Self: 0.0% (0us) | Total: 50.1% (19.9ms) | Samples: 0

**Calls:**
- `Hono` (1)

### `match`
`/tmp/keala-all-win.cDctk1/epsilon/node_modules/hono/dist/router/reg-exp-router/matcher.js:5` | Self: 0.0% (0us) | Total: 2.6% (1.0ms) | Samples: 0

**Called by:**
- `match` (1)

**Calls:**
- `buildAllMatchers` (1)

### `match`
`/tmp/keala-all-win.cDctk1/epsilon/node_modules/hono/dist/router/smart-router/router.js:31` | Self: 0.0% (0us) | Total: 2.6% (1.0ms) | Samples: 0

**Called by:**
- `#dispatch` (1)

**Calls:**
- `match` (1)

## Files

| Self% | Self | File |
|------:|-----:|------|
| 91.9% | 36.5ms | `[native code]` |
| 2.7% | 1.0ms | `internal:shared` |
| 2.6% | 1.0ms | `bun:main` |
| 2.6% | 1.0ms | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/hono/dist/router/reg-exp-router/router.js` |
