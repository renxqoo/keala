# CPU Profile

| Duration | Samples | Interval | Functions |
|----------|---------|----------|----------|
| 107.7ms | 32 | 1.0ms | 59 |

**Top 10:** `(anonymous)` 46.4%, `anonymous` 21.3%, `toJSON` 14.8%, `replace` 2.6%, `includes` 2.1%, `URL` 2.0%, `call` 1.2%, `getStreamOptions` 1.1%, `(anonymous)` 1.0%, `log` 1.0%

## Hot Functions (Self Time)

| Self% | Self | Total% | Total | Function | Location |
|------:|-----:|-------:|------:|----------|----------|
| 46.4% | 50.0ms | 46.4% | 50.0ms | `(anonymous)` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/_chunks/_url.mjs` |
| 21.3% | 23.0ms | 90.9% | 98.0ms | `anonymous` | `[native code]` |
| 14.8% | 16.0ms | 14.8% | 16.0ms | `toJSON` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/h3/dist/response.mjs` |
| 2.6% | 2.8ms | 2.6% | 2.8ms | `replace` | `[native code]` |
| 2.1% | 2.2ms | 2.1% | 2.2ms | `includes` | `[native code]` |
| 2.0% | 2.1ms | 2.0% | 2.1ms | `URL` | `[native code]` |
| 1.2% | 1.3ms | 1.2% | 1.3ms | `call` | `[native code]` |
| 1.1% | 1.2ms | 1.1% | 1.2ms | `getStreamOptions` | `internal:fs/streams` |
| 1.0% | 1.1ms | 20.4% | 21.9ms | `(anonymous)` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/_chunks/_utils.mjs:6` |
| 1.0% | 1.1ms | 1.0% | 1.1ms | `log` | `[native code]` |
| 1.0% | 1.1ms | 1.0% | 1.1ms | `(anonymous)` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/adapters/bun.mjs:16` |
| 1.0% | 1.1ms | 1.0% | 1.1ms | `encodeEscapes` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/rou3/dist/index.mjs` |
| 0.9% | 1.0ms | 0.9% | 1.0ms | `internal:streams/duplex` | `internal:streams/duplex:48` |
| 0.9% | 1.0ms | 0.9% | 1.0ms | `prepareResponse` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/h3/dist/response.mjs` |
| 0.9% | 1.0ms | 0.9% | 1.0ms | `printListening` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/_chunks/_utils2.mjs` |
| 0.9% | 1.0ms | 0.9% | 1.0ms | `node:fs` | `node:fs:8` |

## Call Tree (Total Time)

| Total% | Total | Self% | Self | Function | Location |
|-------:|------:|------:|-----:|----------|----------|
| 90.9% | 98.0ms | 21.3% | 23.0ms | `anonymous` | `[native code]` |
| 46.4% | 50.0ms | 46.4% | 50.0ms | `(anonymous)` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/_chunks/_url.mjs` |
| 40.4% | 43.6ms | 0.0% | 0us | `(module)` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/_chunks/_url.mjs:185` |
| 21.7% | 23.4ms | 0.0% | 0us | `bound fetch` | `[native code]` |
| 21.7% | 23.4ms | 0.0% | 0us | `(anonymous)` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/adapters/bun.mjs:52` |
| 20.4% | 21.9ms | 0.0% | 0us | `(module)` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/_chunks/_utils.mjs:6` |
| 20.4% | 21.9ms | 1.0% | 1.1ms | `(anonymous)` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/_chunks/_utils.mjs:6` |
| 19.3% | 20.8ms | 0.0% | 0us | `(anonymous)` | `[native code]` |
| 15.8% | 17.0ms | 0.0% | 0us | `toResponse` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/h3/dist/response.mjs:309` |
| 15.2% | 16.4ms | 0.0% | 0us | `get WriteStream` | `node:fs:644` |
| 14.8% | 16.0ms | 0.0% | 0us | `errorResponse` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/h3/dist/response.mjs:457` |
| 14.8% | 16.0ms | 14.8% | 16.0ms | `toJSON` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/h3/dist/response.mjs` |
| 14.8% | 16.0ms | 0.0% | 0us | `prepareResponse` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/h3/dist/response.mjs:368` |
| 14.2% | 15.3ms | 0.0% | 0us | `internal:fs/streams` | `internal:fs/streams:2` |
| 11.4% | 12.2ms | 0.0% | 0us | `node:stream` | `node:stream:2` |
| 10.1% | 10.9ms | 0.0% | 0us | `internal:stream` | `internal:stream:2` |
| 9.2% | 9.9ms | 0.0% | 0us | `internal:streams/pipeline` | `internal:streams/pipeline:2` |
| 9.2% | 9.9ms | 0.0% | 0us | `internal:streams/compose` | `internal:streams/compose:2` |
| 6.3% | 6.8ms | 0.0% | 0us | `node:url` | `node:url:2` |
| 5.9% | 6.4ms | 0.0% | 0us | `~request` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/h3/dist/cache.mjs:389` |
| 5.9% | 6.4ms | 0.0% | 0us | `H3Event` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/h3/dist/response.mjs:100` |
| 5.9% | 6.4ms | 0.0% | 0us | `URL` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/_chunks/_url.mjs:90` |
| 4.9% | 5.3ms | 0.0% | 0us | `internal:streams/duplex` | `internal:streams/duplex:2` |
| 3.7% | 4.0ms | 0.0% | 0us | `(module)` | `/tmp/keala-all-win.cDctk1/epsilon/bench/framework-compare/server.mjs:83` |
| 2.6% | 2.8ms | 2.6% | 2.8ms | `replace` | `[native code]` |
| 2.6% | 2.8ms | 0.0% | 0us | `on` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/h3/dist/cache.mjs:483` |
| 2.6% | 2.8ms | 0.0% | 0us | `normalizeRoute` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/h3/dist/response.mjs:48` |
| 2.1% | 2.3ms | 0.0% | 0us | `internal:streams/destroy` | `internal:streams/destroy:2` |
| 2.1% | 2.3ms | 0.0% | 0us | `internal:errors` | `internal:errors:2` |
| 2.1% | 2.2ms | 0.0% | 0us | `(module)` | `/tmp/keala-all-win.cDctk1/epsilon/bench/framework-compare/server.mjs:7` |
| 2.1% | 2.2ms | 2.1% | 2.2ms | `includes` | `[native code]` |
| 2.0% | 2.2ms | 0.0% | 0us | `(module)` | `/tmp/keala-all-win.cDctk1/epsilon/bench/framework-compare/server.mjs:98` |
| 2.0% | 2.2ms | 0.0% | 0us | `serve` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/adapters/bun.mjs:7` |
| 2.0% | 2.1ms | 0.0% | 0us | `(module)` | `/tmp/keala-all-win.cDctk1/epsilon/bench/framework-compare/server.mjs:100` |
| 2.0% | 2.1ms | 2.0% | 2.1ms | `URL` | `[native code]` |
| 1.2% | 1.3ms | 0.0% | 0us | `internal:primordials` | `internal:primordials:83` |
| 1.2% | 1.3ms | 0.0% | 0us | `bound call` | `[native code]` |
| 1.2% | 1.3ms | 0.0% | 0us | `makeSafe` | `internal:primordials:35` |
| 1.2% | 1.3ms | 1.2% | 1.3ms | `call` | `[native code]` |
| 1.1% | 1.2ms | 1.1% | 1.2ms | `getStreamOptions` | `internal:fs/streams` |
| 1.1% | 1.2ms | 0.0% | 0us | `WriteStream` | `internal:fs/streams:201` |
| 1.0% | 1.1ms | 1.0% | 1.1ms | `log` | `[native code]` |
| 1.0% | 1.1ms | 0.0% | 0us | `(module)` | `/tmp/keala-all-win.cDctk1/epsilon/bench/framework-compare/server.mjs:130` |
| 1.0% | 1.1ms | 0.0% | 0us | `BunServer` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/adapters/bun.mjs:17` |
| 1.0% | 1.1ms | 1.0% | 1.1ms | `(anonymous)` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/adapters/bun.mjs:16` |
| 1.0% | 1.1ms | 0.0% | 0us | `on` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/h3/dist/cache.mjs:484` |
| 1.0% | 1.1ms | 1.0% | 1.1ms | `encodeEscapes` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/rou3/dist/index.mjs` |
| 1.0% | 1.1ms | 0.0% | 0us | `~addRoute` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/h3/dist/cache.mjs:505` |
| 1.0% | 1.1ms | 0.0% | 0us | `addRoute` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/rou3/dist/index.mjs:407` |
| 1.0% | 1.1ms | 0.0% | 0us | `_add` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/rou3/dist/index.mjs:421` |
| 0.9% | 1.0ms | 0.9% | 1.0ms | `internal:streams/duplex` | `internal:streams/duplex:48` |
| 0.9% | 1.0ms | 0.9% | 1.0ms | `prepareResponse` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/h3/dist/response.mjs` |
| 0.9% | 1.0ms | 0.0% | 0us | `BunServer` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/adapters/bun.mjs:69` |
| 0.9% | 1.0ms | 0.9% | 1.0ms | `printListening` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/_chunks/_utils2.mjs` |
| 0.9% | 1.0ms | 0.0% | 0us | `serve` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/adapters/bun.mjs:73` |
| 0.9% | 1.0ms | 0.0% | 0us | `internal:streams/operators` | `internal:streams/operators:2` |
| 0.9% | 1.0ms | 0.0% | 0us | `internal:streams/legacy` | `internal:streams/legacy:2` |
| 0.9% | 1.0ms | 0.9% | 1.0ms | `node:fs` | `node:fs:8` |
| 0.9% | 987us | 0.0% | 0us | `internal:validators` | `internal:validators:2` |

## Function Details

### `(anonymous)`
`/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/_chunks/_url.mjs` | Self: 46.4% (50.0ms) | Total: 46.4% (50.0ms) | Samples: 2

**Called by:**
- `URL` (1)
- `(module)` (1)

### `anonymous`
`[native code]` | Self: 21.3% (23.0ms) | Total: 90.9% (98.0ms) | Samples: 16

**Called by:**
- `get WriteStream` (14)
- `internal:fs/streams` (13)
- `node:stream` (11)
- `internal:stream` (10)
- `internal:streams/pipeline` (9)
- `internal:streams/compose` (9)
- `internal:streams/duplex` (5)
- `(anonymous)` (3)
- `node:url` (2)
- `internal:streams/destroy` (2)
- `internal:errors` (2)
- `internal:validators` (1)
- `internal:streams/operators` (1)
- `internal:streams/legacy` (1)

**Calls:**
- `internal:fs/streams` (13)
- `node:stream` (11)
- `internal:stream` (10)
- `internal:streams/pipeline` (9)
- `internal:streams/compose` (9)
- `internal:streams/duplex` (5)
- `internal:streams/destroy` (2)
- `internal:errors` (2)
- `internal:validators` (1)
- `internal:primordials` (1)
- `node:fs` (1)
- `internal:streams/operators` (1)
- `internal:streams/legacy` (1)
- `internal:streams/duplex` (1)

### `toJSON`
`/tmp/keala-all-win.cDctk1/epsilon/node_modules/h3/dist/response.mjs` | Self: 14.8% (16.0ms) | Total: 14.8% (16.0ms) | Samples: 1

**Called by:**
- `errorResponse` (1)

### `replace`
`[native code]` | Self: 2.6% (2.8ms) | Total: 2.6% (2.8ms) | Samples: 1

**Called by:**
- `normalizeRoute` (1)

### `includes`
`[native code]` | Self: 2.1% (2.2ms) | Total: 2.1% (2.2ms) | Samples: 1

**Called by:**
- `(module)` (1)

### `URL`
`[native code]` | Self: 2.0% (2.1ms) | Total: 2.0% (2.1ms) | Samples: 1

**Called by:**
- `(module)` (1)

### `call`
`[native code]` | Self: 1.2% (1.3ms) | Total: 1.2% (1.3ms) | Samples: 1

**Called by:**
- `bound call` (1)

### `getStreamOptions`
`internal:fs/streams` | Self: 1.1% (1.2ms) | Total: 1.1% (1.2ms) | Samples: 1

**Called by:**
- `WriteStream` (1)

### `(anonymous)`
`/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/_chunks/_utils.mjs:6` | Self: 1.0% (1.1ms) | Total: 20.4% (21.9ms) | Samples: 1

**Called by:**
- `(module)` (19)

**Calls:**
- `(anonymous)` (18)

### `log`
`[native code]` | Self: 1.0% (1.1ms) | Total: 1.0% (1.1ms) | Samples: 1

**Called by:**
- `(module)` (1)

### `(anonymous)`
`/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/adapters/bun.mjs:16` | Self: 1.0% (1.1ms) | Total: 1.0% (1.1ms) | Samples: 1

**Called by:**
- `BunServer` (1)

### `encodeEscapes`
`/tmp/keala-all-win.cDctk1/epsilon/node_modules/rou3/dist/index.mjs` | Self: 1.0% (1.1ms) | Total: 1.0% (1.1ms) | Samples: 1

**Called by:**
- `_add` (1)

### `internal:streams/duplex`
`internal:streams/duplex:48` | Self: 0.9% (1.0ms) | Total: 0.9% (1.0ms) | Samples: 1

**Called by:**
- `anonymous` (1)

### `prepareResponse`
`/tmp/keala-all-win.cDctk1/epsilon/node_modules/h3/dist/response.mjs` | Self: 0.9% (1.0ms) | Total: 0.9% (1.0ms) | Samples: 1

**Called by:**
- `toResponse` (1)

### `printListening`
`/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/_chunks/_utils2.mjs` | Self: 0.9% (1.0ms) | Total: 0.9% (1.0ms) | Samples: 1

**Called by:**
- `serve` (1)

### `node:fs`
`node:fs:8` | Self: 0.9% (1.0ms) | Total: 0.9% (1.0ms) | Samples: 1

**Called by:**
- `anonymous` (1)

### `internal:streams/duplex`
`internal:streams/duplex:2` | Self: 0.0% (0us) | Total: 4.9% (5.3ms) | Samples: 0

**Called by:**
- `anonymous` (5)

**Calls:**
- `anonymous` (5)

### `_add`
`/tmp/keala-all-win.cDctk1/epsilon/node_modules/rou3/dist/index.mjs:421` | Self: 0.0% (0us) | Total: 1.0% (1.1ms) | Samples: 0

**Called by:**
- `addRoute` (1)

**Calls:**
- `encodeEscapes` (1)

### `errorResponse`
`/tmp/keala-all-win.cDctk1/epsilon/node_modules/h3/dist/response.mjs:457` | Self: 0.0% (0us) | Total: 14.8% (16.0ms) | Samples: 0

**Called by:**
- `prepareResponse` (1)

**Calls:**
- `toJSON` (1)

### `get WriteStream`
`node:fs:644` | Self: 0.0% (0us) | Total: 15.2% (16.4ms) | Samples: 0

**Called by:**
- `(anonymous)` (14)

**Calls:**
- `anonymous` (14)

### `internal:primordials`
`internal:primordials:83` | Self: 0.0% (0us) | Total: 1.2% (1.3ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `makeSafe` (1)

### `~addRoute`
`/tmp/keala-all-win.cDctk1/epsilon/node_modules/h3/dist/cache.mjs:505` | Self: 0.0% (0us) | Total: 1.0% (1.1ms) | Samples: 0

**Called by:**
- `on` (1)

**Calls:**
- `addRoute` (1)

### `bound call`
`[native code]` | Self: 0.0% (0us) | Total: 1.2% (1.3ms) | Samples: 0

**Called by:**
- `makeSafe` (1)

**Calls:**
- `call` (1)

### `internal:streams/legacy`
`internal:streams/legacy:2` | Self: 0.0% (0us) | Total: 0.9% (1.0ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `anonymous` (1)

### `(module)`
`/tmp/keala-all-win.cDctk1/epsilon/bench/framework-compare/server.mjs:98` | Self: 0.0% (0us) | Total: 2.0% (2.2ms) | Samples: 0

**Calls:**
- `serve` (2)

### `(module)`
`/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/_chunks/_utils.mjs:6` | Self: 0.0% (0us) | Total: 20.4% (21.9ms) | Samples: 0

**Calls:**
- `(anonymous)` (19)

### `(module)`
`/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/_chunks/_url.mjs:185` | Self: 0.0% (0us) | Total: 40.4% (43.6ms) | Samples: 0

**Calls:**
- `(anonymous)` (1)

### `serve`
`/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/adapters/bun.mjs:7` | Self: 0.0% (0us) | Total: 2.0% (2.2ms) | Samples: 0

**Called by:**
- `(module)` (2)

**Calls:**
- `BunServer` (1)
- `BunServer` (1)

### `internal:streams/destroy`
`internal:streams/destroy:2` | Self: 0.0% (0us) | Total: 2.1% (2.3ms) | Samples: 0

**Called by:**
- `anonymous` (2)

**Calls:**
- `anonymous` (2)

### `internal:streams/pipeline`
`internal:streams/pipeline:2` | Self: 0.0% (0us) | Total: 9.2% (9.9ms) | Samples: 0

**Called by:**
- `anonymous` (9)

**Calls:**
- `anonymous` (9)

### `(anonymous)`
`[native code]` | Self: 0.0% (0us) | Total: 19.3% (20.8ms) | Samples: 0

**Called by:**
- `(anonymous)` (18)

**Calls:**
- `get WriteStream` (14)
- `anonymous` (3)
- `WriteStream` (1)

### `(module)`
`/tmp/keala-all-win.cDctk1/epsilon/bench/framework-compare/server.mjs:130` | Self: 0.0% (0us) | Total: 1.0% (1.1ms) | Samples: 0

**Calls:**
- `log` (1)

### `bound fetch`
`[native code]` | Self: 0.0% (0us) | Total: 21.7% (23.4ms) | Samples: 0

**Called by:**
- `(anonymous)` (3)

**Calls:**
- `toResponse` (2)
- `~request` (1)

### `URL`
`/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/_chunks/_url.mjs:90` | Self: 0.0% (0us) | Total: 5.9% (6.4ms) | Samples: 0

**Called by:**
- `H3Event` (1)

**Calls:**
- `(anonymous)` (1)

### `internal:fs/streams`
`internal:fs/streams:2` | Self: 0.0% (0us) | Total: 14.2% (15.3ms) | Samples: 0

**Called by:**
- `anonymous` (13)

**Calls:**
- `anonymous` (13)

### `(module)`
`/tmp/keala-all-win.cDctk1/epsilon/bench/framework-compare/server.mjs:7` | Self: 0.0% (0us) | Total: 2.1% (2.2ms) | Samples: 0

**Calls:**
- `includes` (1)

### `(module)`
`/tmp/keala-all-win.cDctk1/epsilon/bench/framework-compare/server.mjs:100` | Self: 0.0% (0us) | Total: 2.0% (2.1ms) | Samples: 0

**Calls:**
- `URL` (1)

### `makeSafe`
`internal:primordials:35` | Self: 0.0% (0us) | Total: 1.2% (1.3ms) | Samples: 0

**Called by:**
- `internal:primordials` (1)

**Calls:**
- `bound call` (1)

### `WriteStream`
`internal:fs/streams:201` | Self: 0.0% (0us) | Total: 1.1% (1.2ms) | Samples: 0

**Called by:**
- `(anonymous)` (1)

**Calls:**
- `getStreamOptions` (1)

### `on`
`/tmp/keala-all-win.cDctk1/epsilon/node_modules/h3/dist/cache.mjs:483` | Self: 0.0% (0us) | Total: 2.6% (2.8ms) | Samples: 0

**Called by:**
- `(module)` (1)

**Calls:**
- `normalizeRoute` (1)

### `internal:errors`
`internal:errors:2` | Self: 0.0% (0us) | Total: 2.1% (2.3ms) | Samples: 0

**Called by:**
- `anonymous` (2)

**Calls:**
- `anonymous` (2)

### `internal:streams/operators`
`internal:streams/operators:2` | Self: 0.0% (0us) | Total: 0.9% (1.0ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `anonymous` (1)

### `internal:streams/compose`
`internal:streams/compose:2` | Self: 0.0% (0us) | Total: 9.2% (9.9ms) | Samples: 0

**Called by:**
- `anonymous` (9)

**Calls:**
- `anonymous` (9)

### `addRoute`
`/tmp/keala-all-win.cDctk1/epsilon/node_modules/rou3/dist/index.mjs:407` | Self: 0.0% (0us) | Total: 1.0% (1.1ms) | Samples: 0

**Called by:**
- `~addRoute` (1)

**Calls:**
- `_add` (1)

### `BunServer`
`/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/adapters/bun.mjs:17` | Self: 0.0% (0us) | Total: 1.0% (1.1ms) | Samples: 0

**Called by:**
- `serve` (1)

**Calls:**
- `(anonymous)` (1)

### `node:stream`
`node:stream:2` | Self: 0.0% (0us) | Total: 11.4% (12.2ms) | Samples: 0

**Called by:**
- `anonymous` (11)

**Calls:**
- `anonymous` (11)

### `normalizeRoute`
`/tmp/keala-all-win.cDctk1/epsilon/node_modules/h3/dist/response.mjs:48` | Self: 0.0% (0us) | Total: 2.6% (2.8ms) | Samples: 0

**Called by:**
- `on` (1)

**Calls:**
- `replace` (1)

### `~request`
`/tmp/keala-all-win.cDctk1/epsilon/node_modules/h3/dist/cache.mjs:389` | Self: 0.0% (0us) | Total: 5.9% (6.4ms) | Samples: 0

**Called by:**
- `bound fetch` (1)

**Calls:**
- `H3Event` (1)

### `on`
`/tmp/keala-all-win.cDctk1/epsilon/node_modules/h3/dist/cache.mjs:484` | Self: 0.0% (0us) | Total: 1.0% (1.1ms) | Samples: 0

**Called by:**
- `(module)` (1)

**Calls:**
- `~addRoute` (1)

### `internal:validators`
`internal:validators:2` | Self: 0.0% (0us) | Total: 0.9% (987us) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `anonymous` (1)

### `internal:stream`
`internal:stream:2` | Self: 0.0% (0us) | Total: 10.1% (10.9ms) | Samples: 0

**Called by:**
- `anonymous` (10)

**Calls:**
- `anonymous` (10)

### `(anonymous)`
`/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/adapters/bun.mjs:52` | Self: 0.0% (0us) | Total: 21.7% (23.4ms) | Samples: 0

**Calls:**
- `bound fetch` (3)

### `BunServer`
`/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/adapters/bun.mjs:69` | Self: 0.0% (0us) | Total: 0.9% (1.0ms) | Samples: 0

**Called by:**
- `serve` (1)

**Calls:**
- `serve` (1)

### `(module)`
`/tmp/keala-all-win.cDctk1/epsilon/bench/framework-compare/server.mjs:83` | Self: 0.0% (0us) | Total: 3.7% (4.0ms) | Samples: 0

**Calls:**
- `on` (1)
- `on` (1)

### `prepareResponse`
`/tmp/keala-all-win.cDctk1/epsilon/node_modules/h3/dist/response.mjs:368` | Self: 0.0% (0us) | Total: 14.8% (16.0ms) | Samples: 0

**Called by:**
- `toResponse` (1)

**Calls:**
- `errorResponse` (1)

### `H3Event`
`/tmp/keala-all-win.cDctk1/epsilon/node_modules/h3/dist/response.mjs:100` | Self: 0.0% (0us) | Total: 5.9% (6.4ms) | Samples: 0

**Called by:**
- `~request` (1)

**Calls:**
- `URL` (1)

### `toResponse`
`/tmp/keala-all-win.cDctk1/epsilon/node_modules/h3/dist/response.mjs:309` | Self: 0.0% (0us) | Total: 15.8% (17.0ms) | Samples: 0

**Called by:**
- `bound fetch` (2)

**Calls:**
- `prepareResponse` (1)
- `prepareResponse` (1)

### `node:url`
`node:url:2` | Self: 0.0% (0us) | Total: 6.3% (6.8ms) | Samples: 0

**Calls:**
- `anonymous` (2)

### `serve`
`/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/adapters/bun.mjs:73` | Self: 0.0% (0us) | Total: 0.9% (1.0ms) | Samples: 0

**Called by:**
- `BunServer` (1)

**Calls:**
- `printListening` (1)

## Files

| Self% | Self | File |
|------:|-----:|------|
| 46.4% | 50.0ms | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/_chunks/_url.mjs` |
| 30.4% | 32.8ms | `[native code]` |
| 15.8% | 17.0ms | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/h3/dist/response.mjs` |
| 1.1% | 1.2ms | `internal:fs/streams` |
| 1.0% | 1.1ms | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/_chunks/_utils.mjs` |
| 1.0% | 1.1ms | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/adapters/bun.mjs` |
| 1.0% | 1.1ms | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/rou3/dist/index.mjs` |
| 0.9% | 1.0ms | `internal:streams/duplex` |
| 0.9% | 1.0ms | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/_chunks/_utils2.mjs` |
| 0.9% | 1.0ms | `node:fs` |
