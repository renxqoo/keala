# CPU Profile

| Duration | Samples | Interval | Functions |
|----------|---------|----------|----------|
| 4.10s | 469 | 1.0ms | 101 |

**Top 10:** `sourceUrl` 22.3%, `Response` 18.8%, `(anonymous)` 15.7%, `splitPathSearch` 6.6%, `(anonymous)` 6.2%, `sourceMethod` 3.8%, `(anonymous)` 3.2%, `finishDirect` 2.8%, `splitPathSearch` 2.8%, `#serve` 2.5%

## Hot Functions (Self Time)

| Self% | Self | Total% | Total | Function | Location |
|------:|-----:|-------:|------:|----------|----------|
| 22.3% | 917.3ms | 22.3% | 917.3ms | `sourceUrl` | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/core/request-source.js:11` |
| 18.8% | 774.3ms | 18.8% | 774.3ms | `Response` | `[native code]` |
| 15.7% | 645.0ms | 15.7% | 645.0ms | `(anonymous)` | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/adapters/bun.js:43` |
| 6.6% | 273.6ms | 6.6% | 273.6ms | `splitPathSearch` | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/utils/url.js:54` |
| 6.2% | 256.2ms | 6.2% | 256.2ms | `(anonymous)` | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/adapters/bun.js:48` |
| 3.8% | 158.9ms | 3.8% | 158.9ms | `sourceMethod` | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/core/request-source.js:10` |
| 3.2% | 131.3ms | 3.2% | 131.3ms | `(anonymous)` | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/adapters/bun.js:44` |
| 2.8% | 118.2ms | 2.8% | 118.2ms | `finishDirect` | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/core/dispatch.js:159` |
| 2.8% | 116.3ms | 3.0% | 124.0ms | `splitPathSearch` | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/utils/url.js:48` |
| 2.5% | 105.1ms | 2.5% | 105.1ms | `#serve` | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/core/app.js:213` |
| 1.6% | 66.1ms | 20.4% | 840.4ms | `textResponse` | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/core/context/sugar.js:38` |
| 1.5% | 64.3ms | 1.5% | 64.3ms | `dispatchRequest` | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/core/dispatch.js:226` |
| 1.5% | 62.0ms | 1.5% | 62.0ms | `splitPathSearch` | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/utils/url.js:49` |
| 1.3% | 55.9ms | 23.4% | 960.0ms | `dispatchDirect` | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/core/dispatch.js:171` |
| 1.1% | 47.8ms | 1.1% | 47.8ms | `defineProperties` | `[native code]` |
| 0.7% | 30.3ms | 0.7% | 30.3ms | `BoundContext` | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/core/context/context.js:166` |
| 0.5% | 24.5ms | 0.5% | 24.5ms | `splitPathSearch` | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/utils/url.js` |
| 0.5% | 23.2ms | 0.5% | 23.2ms | `publishMatch` | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/core/dispatch.js:195` |
| 0.4% | 19.1ms | 0.4% | 19.1ms | `splitPathSearch` | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/utils/url.js:53` |
| 0.4% | 18.9ms | 67.6% | 2.77s | `#serve` | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/core/app.js:220` |
| 0.4% | 18.5ms | 2.6% | 107.9ms | `anonymous` | `[native code]` |
| 0.4% | 17.3ms | 0.4% | 17.3ms | `settleNativeHandle` | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/core/dispatch.js:47` |
| 0.4% | 17.2ms | 0.4% | 17.2ms | `splitPathSearch` | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/utils/url.js:59` |
| 0.4% | 17.0ms | 0.4% | 17.0ms | `[keala.handleRequestSource]` | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/core/app.js:199` |
| 0.3% | 14.9ms | 0.3% | 14.9ms | `[keala.handleRequestSource]` | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/core/app.js:196` |
| 0.2% | 10.4ms | 0.2% | 10.4ms | `[keala.handleRequestSource]` | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/core/app.js` |
| 0.2% | 10.2ms | 0.2% | 10.2ms | `#serve` | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/core/app.js:238` |
| 0.2% | 9.3ms | 0.2% | 9.3ms | `matchRoute` | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/router/match.js` |
| 0.1% | 7.9ms | 19.9% | 820.1ms | `dispatchRequest` | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/core/dispatch.js:231` |
| 0.1% | 7.7ms | 0.1% | 7.7ms | `indexOf` | `[native code]` |
| 0.1% | 6.7ms | 0.1% | 6.7ms | `matchRoute` | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/router/match.js:105` |
| 0.1% | 6.0ms | 0.1% | 6.0ms | `(anonymous)` | `/tmp/keala-all-win.cDctk1/epsilon/bench/framework-compare/server.mjs:26` |
| 0.1% | 5.3ms | 72.8% | 2.98s | `(anonymous)` | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/adapters/bun.js:55` |
| 0.1% | 5.0ms | 0.1% | 5.0ms | `clearStagedInPlace` | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/core/context/sugar.js:118` |
| 0.0% | 4.0ms | 35.1% | 1.44s | `dispatchRequest` | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/core/dispatch.js:213` |
| 0.0% | 3.6ms | 0.0% | 3.6ms | `publishMatch` | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/core/dispatch.js:197` |
| 0.0% | 3.2ms | 0.0% | 3.2ms | `sourceMethod` | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/core/request-source.js` |
| 0.0% | 2.5ms | 0.0% | 2.5ms | `(module)` | `/tmp/keala-all-win.cDctk1/epsilon/bench/framework-compare/server.mjs:5` |
| 0.0% | 2.3ms | 2.9% | 120.5ms | `dispatchDirect` | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/core/dispatch.js:174` |
| 0.0% | 2.1ms | 0.0% | 2.1ms | `clearStagedInPlace` | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/core/context/sugar.js:120` |
| 0.0% | 2.0ms | 0.0% | 2.0ms | `sugarText` | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/core/context/sugar.js:156` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `guarded` | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/core/compose.js:154` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `setName` | `node:fs:673` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `node:fs` | `node:fs:87` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `lazyInherit` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/_chunks/_url.mjs:11` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `internal:primordials` | `internal:primordials:15` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `defineProperty` | `[native code]` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `assertCanStart` | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/core/server-slot.js` |
| 0.0% | 1.1ms | 0.6% | 28.0ms | `dispatchRequest` | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/core/dispatch.js:222` |
| 0.0% | 1.1ms | 0.5% | 22.7ms | `(anonymous)` | `[native code]` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `node:events` | `node:events:10` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `asyncWrap` | `node:fs/promises:249` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `serve` | `[native code]` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `settleNativeHandle` | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/core/dispatch.js` |
| 0.0% | 994us | 0.0% | 994us | `indexPattern` | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/router/router.js` |
| 0.0% | 940us | 0.0% | 940us | `normalizeRequestTimeout` | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/core/lifecycle.js` |
| 0.0% | 919us | 0.0% | 919us | `textResponse` | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/core/context/sugar.js:35` |

## Call Tree (Total Time)

| Total% | Total | Self% | Self | Function | Location |
|-------:|------:|------:|-----:|----------|----------|
| 72.8% | 2.98s | 0.1% | 5.3ms | `(anonymous)` | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/adapters/bun.js:55` |
| 67.6% | 2.77s | 0.4% | 18.9ms | `#serve` | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/core/app.js:220` |
| 35.1% | 1.44s | 0.0% | 4.0ms | `dispatchRequest` | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/core/dispatch.js:213` |
| 23.4% | 960.0ms | 1.3% | 55.9ms | `dispatchDirect` | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/core/dispatch.js:171` |
| 22.3% | 917.3ms | 22.3% | 917.3ms | `sourceUrl` | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/core/request-source.js:11` |
| 20.5% | 841.4ms | 0.0% | 0us | `sugarText` | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/core/context/sugar.js:169` |
| 20.4% | 840.4ms | 1.6% | 66.1ms | `textResponse` | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/core/context/sugar.js:38` |
| 19.9% | 820.1ms | 0.1% | 7.9ms | `dispatchRequest` | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/core/dispatch.js:231` |
| 18.8% | 774.3ms | 18.8% | 774.3ms | `Response` | `[native code]` |
| 15.7% | 645.0ms | 15.7% | 645.0ms | `(anonymous)` | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/adapters/bun.js:43` |
| 6.6% | 273.6ms | 6.6% | 273.6ms | `splitPathSearch` | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/utils/url.js:54` |
| 6.2% | 256.2ms | 6.2% | 256.2ms | `(anonymous)` | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/adapters/bun.js:48` |
| 3.8% | 158.9ms | 3.8% | 158.9ms | `sourceMethod` | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/core/request-source.js:10` |
| 3.2% | 131.3ms | 3.2% | 131.3ms | `(anonymous)` | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/adapters/bun.js:44` |
| 3.0% | 124.0ms | 2.8% | 116.3ms | `splitPathSearch` | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/utils/url.js:48` |
| 2.9% | 120.5ms | 0.0% | 2.3ms | `dispatchDirect` | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/core/dispatch.js:174` |
| 2.8% | 118.2ms | 2.8% | 118.2ms | `finishDirect` | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/core/dispatch.js:159` |
| 2.8% | 116.0ms | 0.0% | 0us | `dispatchRequest` | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/core/dispatch.js:223` |
| 2.6% | 107.9ms | 0.4% | 18.5ms | `anonymous` | `[native code]` |
| 2.5% | 105.1ms | 2.5% | 105.1ms | `#serve` | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/core/app.js:213` |
| 1.5% | 64.3ms | 1.5% | 64.3ms | `dispatchRequest` | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/core/dispatch.js:226` |
| 1.5% | 62.0ms | 1.5% | 62.0ms | `splitPathSearch` | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/utils/url.js:49` |
| 1.1% | 47.8ms | 1.1% | 47.8ms | `defineProperties` | `[native code]` |
| 1.1% | 46.5ms | 0.0% | 0us | `mergeProtos` | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/core/context/context.js:19` |
| 1.1% | 46.5ms | 0.0% | 0us | `(module)` | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/core/context/context.js:94` |
| 1.1% | 46.1ms | 0.0% | 0us | `sugarText` | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/core/context/sugar.js:165` |
| 0.7% | 30.3ms | 0.7% | 30.3ms | `BoundContext` | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/core/context/context.js:166` |
| 0.7% | 30.3ms | 0.0% | 0us | `#serve` | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/core/app.js:218` |
| 0.6% | 28.0ms | 0.0% | 1.1ms | `dispatchRequest` | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/core/dispatch.js:222` |
| 0.5% | 24.5ms | 0.5% | 24.5ms | `splitPathSearch` | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/utils/url.js` |
| 0.5% | 23.2ms | 0.5% | 23.2ms | `publishMatch` | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/core/dispatch.js:195` |
| 0.5% | 22.7ms | 0.0% | 0us | `(module)` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/_chunks/_utils.mjs:6` |
| 0.5% | 22.7ms | 0.0% | 1.1ms | `(anonymous)` | `[native code]` |
| 0.5% | 22.7ms | 0.0% | 0us | `(anonymous)` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/_chunks/_utils.mjs:6` |
| 0.4% | 19.1ms | 0.4% | 19.1ms | `splitPathSearch` | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/utils/url.js:53` |
| 0.4% | 17.3ms | 0.4% | 17.3ms | `settleNativeHandle` | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/core/dispatch.js:47` |
| 0.4% | 17.2ms | 0.4% | 17.2ms | `splitPathSearch` | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/utils/url.js:59` |
| 0.4% | 17.0ms | 0.4% | 17.0ms | `[keala.handleRequestSource]` | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/core/app.js:199` |
| 0.3% | 16.1ms | 0.0% | 0us | `dispatchRequest` | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/core/dispatch.js:216` |
| 0.3% | 16.0ms | 0.0% | 0us | `get WriteStream` | `node:fs:644` |
| 0.3% | 16.0ms | 0.0% | 0us | `internal:fs/streams` | `internal:fs/streams:2` |
| 0.3% | 14.9ms | 0.3% | 14.9ms | `[keala.handleRequestSource]` | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/core/app.js:196` |
| 0.3% | 14.1ms | 0.0% | 0us | `node:stream` | `node:stream:2` |
| 0.3% | 12.9ms | 0.0% | 0us | `internal:stream` | `internal:stream:2` |
| 0.2% | 10.6ms | 0.0% | 0us | `internal:streams/compose` | `internal:streams/compose:2` |
| 0.2% | 10.4ms | 0.2% | 10.4ms | `[keala.handleRequestSource]` | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/core/app.js` |
| 0.2% | 10.2ms | 0.2% | 10.2ms | `#serve` | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/core/app.js:238` |
| 0.2% | 9.5ms | 0.0% | 0us | `internal:streams/pipeline` | `internal:streams/pipeline:2` |
| 0.2% | 9.3ms | 0.2% | 9.3ms | `matchRoute` | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/router/match.js` |
| 0.1% | 7.7ms | 0.1% | 7.7ms | `indexOf` | `[native code]` |
| 0.1% | 7.1ms | 0.0% | 0us | `sugarText` | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/core/context/sugar.js:180` |
| 0.1% | 6.7ms | 0.1% | 6.7ms | `matchRoute` | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/router/match.js:105` |
| 0.1% | 6.0ms | 0.1% | 6.0ms | `(anonymous)` | `/tmp/keala-all-win.cDctk1/epsilon/bench/framework-compare/server.mjs:26` |
| 0.1% | 5.9ms | 0.0% | 0us | `internal:streams/duplex` | `internal:streams/duplex:2` |
| 0.1% | 5.3ms | 0.0% | 0us | `node:url` | `node:url:2` |
| 0.1% | 5.0ms | 0.1% | 5.0ms | `clearStagedInPlace` | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/core/context/sugar.js:118` |
| 0.0% | 3.6ms | 0.0% | 3.6ms | `publishMatch` | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/core/dispatch.js:197` |
| 0.0% | 3.2ms | 0.0% | 3.2ms | `sourceMethod` | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/core/request-source.js` |
| 0.0% | 2.5ms | 0.0% | 2.5ms | `(module)` | `/tmp/keala-all-win.cDctk1/epsilon/bench/framework-compare/server.mjs:5` |
| 0.0% | 2.4ms | 0.0% | 0us | `internal:streams/destroy` | `internal:streams/destroy:2` |
| 0.0% | 2.4ms | 0.0% | 0us | `internal:errors` | `internal:errors:2` |
| 0.0% | 2.3ms | 0.0% | 0us | `internal:streams/legacy` | `internal:streams/legacy:2` |
| 0.0% | 2.2ms | 0.0% | 0us | `internal:streams/operators` | `internal:streams/operators:2` |
| 0.0% | 2.1ms | 0.0% | 0us | `listen` | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/core/app.js:253` |
| 0.0% | 2.1ms | 0.0% | 0us | `(module)` | `/tmp/keala-all-win.cDctk1/epsilon/bench/framework-compare/server.mjs:42` |
| 0.0% | 2.1ms | 0.0% | 2.1ms | `clearStagedInPlace` | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/core/context/sugar.js:120` |
| 0.0% | 2.0ms | 0.0% | 2.0ms | `sugarText` | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/core/context/sugar.js:156` |
| 0.0% | 1.3ms | 0.0% | 1.3ms | `guarded` | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/core/compose.js:154` |
| 0.0% | 1.2ms | 0.0% | 0us | `node:fs` | `node:fs:759` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `setName` | `node:fs:673` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `node:fs` | `node:fs:87` |
| 0.0% | 1.2ms | 0.0% | 0us | `(anonymous)` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/_chunks/_url.mjs:78` |
| 0.0% | 1.2ms | 0.0% | 0us | `(module)` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/_chunks/_url.mjs:185` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `lazyInherit` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/_chunks/_url.mjs:11` |
| 0.0% | 1.2ms | 0.0% | 0us | `internal:streams/duplex` | `internal:streams/duplex:51` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `internal:primordials` | `internal:primordials:15` |
| 0.0% | 1.2ms | 0.0% | 0us | `internal:streams/readable` | `internal:streams/readable:2` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `defineProperty` | `[native code]` |
| 0.0% | 1.1ms | 0.0% | 0us | `copyProps` | `internal:primordials:27` |
| 0.0% | 1.1ms | 0.0% | 0us | `internal:primordials` | `internal:primordials:88` |
| 0.0% | 1.1ms | 0.0% | 0us | `makeSafe` | `internal:primordials:52` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `assertCanStart` | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/core/server-slot.js` |
| 0.0% | 1.1ms | 0.0% | 0us | `startBunServer` | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/adapters/bun.js:90` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `node:events` | `node:events:10` |
| 0.0% | 1.0ms | 0.0% | 0us | `node:fs/promises` | `node:fs/promises:157` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `asyncWrap` | `node:fs/promises:249` |
| 0.0% | 1.0ms | 0.0% | 0us | `internal:streams/end-of-stream` | `internal:streams/end-of-stream:17` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `settleNativeHandle` | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/core/dispatch.js` |
| 0.0% | 1.0ms | 0.0% | 0us | `startBunServer` | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/adapters/bun.js:222` |
| 0.0% | 1.0ms | 0.0% | 0us | `(anonymous)` | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/adapters/bun.js:57` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `serve` | `[native code]` |
| 0.0% | 1.0ms | 0.0% | 0us | `serve` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/adapters/bun.mjs:72` |
| 0.0% | 994us | 0.0% | 0us | `registerDef` | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/router/router.js:313` |
| 0.0% | 994us | 0.0% | 0us | `bindDef` | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/router/router.js:131` |
| 0.0% | 994us | 0.0% | 0us | `routeShortcut` | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/core/registration.js:29` |
| 0.0% | 994us | 0.0% | 994us | `indexPattern` | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/router/router.js` |
| 0.0% | 994us | 0.0% | 0us | `(module)` | `/tmp/keala-all-win.cDctk1/epsilon/bench/framework-compare/server.mjs:26` |
| 0.0% | 940us | 0.0% | 0us | `Keala` | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/core/app.js:82` |
| 0.0% | 940us | 0.0% | 0us | `(module)` | `/tmp/keala-all-win.cDctk1/epsilon/bench/framework-compare/server.mjs:24` |
| 0.0% | 940us | 0.0% | 940us | `normalizeRequestTimeout` | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/core/lifecycle.js` |
| 0.0% | 919us | 0.0% | 919us | `textResponse` | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/core/context/sugar.js:35` |

## Function Details

### `sourceUrl`
`/tmp/keala-all-win.cDctk1/epsilon/before/dist/core/request-source.js:11` | Self: 22.3% (917.3ms) | Total: 22.3% (917.3ms) | Samples: 91

**Called by:**
- `dispatchRequest` (91)

### `Response`
`[native code]` | Self: 18.8% (774.3ms) | Total: 18.8% (774.3ms) | Samples: 76

**Called by:**
- `textResponse` (76)

### `(anonymous)`
`/tmp/keala-all-win.cDctk1/epsilon/before/dist/adapters/bun.js:43` | Self: 15.7% (645.0ms) | Total: 15.7% (645.0ms) | Samples: 65

### `splitPathSearch`
`/tmp/keala-all-win.cDctk1/epsilon/before/dist/utils/url.js:54` | Self: 6.6% (273.6ms) | Total: 6.6% (273.6ms) | Samples: 24

**Called by:**
- `dispatchRequest` (24)

### `(anonymous)`
`/tmp/keala-all-win.cDctk1/epsilon/before/dist/adapters/bun.js:48` | Self: 6.2% (256.2ms) | Total: 6.2% (256.2ms) | Samples: 38

### `sourceMethod`
`/tmp/keala-all-win.cDctk1/epsilon/before/dist/core/request-source.js:10` | Self: 3.8% (158.9ms) | Total: 3.8% (158.9ms) | Samples: 12

**Called by:**
- `dispatchRequest` (8)
- `sugarText` (4)

### `(anonymous)`
`/tmp/keala-all-win.cDctk1/epsilon/before/dist/adapters/bun.js:44` | Self: 3.2% (131.3ms) | Total: 3.2% (131.3ms) | Samples: 21

### `finishDirect`
`/tmp/keala-all-win.cDctk1/epsilon/before/dist/core/dispatch.js:159` | Self: 2.8% (118.2ms) | Total: 2.8% (118.2ms) | Samples: 7

**Called by:**
- `dispatchDirect` (7)

### `splitPathSearch`
`/tmp/keala-all-win.cDctk1/epsilon/before/dist/utils/url.js:48` | Self: 2.8% (116.3ms) | Total: 3.0% (124.0ms) | Samples: 11

**Called by:**
- `dispatchRequest` (12)

**Calls:**
- `indexOf` (1)

### `#serve`
`/tmp/keala-all-win.cDctk1/epsilon/before/dist/core/app.js:213` | Self: 2.5% (105.1ms) | Total: 2.5% (105.1ms) | Samples: 15

**Called by:**
- `(anonymous)` (15)

### `textResponse`
`/tmp/keala-all-win.cDctk1/epsilon/before/dist/core/context/sugar.js:38` | Self: 1.6% (66.1ms) | Total: 20.4% (840.4ms) | Samples: 8

**Called by:**
- `sugarText` (84)

**Calls:**
- `Response` (76)

### `dispatchRequest`
`/tmp/keala-all-win.cDctk1/epsilon/before/dist/core/dispatch.js:226` | Self: 1.5% (64.3ms) | Total: 1.5% (64.3ms) | Samples: 9

**Called by:**
- `#serve` (9)

### `splitPathSearch`
`/tmp/keala-all-win.cDctk1/epsilon/before/dist/utils/url.js:49` | Self: 1.5% (62.0ms) | Total: 1.5% (62.0ms) | Samples: 8

**Called by:**
- `dispatchRequest` (8)

### `dispatchDirect`
`/tmp/keala-all-win.cDctk1/epsilon/before/dist/core/dispatch.js:171` | Self: 1.3% (55.9ms) | Total: 23.4% (960.0ms) | Samples: 8

**Called by:**
- `dispatchRequest` (68)
- `#serve` (36)

**Calls:**
- `sugarText` (85)
- `sugarText` (4)
- `sugarText` (3)
- `sugarText` (2)
- `guarded` (1)
- `(anonymous)` (1)

### `defineProperties`
`[native code]` | Self: 1.1% (47.8ms) | Total: 1.1% (47.8ms) | Samples: 2

**Called by:**
- `internal:streams/duplex` (1)
- `mergeProtos` (1)

### `BoundContext`
`/tmp/keala-all-win.cDctk1/epsilon/before/dist/core/context/context.js:166` | Self: 0.7% (30.3ms) | Total: 0.7% (30.3ms) | Samples: 3

**Called by:**
- `#serve` (3)

### `splitPathSearch`
`/tmp/keala-all-win.cDctk1/epsilon/before/dist/utils/url.js` | Self: 0.5% (24.5ms) | Total: 0.5% (24.5ms) | Samples: 1

**Called by:**
- `dispatchRequest` (1)

### `publishMatch`
`/tmp/keala-all-win.cDctk1/epsilon/before/dist/core/dispatch.js:195` | Self: 0.5% (23.2ms) | Total: 0.5% (23.2ms) | Samples: 3

**Called by:**
- `dispatchRequest` (3)

### `splitPathSearch`
`/tmp/keala-all-win.cDctk1/epsilon/before/dist/utils/url.js:53` | Self: 0.4% (19.1ms) | Total: 0.4% (19.1ms) | Samples: 2

**Called by:**
- `dispatchRequest` (2)

### `#serve`
`/tmp/keala-all-win.cDctk1/epsilon/before/dist/core/app.js:220` | Self: 0.4% (18.9ms) | Total: 67.6% (2.77s) | Samples: 3

**Called by:**
- `(anonymous)` (286)

**Calls:**
- `dispatchRequest` (143)
- `dispatchRequest` (72)
- `dispatchDirect` (36)
- `dispatchRequest` (10)
- `dispatchRequest` (9)
- `dispatchRequest` (5)
- `dispatchDirect` (5)
- `dispatchRequest` (3)

### `anonymous`
`[native code]` | Self: 0.4% (18.5ms) | Total: 2.6% (107.9ms) | Samples: 12

**Called by:**
- `internal:fs/streams` (14)
- `get WriteStream` (14)
- `node:stream` (12)
- `internal:stream` (11)
- `internal:streams/compose` (9)
- `internal:streams/pipeline` (8)
- `internal:streams/duplex` (5)
- `(anonymous)` (4)
- `internal:streams/destroy` (2)
- `internal:errors` (2)
- `internal:streams/operators` (2)
- `internal:streams/legacy` (2)
- `node:url` (1)
- `internal:streams/readable` (1)
- `internal:streams/end-of-stream` (1)

**Calls:**
- `internal:fs/streams` (14)
- `node:stream` (12)
- `internal:stream` (11)
- `internal:streams/compose` (9)
- `internal:streams/pipeline` (8)
- `internal:streams/duplex` (5)
- `internal:errors` (2)
- `internal:streams/legacy` (2)
- `internal:streams/operators` (2)
- `internal:streams/destroy` (2)
- `node:fs/promises` (1)
- `internal:streams/end-of-stream` (1)
- `internal:primordials` (1)
- `node:fs` (1)
- `internal:primordials` (1)
- `internal:streams/duplex` (1)
- `internal:streams/readable` (1)
- `node:events` (1)
- `node:fs` (1)

### `settleNativeHandle`
`/tmp/keala-all-win.cDctk1/epsilon/before/dist/core/dispatch.js:47` | Self: 0.4% (17.3ms) | Total: 0.4% (17.3ms) | Samples: 3

**Called by:**
- `(anonymous)` (3)

### `splitPathSearch`
`/tmp/keala-all-win.cDctk1/epsilon/before/dist/utils/url.js:59` | Self: 0.4% (17.2ms) | Total: 0.4% (17.2ms) | Samples: 2

**Called by:**
- `dispatchRequest` (2)

### `[keala.handleRequestSource]`
`/tmp/keala-all-win.cDctk1/epsilon/before/dist/core/app.js:199` | Self: 0.4% (17.0ms) | Total: 0.4% (17.0ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `[keala.handleRequestSource]`
`/tmp/keala-all-win.cDctk1/epsilon/before/dist/core/app.js:196` | Self: 0.3% (14.9ms) | Total: 0.3% (14.9ms) | Samples: 3

**Called by:**
- `(anonymous)` (3)

### `[keala.handleRequestSource]`
`/tmp/keala-all-win.cDctk1/epsilon/before/dist/core/app.js` | Self: 0.2% (10.4ms) | Total: 0.2% (10.4ms) | Samples: 3

**Called by:**
- `(anonymous)` (3)

### `#serve`
`/tmp/keala-all-win.cDctk1/epsilon/before/dist/core/app.js:238` | Self: 0.2% (10.2ms) | Total: 0.2% (10.2ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `matchRoute`
`/tmp/keala-all-win.cDctk1/epsilon/before/dist/router/match.js` | Self: 0.2% (9.3ms) | Total: 0.2% (9.3ms) | Samples: 2

**Called by:**
- `dispatchRequest` (2)

### `dispatchRequest`
`/tmp/keala-all-win.cDctk1/epsilon/before/dist/core/dispatch.js:231` | Self: 0.1% (7.9ms) | Total: 19.9% (820.1ms) | Samples: 1

**Called by:**
- `#serve` (72)

**Calls:**
- `dispatchDirect` (68)
- `dispatchDirect` (3)

### `indexOf`
`[native code]` | Self: 0.1% (7.7ms) | Total: 0.1% (7.7ms) | Samples: 1

**Called by:**
- `splitPathSearch` (1)

### `matchRoute`
`/tmp/keala-all-win.cDctk1/epsilon/before/dist/router/match.js:105` | Self: 0.1% (6.7ms) | Total: 0.1% (6.7ms) | Samples: 1

**Called by:**
- `dispatchRequest` (1)

### `(anonymous)`
`/tmp/keala-all-win.cDctk1/epsilon/bench/framework-compare/server.mjs:26` | Self: 0.1% (6.0ms) | Total: 0.1% (6.0ms) | Samples: 1

**Called by:**
- `dispatchDirect` (1)

### `(anonymous)`
`/tmp/keala-all-win.cDctk1/epsilon/before/dist/adapters/bun.js:55` | Self: 0.1% (5.3ms) | Total: 72.8% (2.98s) | Samples: 2

**Calls:**
- `#serve` (286)
- `#serve` (15)
- `settleNativeHandle` (3)
- `[keala.handleRequestSource]` (3)
- `[keala.handleRequestSource]` (3)
- `#serve` (3)
- `settleNativeHandle` (1)
- `#serve` (1)
- `[keala.handleRequestSource]` (1)

### `clearStagedInPlace`
`/tmp/keala-all-win.cDctk1/epsilon/before/dist/core/context/sugar.js:118` | Self: 0.1% (5.0ms) | Total: 0.1% (5.0ms) | Samples: 1

**Called by:**
- `sugarText` (1)

### `dispatchRequest`
`/tmp/keala-all-win.cDctk1/epsilon/before/dist/core/dispatch.js:213` | Self: 0.0% (4.0ms) | Total: 35.1% (1.44s) | Samples: 3

**Called by:**
- `#serve` (143)

**Calls:**
- `sourceUrl` (91)
- `splitPathSearch` (24)
- `splitPathSearch` (12)
- `splitPathSearch` (8)
- `splitPathSearch` (2)
- `splitPathSearch` (2)
- `splitPathSearch` (1)

### `publishMatch`
`/tmp/keala-all-win.cDctk1/epsilon/before/dist/core/dispatch.js:197` | Self: 0.0% (3.6ms) | Total: 0.0% (3.6ms) | Samples: 1

**Called by:**
- `dispatchRequest` (1)

### `sourceMethod`
`/tmp/keala-all-win.cDctk1/epsilon/before/dist/core/request-source.js` | Self: 0.0% (3.2ms) | Total: 0.0% (3.2ms) | Samples: 2

**Called by:**
- `dispatchRequest` (2)

### `(module)`
`/tmp/keala-all-win.cDctk1/epsilon/bench/framework-compare/server.mjs:5` | Self: 0.0% (2.5ms) | Total: 0.0% (2.5ms) | Samples: 1

### `dispatchDirect`
`/tmp/keala-all-win.cDctk1/epsilon/before/dist/core/dispatch.js:174` | Self: 0.0% (2.3ms) | Total: 2.9% (120.5ms) | Samples: 1

**Called by:**
- `#serve` (5)
- `dispatchRequest` (3)

**Calls:**
- `finishDirect` (7)

### `clearStagedInPlace`
`/tmp/keala-all-win.cDctk1/epsilon/before/dist/core/context/sugar.js:120` | Self: 0.0% (2.1ms) | Total: 0.0% (2.1ms) | Samples: 2

**Called by:**
- `sugarText` (2)

### `sugarText`
`/tmp/keala-all-win.cDctk1/epsilon/before/dist/core/context/sugar.js:156` | Self: 0.0% (2.0ms) | Total: 0.0% (2.0ms) | Samples: 2

**Called by:**
- `dispatchDirect` (2)

### `guarded`
`/tmp/keala-all-win.cDctk1/epsilon/before/dist/core/compose.js:154` | Self: 0.0% (1.3ms) | Total: 0.0% (1.3ms) | Samples: 1

**Called by:**
- `dispatchDirect` (1)

### `setName`
`node:fs:673` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `node:fs` (1)

### `node:fs`
`node:fs:87` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `anonymous` (1)

### `lazyInherit`
`/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/_chunks/_url.mjs:11` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `internal:primordials`
`internal:primordials:15` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `anonymous` (1)

### `defineProperty`
`[native code]` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `copyProps` (1)

### `assertCanStart`
`/tmp/keala-all-win.cDctk1/epsilon/before/dist/core/server-slot.js` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `startBunServer` (1)

### `dispatchRequest`
`/tmp/keala-all-win.cDctk1/epsilon/before/dist/core/dispatch.js:222` | Self: 0.0% (1.1ms) | Total: 0.6% (28.0ms) | Samples: 1

**Called by:**
- `#serve` (5)

**Calls:**
- `publishMatch` (3)
- `publishMatch` (1)

### `(anonymous)`
`[native code]` | Self: 0.0% (1.1ms) | Total: 0.5% (22.7ms) | Samples: 1

**Called by:**
- `(anonymous)` (19)

**Calls:**
- `get WriteStream` (14)
- `anonymous` (4)

### `node:events`
`node:events:10` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `anonymous` (1)

### `asyncWrap`
`node:fs/promises:249` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `node:fs/promises` (1)

### `serve`
`[native code]` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `serve` (1)

### `settleNativeHandle`
`/tmp/keala-all-win.cDctk1/epsilon/before/dist/core/dispatch.js` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `indexPattern`
`/tmp/keala-all-win.cDctk1/epsilon/before/dist/router/router.js` | Self: 0.0% (994us) | Total: 0.0% (994us) | Samples: 1

**Called by:**
- `bindDef` (1)

### `normalizeRequestTimeout`
`/tmp/keala-all-win.cDctk1/epsilon/before/dist/core/lifecycle.js` | Self: 0.0% (940us) | Total: 0.0% (940us) | Samples: 1

**Called by:**
- `Keala` (1)

### `textResponse`
`/tmp/keala-all-win.cDctk1/epsilon/before/dist/core/context/sugar.js:35` | Self: 0.0% (919us) | Total: 0.0% (919us) | Samples: 1

**Called by:**
- `sugarText` (1)

### `Keala`
`/tmp/keala-all-win.cDctk1/epsilon/before/dist/core/app.js:82` | Self: 0.0% (0us) | Total: 0.0% (940us) | Samples: 0

**Called by:**
- `(module)` (1)

**Calls:**
- `normalizeRequestTimeout` (1)

### `internal:streams/duplex`
`internal:streams/duplex:51` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `defineProperties` (1)

### `(anonymous)`
`/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/_chunks/_utils.mjs:6` | Self: 0.0% (0us) | Total: 0.5% (22.7ms) | Samples: 0

**Called by:**
- `(module)` (19)

**Calls:**
- `(anonymous)` (19)

### `get WriteStream`
`node:fs:644` | Self: 0.0% (0us) | Total: 0.3% (16.0ms) | Samples: 0

**Called by:**
- `(anonymous)` (14)

**Calls:**
- `anonymous` (14)

### `mergeProtos`
`/tmp/keala-all-win.cDctk1/epsilon/before/dist/core/context/context.js:19` | Self: 0.0% (0us) | Total: 1.1% (46.5ms) | Samples: 0

**Called by:**
- `(module)` (1)

**Calls:**
- `defineProperties` (1)

### `internal:streams/legacy`
`internal:streams/legacy:2` | Self: 0.0% (0us) | Total: 0.0% (2.3ms) | Samples: 0

**Called by:**
- `anonymous` (2)

**Calls:**
- `anonymous` (2)

### `routeShortcut`
`/tmp/keala-all-win.cDctk1/epsilon/before/dist/core/registration.js:29` | Self: 0.0% (0us) | Total: 0.0% (994us) | Samples: 0

**Called by:**
- `(module)` (1)

**Calls:**
- `registerDef` (1)

### `#serve`
`/tmp/keala-all-win.cDctk1/epsilon/before/dist/core/app.js:218` | Self: 0.0% (0us) | Total: 0.7% (30.3ms) | Samples: 0

**Called by:**
- `(anonymous)` (3)

**Calls:**
- `BoundContext` (3)

### `node:fs`
`node:fs:759` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `setName` (1)

### `startBunServer`
`/tmp/keala-all-win.cDctk1/epsilon/before/dist/adapters/bun.js:222` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `listen` (1)

**Calls:**
- `(anonymous)` (1)

### `(module)`
`/tmp/keala-all-win.cDctk1/epsilon/bench/framework-compare/server.mjs:42` | Self: 0.0% (0us) | Total: 0.0% (2.1ms) | Samples: 0

**Calls:**
- `listen` (2)

### `startBunServer`
`/tmp/keala-all-win.cDctk1/epsilon/before/dist/adapters/bun.js:90` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `listen` (1)

**Calls:**
- `assertCanStart` (1)

### `registerDef`
`/tmp/keala-all-win.cDctk1/epsilon/before/dist/router/router.js:313` | Self: 0.0% (0us) | Total: 0.0% (994us) | Samples: 0

**Called by:**
- `routeShortcut` (1)

**Calls:**
- `bindDef` (1)

### `dispatchRequest`
`/tmp/keala-all-win.cDctk1/epsilon/before/dist/core/dispatch.js:223` | Self: 0.0% (0us) | Total: 2.8% (116.0ms) | Samples: 0

**Called by:**
- `#serve` (10)

**Calls:**
- `sourceMethod` (8)
- `sourceMethod` (2)

### `(module)`
`/tmp/keala-all-win.cDctk1/epsilon/before/dist/core/context/context.js:94` | Self: 0.0% (0us) | Total: 1.1% (46.5ms) | Samples: 0

**Calls:**
- `mergeProtos` (1)

### `internal:streams/operators`
`internal:streams/operators:2` | Self: 0.0% (0us) | Total: 0.0% (2.2ms) | Samples: 0

**Called by:**
- `anonymous` (2)

**Calls:**
- `anonymous` (2)

### `(module)`
`/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/_chunks/_url.mjs:185` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Calls:**
- `(anonymous)` (1)

### `internal:streams/destroy`
`internal:streams/destroy:2` | Self: 0.0% (0us) | Total: 0.0% (2.4ms) | Samples: 0

**Called by:**
- `anonymous` (2)

**Calls:**
- `anonymous` (2)

### `internal:streams/pipeline`
`internal:streams/pipeline:2` | Self: 0.0% (0us) | Total: 0.2% (9.5ms) | Samples: 0

**Called by:**
- `anonymous` (8)

**Calls:**
- `anonymous` (8)

### `(module)`
`/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/_chunks/_utils.mjs:6` | Self: 0.0% (0us) | Total: 0.5% (22.7ms) | Samples: 0

**Calls:**
- `(anonymous)` (19)

### `internal:primordials`
`internal:primordials:88` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `makeSafe` (1)

### `(module)`
`/tmp/keala-all-win.cDctk1/epsilon/bench/framework-compare/server.mjs:26` | Self: 0.0% (0us) | Total: 0.0% (994us) | Samples: 0

**Calls:**
- `routeShortcut` (1)

### `listen`
`/tmp/keala-all-win.cDctk1/epsilon/before/dist/core/app.js:253` | Self: 0.0% (0us) | Total: 0.0% (2.1ms) | Samples: 0

**Called by:**
- `(module)` (2)

**Calls:**
- `startBunServer` (1)
- `startBunServer` (1)

### `internal:streams/readable`
`internal:streams/readable:2` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `anonymous` (1)

### `sugarText`
`/tmp/keala-all-win.cDctk1/epsilon/before/dist/core/context/sugar.js:180` | Self: 0.0% (0us) | Total: 0.1% (7.1ms) | Samples: 0

**Called by:**
- `dispatchDirect` (3)

**Calls:**
- `clearStagedInPlace` (2)
- `clearStagedInPlace` (1)

### `node:url`
`node:url:2` | Self: 0.0% (0us) | Total: 0.1% (5.3ms) | Samples: 0

**Calls:**
- `anonymous` (1)

### `internal:fs/streams`
`internal:fs/streams:2` | Self: 0.0% (0us) | Total: 0.3% (16.0ms) | Samples: 0

**Called by:**
- `anonymous` (14)

**Calls:**
- `anonymous` (14)

### `sugarText`
`/tmp/keala-all-win.cDctk1/epsilon/before/dist/core/context/sugar.js:169` | Self: 0.0% (0us) | Total: 20.5% (841.4ms) | Samples: 0

**Called by:**
- `dispatchDirect` (85)

**Calls:**
- `textResponse` (84)
- `textResponse` (1)

### `(anonymous)`
`/tmp/keala-all-win.cDctk1/epsilon/before/dist/adapters/bun.js:57` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `startBunServer` (1)

**Calls:**
- `serve` (1)

### `internal:errors`
`internal:errors:2` | Self: 0.0% (0us) | Total: 0.0% (2.4ms) | Samples: 0

**Called by:**
- `anonymous` (2)

**Calls:**
- `anonymous` (2)

### `node:fs/promises`
`node:fs/promises:157` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `asyncWrap` (1)

### `internal:streams/compose`
`internal:streams/compose:2` | Self: 0.0% (0us) | Total: 0.2% (10.6ms) | Samples: 0

**Called by:**
- `anonymous` (9)

**Calls:**
- `anonymous` (9)

### `serve`
`/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/adapters/bun.mjs:72` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `(anonymous)` (1)

**Calls:**
- `serve` (1)

### `node:stream`
`node:stream:2` | Self: 0.0% (0us) | Total: 0.3% (14.1ms) | Samples: 0

**Called by:**
- `anonymous` (12)

**Calls:**
- `anonymous` (12)

### `(anonymous)`
`/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/_chunks/_url.mjs:78` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `(module)` (1)

**Calls:**
- `lazyInherit` (1)

### `bindDef`
`/tmp/keala-all-win.cDctk1/epsilon/before/dist/router/router.js:131` | Self: 0.0% (0us) | Total: 0.0% (994us) | Samples: 0

**Called by:**
- `registerDef` (1)

**Calls:**
- `indexPattern` (1)

### `makeSafe`
`internal:primordials:52` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `internal:primordials` (1)

**Calls:**
- `copyProps` (1)

### `internal:streams/end-of-stream`
`internal:streams/end-of-stream:17` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `anonymous` (1)

### `internal:streams/duplex`
`internal:streams/duplex:2` | Self: 0.0% (0us) | Total: 0.1% (5.9ms) | Samples: 0

**Called by:**
- `anonymous` (5)

**Calls:**
- `anonymous` (5)

### `internal:stream`
`internal:stream:2` | Self: 0.0% (0us) | Total: 0.3% (12.9ms) | Samples: 0

**Called by:**
- `anonymous` (11)

**Calls:**
- `anonymous` (11)

### `sugarText`
`/tmp/keala-all-win.cDctk1/epsilon/before/dist/core/context/sugar.js:165` | Self: 0.0% (0us) | Total: 1.1% (46.1ms) | Samples: 0

**Called by:**
- `dispatchDirect` (4)

**Calls:**
- `sourceMethod` (4)

### `dispatchRequest`
`/tmp/keala-all-win.cDctk1/epsilon/before/dist/core/dispatch.js:216` | Self: 0.0% (0us) | Total: 0.3% (16.1ms) | Samples: 0

**Called by:**
- `#serve` (3)

**Calls:**
- `matchRoute` (2)
- `matchRoute` (1)

### `(module)`
`/tmp/keala-all-win.cDctk1/epsilon/bench/framework-compare/server.mjs:24` | Self: 0.0% (0us) | Total: 0.0% (940us) | Samples: 0

**Calls:**
- `Keala` (1)

### `copyProps`
`internal:primordials:27` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `makeSafe` (1)

**Calls:**
- `defineProperty` (1)

## Files

| Self% | Self | File |
|------:|-----:|------|
| 26.3% | 1.07s | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/core/request-source.js` |
| 25.3% | 1.03s | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/adapters/bun.js` |
| 20.7% | 851.8ms | `[native code]` |
| 12.5% | 513.0ms | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/utils/url.js` |
| 7.2% | 299.1ms | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/core/dispatch.js` |
| 4.3% | 176.8ms | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/core/app.js` |
| 1.8% | 76.2ms | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/core/context/sugar.js` |
| 0.7% | 30.3ms | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/core/context/context.js` |
| 0.3% | 16.1ms | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/router/match.js` |
| 0.2% | 8.5ms | `/tmp/keala-all-win.cDctk1/epsilon/bench/framework-compare/server.mjs` |
| 0.0% | 2.5ms | `node:fs` |
| 0.0% | 1.3ms | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/core/compose.js` |
| 0.0% | 1.2ms | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/_chunks/_url.mjs` |
| 0.0% | 1.2ms | `internal:primordials` |
| 0.0% | 1.1ms | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/core/server-slot.js` |
| 0.0% | 1.1ms | `node:events` |
| 0.0% | 1.0ms | `node:fs/promises` |
| 0.0% | 994us | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/router/router.js` |
| 0.0% | 940us | `/tmp/keala-all-win.cDctk1/epsilon/before/dist/core/lifecycle.js` |
