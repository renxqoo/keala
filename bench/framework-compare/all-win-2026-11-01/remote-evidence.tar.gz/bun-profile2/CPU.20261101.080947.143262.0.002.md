# CPU Profile

| Duration | Samples | Interval | Functions |
|----------|---------|----------|----------|
| 4.04s | 365 | 1.0ms | 43 |

**Top 10:** `(anonymous)` 24.8%, `Response` 22.0%, `getPath` 20.5%, `getPath` 6.7%, `fetch` 6.3%, `#dispatch` 2.9%, `match2` 2.9%, `#dispatch` 2.6%, `Context` 2.3%, `(anonymous)` 1.9%

## Hot Functions (Self Time)

| Self% | Self | Total% | Total | Function | Location |
|------:|-----:|-------:|------:|----------|----------|
| 24.8% | 1.00s | 24.8% | 1.00s | `(anonymous)` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/hono/dist/context.js:55` |
| 22.0% | 891.2ms | 22.0% | 891.2ms | `Response` | `[native code]` |
| 20.5% | 832.9ms | 20.5% | 832.9ms | `getPath` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/hono/dist/utils/url.js:69` |
| 6.7% | 272.4ms | 6.7% | 272.4ms | `getPath` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/hono/dist/utils/url.js:70` |
| 6.3% | 257.4ms | 6.3% | 257.4ms | `fetch` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/hono/dist/hono-base.js:331` |
| 2.9% | 120.9ms | 32.3% | 1.30s | `#dispatch` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/hono/dist/hono-base.js:284` |
| 2.9% | 118.8ms | 2.9% | 118.8ms | `match2` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/hono/dist/router/reg-exp-router/matcher.js` |
| 2.6% | 106.3ms | 2.6% | 106.3ms | `#dispatch` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/hono/dist/hono-base.js:279` |
| 2.3% | 94.5ms | 29.2% | 1.18s | `Context` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/hono/dist/context.js:62` |
| 1.9% | 80.2ms | 1.9% | 80.2ms | `(anonymous)` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/hono/dist/context.js:14` |
| 1.7% | 70.8ms | 23.7% | 962.0ms | `text` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/hono/dist/context.js:357` |
| 1.0% | 42.4ms | 29.4% | 1.18s | `#dispatch` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/hono/dist/hono-base.js:282` |
| 0.8% | 36.1ms | 0.8% | 36.1ms | `getPath` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/hono/dist/utils/url.js` |
| 0.7% | 29.6ms | 4.4% | 179.2ms | `#dispatch` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/hono/dist/hono-base.js:283` |
| 0.7% | 29.4ms | 0.7% | 29.4ms | `test` | `[native code]` |
| 0.5% | 22.2ms | 0.5% | 22.2ms | `createNullObject` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/hono/dist/router/utils.js` |
| 0.1% | 7.1ms | 0.2% | 8.1ms | `anonymous` | `[native code]` |
| 0.1% | 6.6ms | 0.1% | 6.6ms | `(anonymous)` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/hono/dist/context.js:13` |
| 0.1% | 6.2ms | 0.1% | 6.2ms | `#dispatch` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/hono/dist/hono-base.js:302` |
| 0.1% | 5.8ms | 0.1% | 5.8ms | `getPath` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/hono/dist/utils/url.js:84` |
| 0.0% | 3.5ms | 0.0% | 3.5ms | `(anonymous)` | `/tmp/keala-all-win.cDctk1/epsilon/bench/framework-compare/server.mjs` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `#buildMatcher` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/hono/dist/router/reg-exp-router/router.js` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `#addRoute` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/hono/dist/hono-base.js` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `#dispatch` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/hono/dist/hono-base.js:289` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `text` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/hono/dist/context.js` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `bind` | `[native code]` |
| 0.0% | 963us | 0.0% | 963us | `Context` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/hono/dist/context.js` |

## Call Tree (Total Time)

| Total% | Total | Self% | Self | Function | Location |
|-------:|------:|------:|-----:|----------|----------|
| 32.3% | 1.30s | 2.9% | 120.9ms | `#dispatch` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/hono/dist/hono-base.js:284` |
| 29.4% | 1.18s | 1.0% | 42.4ms | `#dispatch` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/hono/dist/hono-base.js:282` |
| 29.2% | 1.18s | 2.3% | 94.5ms | `Context` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/hono/dist/context.js:62` |
| 24.8% | 1.00s | 24.8% | 1.00s | `(anonymous)` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/hono/dist/context.js:55` |
| 23.8% | 966.7ms | 0.0% | 0us | `#dispatch` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/hono/dist/hono-base.js:294` |
| 23.7% | 962.0ms | 1.7% | 70.8ms | `text` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/hono/dist/context.js:357` |
| 22.0% | 891.2ms | 22.0% | 891.2ms | `Response` | `[native code]` |
| 20.5% | 832.9ms | 20.5% | 832.9ms | `getPath` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/hono/dist/utils/url.js:69` |
| 6.7% | 272.4ms | 6.7% | 272.4ms | `getPath` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/hono/dist/utils/url.js:70` |
| 6.3% | 257.4ms | 6.3% | 257.4ms | `fetch` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/hono/dist/hono-base.js:331` |
| 4.4% | 179.2ms | 0.7% | 29.6ms | `#dispatch` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/hono/dist/hono-base.js:283` |
| 2.9% | 118.8ms | 2.9% | 118.8ms | `match2` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/hono/dist/router/reg-exp-router/matcher.js` |
| 2.6% | 106.3ms | 2.6% | 106.3ms | `#dispatch` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/hono/dist/hono-base.js:279` |
| 1.9% | 80.2ms | 1.9% | 80.2ms | `(anonymous)` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/hono/dist/context.js:14` |
| 0.8% | 36.1ms | 0.8% | 36.1ms | `getPath` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/hono/dist/utils/url.js` |
| 0.8% | 34.2ms | 0.0% | 0us | `(anonymous)` | `/tmp/keala-all-win.cDctk1/epsilon/bench/framework-compare/server.mjs:55` |
| 0.7% | 29.4ms | 0.0% | 0us | `match` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/hono/dist/router/smart-router/router.js:29` |
| 0.7% | 29.4ms | 0.0% | 0us | `add` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/hono/dist/router/reg-exp-router/router.js:71` |
| 0.7% | 29.4ms | 0.7% | 29.4ms | `test` | `[native code]` |
| 0.5% | 22.2ms | 0.0% | 0us | `(module)` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/hono/dist/router/reg-exp-router/router.js:17` |
| 0.5% | 22.2ms | 0.5% | 22.2ms | `createNullObject` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/hono/dist/router/utils.js` |
| 0.5% | 21.4ms | 0.0% | 0us | `bound match2` | `[native code]` |
| 0.2% | 8.1ms | 0.1% | 7.1ms | `anonymous` | `[native code]` |
| 0.1% | 7.1ms | 0.0% | 0us | `node:url` | `node:url:2` |
| 0.1% | 6.6ms | 0.1% | 6.6ms | `(anonymous)` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/hono/dist/context.js:13` |
| 0.1% | 6.2ms | 0.1% | 6.2ms | `#dispatch` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/hono/dist/hono-base.js:302` |
| 0.1% | 5.8ms | 0.1% | 5.8ms | `getPath` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/hono/dist/utils/url.js:84` |
| 0.0% | 3.5ms | 0.0% | 3.5ms | `(anonymous)` | `/tmp/keala-all-win.cDctk1/epsilon/bench/framework-compare/server.mjs` |
| 0.0% | 1.2ms | 0.0% | 0us | `buildAllMatchers` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/hono/dist/router/reg-exp-router/router.js:103` |
| 0.0% | 1.2ms | 0.0% | 0us | `match` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/hono/dist/router/smart-router/router.js:31` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `#buildMatcher` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/hono/dist/router/reg-exp-router/router.js` |
| 0.0% | 1.2ms | 0.0% | 0us | `match` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/hono/dist/router/reg-exp-router/matcher.js:5` |
| 0.0% | 1.1ms | 0.0% | 0us | `forEach` | `[native code]` |
| 0.0% | 1.1ms | 0.0% | 0us | `(anonymous)` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/hono/dist/hono-base.js:48` |
| 0.0% | 1.1ms | 0.0% | 0us | `(module)` | `/tmp/keala-all-win.cDctk1/epsilon/bench/framework-compare/server.mjs:55` |
| 0.0% | 1.1ms | 0.0% | 0us | `(anonymous)` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/hono/dist/hono-base.js:49` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `#addRoute` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/hono/dist/hono-base.js` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `#dispatch` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/hono/dist/hono-base.js:289` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `text` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/hono/dist/context.js` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `bind` | `[native code]` |
| 0.0% | 1.0ms | 0.0% | 0us | `node:path` | `node:path:2` |
| 0.0% | 1.0ms | 0.0% | 0us | `internal:validators` | `internal:validators:2` |
| 0.0% | 963us | 0.0% | 963us | `Context` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/hono/dist/context.js` |

## Function Details

### `(anonymous)`
`/tmp/keala-all-win.cDctk1/epsilon/node_modules/hono/dist/context.js:55` | Self: 24.8% (1.00s) | Total: 24.8% (1.00s) | Samples: 84

**Called by:**
- `Context` (84)

### `Response`
`[native code]` | Self: 22.0% (891.2ms) | Total: 22.0% (891.2ms) | Samples: 73

**Called by:**
- `text` (73)

### `getPath`
`/tmp/keala-all-win.cDctk1/epsilon/node_modules/hono/dist/utils/url.js:69` | Self: 20.5% (832.9ms) | Total: 20.5% (832.9ms) | Samples: 79

**Called by:**
- `#dispatch` (79)

### `getPath`
`/tmp/keala-all-win.cDctk1/epsilon/node_modules/hono/dist/utils/url.js:70` | Self: 6.7% (272.4ms) | Total: 6.7% (272.4ms) | Samples: 24

**Called by:**
- `#dispatch` (24)

### `fetch`
`/tmp/keala-all-win.cDctk1/epsilon/node_modules/hono/dist/hono-base.js:331` | Self: 6.3% (257.4ms) | Total: 6.3% (257.4ms) | Samples: 12

### `#dispatch`
`/tmp/keala-all-win.cDctk1/epsilon/node_modules/hono/dist/hono-base.js:284` | Self: 2.9% (120.9ms) | Total: 32.3% (1.30s) | Samples: 15

**Calls:**
- `Context` (104)
- `Context` (1)

### `match2`
`/tmp/keala-all-win.cDctk1/epsilon/node_modules/hono/dist/router/reg-exp-router/matcher.js` | Self: 2.9% (118.8ms) | Total: 2.9% (118.8ms) | Samples: 10

**Called by:**
- `#dispatch` (9)
- `bound match2` (1)

### `#dispatch`
`/tmp/keala-all-win.cDctk1/epsilon/node_modules/hono/dist/hono-base.js:279` | Self: 2.6% (106.3ms) | Total: 2.6% (106.3ms) | Samples: 14

### `Context`
`/tmp/keala-all-win.cDctk1/epsilon/node_modules/hono/dist/context.js:62` | Self: 2.3% (94.5ms) | Total: 29.2% (1.18s) | Samples: 6

**Called by:**
- `#dispatch` (104)

**Calls:**
- `(anonymous)` (84)
- `(anonymous)` (12)
- `(anonymous)` (2)

### `(anonymous)`
`/tmp/keala-all-win.cDctk1/epsilon/node_modules/hono/dist/context.js:14` | Self: 1.9% (80.2ms) | Total: 1.9% (80.2ms) | Samples: 12

**Called by:**
- `Context` (12)

### `text`
`/tmp/keala-all-win.cDctk1/epsilon/node_modules/hono/dist/context.js:357` | Self: 1.7% (70.8ms) | Total: 23.7% (962.0ms) | Samples: 7

**Called by:**
- `#dispatch` (79)
- `(anonymous)` (1)

**Calls:**
- `Response` (73)

### `#dispatch`
`/tmp/keala-all-win.cDctk1/epsilon/node_modules/hono/dist/hono-base.js:282` | Self: 1.0% (42.4ms) | Total: 29.4% (1.18s) | Samples: 5

**Calls:**
- `getPath` (79)
- `getPath` (24)
- `getPath` (6)
- `getPath` (1)

### `getPath`
`/tmp/keala-all-win.cDctk1/epsilon/node_modules/hono/dist/utils/url.js` | Self: 0.8% (36.1ms) | Total: 0.8% (36.1ms) | Samples: 6

**Called by:**
- `#dispatch` (6)

### `#dispatch`
`/tmp/keala-all-win.cDctk1/epsilon/node_modules/hono/dist/hono-base.js:283` | Self: 0.7% (29.6ms) | Total: 4.4% (179.2ms) | Samples: 3

**Calls:**
- `match2` (9)
- `match` (1)
- `match` (1)
- `bound match2` (1)

### `test`
`[native code]` | Self: 0.7% (29.4ms) | Total: 0.7% (29.4ms) | Samples: 1

**Called by:**
- `add` (1)

### `createNullObject`
`/tmp/keala-all-win.cDctk1/epsilon/node_modules/hono/dist/router/utils.js` | Self: 0.5% (22.2ms) | Total: 0.5% (22.2ms) | Samples: 1

**Called by:**
- `(module)` (1)

### `anonymous`
`[native code]` | Self: 0.1% (7.1ms) | Total: 0.2% (8.1ms) | Samples: 2

**Called by:**
- `node:url` (2)
- `internal:validators` (1)

**Calls:**
- `internal:validators` (1)

### `(anonymous)`
`/tmp/keala-all-win.cDctk1/epsilon/node_modules/hono/dist/context.js:13` | Self: 0.1% (6.6ms) | Total: 0.1% (6.6ms) | Samples: 2

**Called by:**
- `Context` (2)

### `#dispatch`
`/tmp/keala-all-win.cDctk1/epsilon/node_modules/hono/dist/hono-base.js:302` | Self: 0.1% (6.2ms) | Total: 0.1% (6.2ms) | Samples: 1

### `getPath`
`/tmp/keala-all-win.cDctk1/epsilon/node_modules/hono/dist/utils/url.js:84` | Self: 0.1% (5.8ms) | Total: 0.1% (5.8ms) | Samples: 1

**Called by:**
- `#dispatch` (1)

### `(anonymous)`
`/tmp/keala-all-win.cDctk1/epsilon/bench/framework-compare/server.mjs` | Self: 0.0% (3.5ms) | Total: 0.0% (3.5ms) | Samples: 1

**Called by:**
- `#dispatch` (1)

### `#buildMatcher`
`/tmp/keala-all-win.cDctk1/epsilon/node_modules/hono/dist/router/reg-exp-router/router.js` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `buildAllMatchers` (1)

### `#addRoute`
`/tmp/keala-all-win.cDctk1/epsilon/node_modules/hono/dist/hono-base.js` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `#dispatch`
`/tmp/keala-all-win.cDctk1/epsilon/node_modules/hono/dist/hono-base.js:289` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

### `text`
`/tmp/keala-all-win.cDctk1/epsilon/node_modules/hono/dist/context.js` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `#dispatch` (1)

### `bind`
`[native code]` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `node:path` (1)

### `Context`
`/tmp/keala-all-win.cDctk1/epsilon/node_modules/hono/dist/context.js` | Self: 0.0% (963us) | Total: 0.0% (963us) | Samples: 1

**Called by:**
- `#dispatch` (1)

### `(module)`
`/tmp/keala-all-win.cDctk1/epsilon/node_modules/hono/dist/router/reg-exp-router/router.js:17` | Self: 0.0% (0us) | Total: 0.5% (22.2ms) | Samples: 0

**Calls:**
- `createNullObject` (1)

### `add`
`/tmp/keala-all-win.cDctk1/epsilon/node_modules/hono/dist/router/reg-exp-router/router.js:71` | Self: 0.0% (0us) | Total: 0.7% (29.4ms) | Samples: 0

**Called by:**
- `match` (1)

**Calls:**
- `test` (1)

### `forEach`
`[native code]` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `(anonymous)` (1)

**Calls:**
- `(anonymous)` (1)

### `match`
`/tmp/keala-all-win.cDctk1/epsilon/node_modules/hono/dist/router/smart-router/router.js:29` | Self: 0.0% (0us) | Total: 0.7% (29.4ms) | Samples: 0

**Called by:**
- `#dispatch` (1)

**Calls:**
- `add` (1)

### `buildAllMatchers`
`/tmp/keala-all-win.cDctk1/epsilon/node_modules/hono/dist/router/reg-exp-router/router.js:103` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `match` (1)

**Calls:**
- `#buildMatcher` (1)

### `node:url`
`node:url:2` | Self: 0.0% (0us) | Total: 0.1% (7.1ms) | Samples: 0

**Calls:**
- `anonymous` (2)

### `bound match2`
`[native code]` | Self: 0.0% (0us) | Total: 0.5% (21.4ms) | Samples: 0

**Called by:**
- `#dispatch` (1)

**Calls:**
- `match2` (1)

### `internal:validators`
`internal:validators:2` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `anonymous` (1)

### `(anonymous)`
`/tmp/keala-all-win.cDctk1/epsilon/node_modules/hono/dist/hono-base.js:48` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `(module)` (1)

**Calls:**
- `forEach` (1)

### `match`
`/tmp/keala-all-win.cDctk1/epsilon/node_modules/hono/dist/router/smart-router/router.js:31` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `#dispatch` (1)

**Calls:**
- `match` (1)

### `#dispatch`
`/tmp/keala-all-win.cDctk1/epsilon/node_modules/hono/dist/hono-base.js:294` | Self: 0.0% (0us) | Total: 23.8% (966.7ms) | Samples: 0

**Calls:**
- `text` (79)
- `(anonymous)` (1)
- `text` (1)
- `(anonymous)` (1)

### `match`
`/tmp/keala-all-win.cDctk1/epsilon/node_modules/hono/dist/router/reg-exp-router/matcher.js:5` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `match` (1)

**Calls:**
- `buildAllMatchers` (1)

### `(module)`
`/tmp/keala-all-win.cDctk1/epsilon/bench/framework-compare/server.mjs:55` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Calls:**
- `(anonymous)` (1)

### `(anonymous)`
`/tmp/keala-all-win.cDctk1/epsilon/node_modules/hono/dist/hono-base.js:49` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `forEach` (1)

**Calls:**
- `#addRoute` (1)

### `node:path`
`node:path:2` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Calls:**
- `bind` (1)

### `(anonymous)`
`/tmp/keala-all-win.cDctk1/epsilon/bench/framework-compare/server.mjs:55` | Self: 0.0% (0us) | Total: 0.8% (34.2ms) | Samples: 0

**Called by:**
- `#dispatch` (1)

**Calls:**
- `text` (1)

## Files

| Self% | Self | File |
|------:|-----:|------|
| 31.1% | 1.25s | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/hono/dist/context.js` |
| 28.3% | 1.14s | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/hono/dist/utils/url.js` |
| 22.9% | 928.9ms | `[native code]` |
| 13.9% | 565.4ms | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/hono/dist/hono-base.js` |
| 2.9% | 118.8ms | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/hono/dist/router/reg-exp-router/matcher.js` |
| 0.5% | 22.2ms | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/hono/dist/router/utils.js` |
| 0.0% | 3.5ms | `/tmp/keala-all-win.cDctk1/epsilon/bench/framework-compare/server.mjs` |
| 0.0% | 1.2ms | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/hono/dist/router/reg-exp-router/router.js` |
