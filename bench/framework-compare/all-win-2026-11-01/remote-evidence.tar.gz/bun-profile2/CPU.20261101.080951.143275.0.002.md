# CPU Profile

| Duration | Samples | Interval | Functions |
|----------|---------|----------|----------|
| 4.11s | 572 | 1.0ms | 104 |

**Top 10:** `defineProperties` 23.5%, `Response` 18.0%, `H3Event` 15.5%, `URL` 11.6%, `(anonymous)` 4.9%, `URL` 3.1%, `pathname` 2.4%, `bound handler` 1.9%, `findRoute` 1.5%, `(anonymous)` 1.5%

## Hot Functions (Self Time)

| Self% | Self | Total% | Total | Function | Location |
|------:|-----:|-------:|------:|----------|----------|
| 23.5% | 969.9ms | 23.5% | 969.9ms | `defineProperties` | `[native code]` |
| 18.0% | 741.8ms | 18.0% | 741.8ms | `Response` | `[native code]` |
| 15.5% | 639.9ms | 31.5% | 1.29s | `H3Event` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/h3/dist/response.mjs:100` |
| 11.6% | 480.4ms | 11.6% | 480.4ms | `URL` | `[native code]` |
| 4.9% | 203.3ms | 28.5% | 1.17s | `(anonymous)` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/adapters/bun.mjs:35` |
| 3.1% | 127.8ms | 14.6% | 604.3ms | `URL` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/_chunks/_url.mjs:94` |
| 2.4% | 98.8ms | 2.4% | 98.8ms | `pathname` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/_chunks/_url.mjs:138` |
| 1.9% | 78.4ms | 6.1% | 252.0ms | `bound handler` | `[native code]` |
| 1.5% | 63.4ms | 1.5% | 63.4ms | `findRoute` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/rou3/dist/index.mjs` |
| 1.5% | 62.9ms | 1.5% | 62.9ms | `(anonymous)` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/adapters/bun.mjs:36` |
| 1.2% | 53.1ms | 1.2% | 53.1ms | `H3Event` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/h3/dist/response.mjs` |
| 1.2% | 52.0ms | 1.2% | 52.0ms | `lazyInherit` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/_chunks/_url.mjs` |
| 1.1% | 48.2ms | 19.1% | 790.1ms | `prepareResponse` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/h3/dist/response.mjs:378` |
| 1.1% | 46.4ms | 4.0% | 166.0ms | `~findRoute` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/h3/dist/cache.mjs:500` |
| 1.0% | 41.8ms | 1.0% | 41.8ms | `(anonymous)` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/adapters/bun.mjs:41` |
| 1.0% | 41.5ms | 1.0% | 41.5ms | `toResponse` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/h3/dist/response.mjs:305` |
| 0.9% | 39.9ms | 0.9% | 39.9ms | `prepareResponse` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/h3/dist/response.mjs:351` |
| 0.8% | 36.3ms | 0.8% | 36.3ms | `get pathname` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/_chunks/_url.mjs:138` |
| 0.8% | 35.4ms | 0.8% | 36.7ms | `H3Event` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/h3/dist/response.mjs:102` |
| 0.7% | 31.8ms | 0.7% | 31.8ms | `URL` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/_chunks/_url.mjs:100` |
| 0.6% | 26.2ms | 0.6% | 26.2ms | `H3Event` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/h3/dist/response.mjs:95` |
| 0.5% | 24.1ms | 2.7% | 112.2ms | `anonymous` | `[native code]` |
| 0.4% | 20.3ms | 0.4% | 20.3ms | `toNativeResponse` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/_chunks/_utils2.mjs` |
| 0.4% | 18.7ms | 0.4% | 18.7ms | `URL` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/_chunks/_url.mjs:90` |
| 0.4% | 17.1ms | 0.4% | 17.1ms | `prepareResponse` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/h3/dist/response.mjs` |
| 0.3% | 16.0ms | 0.3% | 16.0ms | `routeHandler` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/h3/dist/cache.mjs:423` |
| 0.2% | 11.5ms | 0.2% | 11.5ms | `~request` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/h3/dist/cache.mjs` |
| 0.2% | 11.2ms | 0.2% | 11.2ms | `~request` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/h3/dist/cache.mjs:403` |
| 0.2% | 10.9ms | 66.0% | 2.71s | `(anonymous)` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/adapters/bun.mjs:52` |
| 0.2% | 10.1ms | 0.6% | 26.1ms | `handler` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/h3/dist/cache.mjs:386` |
| 0.1% | 6.8ms | 0.1% | 6.8ms | `e` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/rou3/dist/index.mjs:2` |
| 0.1% | 6.2ms | 0.2% | 8.2ms | `prepareResponse` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/h3/dist/response.mjs:374` |
| 0.1% | 6.1ms | 0.1% | 6.1ms | `toNativeResponse` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/_chunks/_utils2.mjs:57` |
| 0.1% | 4.9ms | 0.1% | 4.9ms | `URL` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/_chunks/_url.mjs` |
| 0.0% | 3.2ms | 0.0% | 3.2ms | `toResponse` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/h3/dist/response.mjs:314` |
| 0.0% | 3.1ms | 0.0% | 3.1ms | `findRoute` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/rou3/dist/index.mjs:682` |
| 0.0% | 2.1ms | 0.0% | 2.1ms | `get pathname` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/_chunks/_url.mjs` |
| 0.0% | 2.0ms | 0.0% | 2.0ms | `prepareResponseBody` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/h3/dist/response.mjs` |
| 0.0% | 1.9ms | 6.6% | 273.5ms | `~request` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/h3/dist/cache.mjs:399` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `e` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/rou3/dist/index.mjs` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `call` | `[native code]` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `Writable` | `internal:streams/writable` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `BunServer` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/adapters/bun.mjs` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `includes` | `[native code]` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `_add` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/rou3/dist/index.mjs` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `node:events` | `node:events:405` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `createSafeIterator` | `internal:primordials` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `on` | `[native code]` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `@lazy` | `[native code]` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `serve` | `[native code]` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `H3` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/h3/dist/cache.mjs` |
| 0.0% | 999us | 0.0% | 999us | `prepareResponse` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/h3/dist/response.mjs:381` |
| 0.0% | 932us | 0.0% | 932us | `internal:shared` | `internal:shared:33` |
| 0.0% | 926us | 0.0% | 926us | `setName` | `node:fs` |
| 0.0% | 926us | 0.0% | 926us | `Headers` | `[native code]` |
| 0.0% | 918us | 4.0% | 166.9ms | `handler` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/h3/dist/cache.mjs:381` |

## Call Tree (Total Time)

| Total% | Total | Self% | Self | Function | Location |
|-------:|------:|------:|-----:|----------|----------|
| 66.0% | 2.71s | 0.2% | 10.9ms | `(anonymous)` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/adapters/bun.mjs:52` |
| 36.6% | 1.50s | 0.0% | 0us | `~request` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/h3/dist/cache.mjs:389` |
| 31.5% | 1.29s | 15.5% | 639.9ms | `H3Event` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/h3/dist/response.mjs:100` |
| 28.5% | 1.17s | 4.9% | 203.3ms | `(anonymous)` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/adapters/bun.mjs:35` |
| 23.5% | 969.9ms | 23.5% | 969.9ms | `defineProperties` | `[native code]` |
| 20.8% | 856.4ms | 0.0% | 0us | `toResponse` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/h3/dist/response.mjs:309` |
| 19.1% | 790.1ms | 1.1% | 48.2ms | `prepareResponse` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/h3/dist/response.mjs:378` |
| 18.0% | 741.8ms | 18.0% | 741.8ms | `Response` | `[native code]` |
| 14.6% | 604.3ms | 3.1% | 127.8ms | `URL` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/_chunks/_url.mjs:94` |
| 11.6% | 480.4ms | 11.6% | 480.4ms | `URL` | `[native code]` |
| 6.6% | 273.5ms | 0.0% | 1.9ms | `~request` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/h3/dist/cache.mjs:399` |
| 6.1% | 252.0ms | 1.9% | 78.4ms | `bound handler` | `[native code]` |
| 4.0% | 166.9ms | 0.0% | 918us | `handler` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/h3/dist/cache.mjs:381` |
| 4.0% | 166.0ms | 1.1% | 46.4ms | `~findRoute` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/h3/dist/cache.mjs:500` |
| 2.7% | 112.2ms | 0.5% | 24.1ms | `anonymous` | `[native code]` |
| 2.4% | 98.8ms | 2.4% | 98.8ms | `pathname` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/_chunks/_url.mjs:138` |
| 2.0% | 84.4ms | 0.0% | 0us | `H3Event` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/h3/dist/response.mjs:101` |
| 1.5% | 63.4ms | 1.5% | 63.4ms | `findRoute` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/rou3/dist/index.mjs` |
| 1.5% | 62.9ms | 1.5% | 62.9ms | `(anonymous)` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/adapters/bun.mjs:36` |
| 1.2% | 53.1ms | 1.2% | 53.1ms | `H3Event` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/h3/dist/response.mjs` |
| 1.2% | 52.0ms | 1.2% | 52.0ms | `lazyInherit` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/_chunks/_url.mjs` |
| 1.2% | 52.0ms | 0.0% | 0us | `(module)` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/_chunks/_url.mjs:185` |
| 1.2% | 52.0ms | 0.0% | 0us | `(anonymous)` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/_chunks/_url.mjs:78` |
| 1.0% | 41.8ms | 1.0% | 41.8ms | `(anonymous)` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/adapters/bun.mjs:41` |
| 1.0% | 41.5ms | 1.0% | 41.5ms | `toResponse` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/h3/dist/response.mjs:305` |
| 0.9% | 39.9ms | 0.9% | 39.9ms | `prepareResponse` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/h3/dist/response.mjs:351` |
| 0.8% | 36.7ms | 0.8% | 35.4ms | `H3Event` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/h3/dist/response.mjs:102` |
| 0.8% | 36.3ms | 0.8% | 36.3ms | `get pathname` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/_chunks/_url.mjs:138` |
| 0.7% | 31.8ms | 0.7% | 31.8ms | `URL` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/_chunks/_url.mjs:100` |
| 0.6% | 26.2ms | 0.6% | 26.2ms | `H3Event` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/h3/dist/response.mjs:95` |
| 0.6% | 26.1ms | 0.2% | 10.1ms | `handler` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/h3/dist/cache.mjs:386` |
| 0.5% | 24.6ms | 0.0% | 0us | `(anonymous)` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/_chunks/_utils.mjs:6` |
| 0.5% | 24.6ms | 0.0% | 0us | `(module)` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/_chunks/_utils.mjs:6` |
| 0.5% | 24.6ms | 0.0% | 0us | `(anonymous)` | `[native code]` |
| 0.4% | 20.3ms | 0.4% | 20.3ms | `toNativeResponse` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/_chunks/_utils2.mjs` |
| 0.4% | 19.1ms | 0.0% | 0us | `get WriteStream` | `node:fs:644` |
| 0.4% | 18.7ms | 0.4% | 18.7ms | `URL` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/_chunks/_url.mjs:90` |
| 0.4% | 17.1ms | 0.4% | 17.1ms | `prepareResponse` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/h3/dist/response.mjs` |
| 0.3% | 16.0ms | 0.0% | 0us | `(anonymous)` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/h3/dist/cache.mjs:416` |
| 0.3% | 16.0ms | 0.3% | 16.0ms | `routeHandler` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/h3/dist/cache.mjs:423` |
| 0.3% | 15.8ms | 0.0% | 0us | `internal:fs/streams` | `internal:fs/streams:2` |
| 0.3% | 13.5ms | 0.0% | 0us | `node:stream` | `node:stream:2` |
| 0.2% | 12.2ms | 0.0% | 0us | `internal:stream` | `internal:stream:2` |
| 0.2% | 11.5ms | 0.2% | 11.5ms | `~request` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/h3/dist/cache.mjs` |
| 0.2% | 11.2ms | 0.2% | 11.2ms | `~request` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/h3/dist/cache.mjs:403` |
| 0.2% | 10.0ms | 0.0% | 0us | `internal:streams/compose` | `internal:streams/compose:2` |
| 0.2% | 8.7ms | 0.0% | 0us | `internal:streams/pipeline` | `internal:streams/pipeline:2` |
| 0.2% | 8.4ms | 0.0% | 0us | `H3Event` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/h3/dist/response.mjs:96` |
| 0.2% | 8.2ms | 0.1% | 6.2ms | `prepareResponse` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/h3/dist/response.mjs:374` |
| 0.2% | 8.2ms | 0.0% | 0us | `bound fetch` | `[native code]` |
| 0.1% | 7.2ms | 0.0% | 0us | `node:url` | `node:url:2` |
| 0.1% | 6.8ms | 0.1% | 6.8ms | `e` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/rou3/dist/index.mjs:2` |
| 0.1% | 6.1ms | 0.1% | 6.1ms | `toNativeResponse` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/_chunks/_utils2.mjs:57` |
| 0.1% | 5.3ms | 0.0% | 0us | `internal:streams/duplex` | `internal:streams/duplex:2` |
| 0.1% | 4.9ms | 0.1% | 4.9ms | `URL` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/_chunks/_url.mjs` |
| 0.0% | 3.9ms | 0.0% | 0us | `(module)` | `/tmp/keala-all-win.cDctk1/epsilon/bench/framework-compare/server.mjs:100` |
| 0.0% | 3.4ms | 0.0% | 0us | `internal:errors` | `internal:errors:2` |
| 0.0% | 3.4ms | 0.0% | 0us | `internal:streams/destroy` | `internal:streams/destroy:2` |
| 0.0% | 3.2ms | 0.0% | 3.2ms | `toResponse` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/h3/dist/response.mjs:314` |
| 0.0% | 3.1ms | 0.0% | 3.1ms | `findRoute` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/rou3/dist/index.mjs:682` |
| 0.0% | 2.2ms | 0.0% | 0us | `serve` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/adapters/bun.mjs:7` |
| 0.0% | 2.2ms | 0.0% | 0us | `(module)` | `/tmp/keala-all-win.cDctk1/epsilon/bench/framework-compare/server.mjs:98` |
| 0.0% | 2.1ms | 0.0% | 2.1ms | `get pathname` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/_chunks/_url.mjs` |
| 0.0% | 2.1ms | 0.0% | 0us | `internal:streams/legacy` | `internal:streams/legacy:2` |
| 0.0% | 2.0ms | 0.0% | 2.0ms | `prepareResponseBody` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/h3/dist/response.mjs` |
| 0.0% | 1.5ms | 0.0% | 1.5ms | `e` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/rou3/dist/index.mjs` |
| 0.0% | 1.2ms | 0.0% | 0us | `bound call` | `[native code]` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `call` | `[native code]` |
| 0.0% | 1.2ms | 0.0% | 0us | `internal:primordials` | `internal:primordials:83` |
| 0.0% | 1.2ms | 0.0% | 0us | `makeSafe` | `internal:primordials:35` |
| 0.0% | 1.2ms | 0.0% | 0us | `internal:stream` | `internal:stream:46` |
| 0.0% | 1.2ms | 0.0% | 0us | `WriteStream` | `internal:fs/streams:259` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `Writable` | `internal:streams/writable` |
| 0.0% | 1.2ms | 0.0% | 0us | `internal:streams/end-of-stream` | `internal:streams/end-of-stream:17` |
| 0.0% | 1.2ms | 0.0% | 0us | `internal:streams/operators` | `internal:streams/operators:2` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `BunServer` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/adapters/bun.mjs` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `includes` | `[native code]` |
| 0.0% | 1.2ms | 0.0% | 1.2ms | `_add` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/rou3/dist/index.mjs` |
| 0.0% | 1.2ms | 0.0% | 0us | `~addRoute` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/h3/dist/cache.mjs:505` |
| 0.0% | 1.2ms | 0.0% | 0us | `addRoute` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/rou3/dist/index.mjs:407` |
| 0.0% | 1.2ms | 0.0% | 0us | `on` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/h3/dist/cache.mjs:484` |
| 0.0% | 1.2ms | 0.0% | 0us | `(module)` | `/tmp/keala-all-win.cDctk1/epsilon/bench/framework-compare/server.mjs:83` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `node:events` | `node:events:405` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `createSafeIterator` | `internal:primordials` |
| 0.0% | 1.1ms | 0.0% | 0us | `internal:primordials` | `internal:primordials:54` |
| 0.0% | 1.1ms | 0.0% | 0us | `(module)` | `/tmp/keala-all-win.cDctk1/epsilon/bench/framework-compare/server.mjs:114` |
| 0.0% | 1.1ms | 0.0% | 1.1ms | `on` | `[native code]` |
| 0.0% | 1.0ms | 0.0% | 0us | `internal:fs/binding` | `internal:fs/binding:3` |
| 0.0% | 1.0ms | 0.0% | 0us | `node:fs` | `node:fs:8` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `@lazy` | `[native code]` |
| 0.0% | 1.0ms | 0.0% | 0us | `serve` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/adapters/bun.mjs:72` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `serve` | `[native code]` |
| 0.0% | 1.0ms | 0.0% | 0us | `BunServer` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/adapters/bun.mjs:69` |
| 0.0% | 1.0ms | 0.0% | 0us | `(module)` | `/tmp/keala-all-win.cDctk1/epsilon/bench/framework-compare/server.mjs:81` |
| 0.0% | 1.0ms | 0.0% | 1.0ms | `H3` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/h3/dist/cache.mjs` |
| 0.0% | 999us | 0.0% | 999us | `prepareResponse` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/h3/dist/response.mjs:381` |
| 0.0% | 966us | 0.0% | 0us | `internal:streams/readable` | `internal:streams/readable:14` |
| 0.0% | 932us | 0.0% | 932us | `internal:shared` | `internal:shared:33` |
| 0.0% | 932us | 0.0% | 0us | `internal:validators` | `internal:validators:2` |
| 0.0% | 926us | 0.0% | 926us | `Headers` | `[native code]` |
| 0.0% | 926us | 0.0% | 926us | `setName` | `node:fs` |
| 0.0% | 926us | 0.0% | 0us | `node:fs` | `node:fs:679` |
| 0.0% | 926us | 0.0% | 0us | `(module)` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/h3/dist/response.mjs:409` |
| 0.0% | 926us | 0.0% | 0us | `FrozenHeaders` | `[native code]` |

## Function Details

### `defineProperties`
`[native code]` | Self: 23.5% (969.9ms) | Total: 23.5% (969.9ms) | Samples: 126

**Called by:**
- `(anonymous)` (126)

### `Response`
`[native code]` | Self: 18.0% (741.8ms) | Total: 18.0% (741.8ms) | Samples: 100

**Called by:**
- `prepareResponse` (100)

### `H3Event`
`/tmp/keala-all-win.cDctk1/epsilon/node_modules/h3/dist/response.mjs:100` | Self: 15.5% (639.9ms) | Total: 31.5% (1.29s) | Samples: 87

**Called by:**
- `~request` (158)

**Calls:**
- `URL` (67)
- `URL` (2)
- `URL` (1)
- `URL` (1)

### `URL`
`[native code]` | Self: 11.6% (480.4ms) | Total: 11.6% (480.4ms) | Samples: 51

**Called by:**
- `URL` (49)
- `(module)` (2)

### `(anonymous)`
`/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/adapters/bun.mjs:35` | Self: 4.9% (203.3ms) | Total: 28.5% (1.17s) | Samples: 39

**Calls:**
- `defineProperties` (126)

### `URL`
`/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/_chunks/_url.mjs:94` | Self: 3.1% (127.8ms) | Total: 14.6% (604.3ms) | Samples: 18

**Called by:**
- `H3Event` (67)

**Calls:**
- `URL` (49)

### `pathname`
`/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/_chunks/_url.mjs:138` | Self: 2.4% (98.8ms) | Total: 2.4% (98.8ms) | Samples: 20

**Called by:**
- `H3Event` (12)
- `~findRoute` (8)

### `bound handler`
`[native code]` | Self: 1.9% (78.4ms) | Total: 6.1% (252.0ms) | Samples: 4

**Called by:**
- `~request` (28)

**Calls:**
- `handler` (23)
- `handler` (1)

### `findRoute`
`/tmp/keala-all-win.cDctk1/epsilon/node_modules/rou3/dist/index.mjs` | Self: 1.5% (63.4ms) | Total: 1.5% (63.4ms) | Samples: 7

**Called by:**
- `~findRoute` (7)

### `(anonymous)`
`/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/adapters/bun.mjs:36` | Self: 1.5% (62.9ms) | Total: 1.5% (62.9ms) | Samples: 6

### `H3Event`
`/tmp/keala-all-win.cDctk1/epsilon/node_modules/h3/dist/response.mjs` | Self: 1.2% (53.1ms) | Total: 1.2% (53.1ms) | Samples: 6

**Called by:**
- `~request` (6)

### `lazyInherit`
`/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/_chunks/_url.mjs` | Self: 1.2% (52.0ms) | Total: 1.2% (52.0ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `prepareResponse`
`/tmp/keala-all-win.cDctk1/epsilon/node_modules/h3/dist/response.mjs:378` | Self: 1.1% (48.2ms) | Total: 19.1% (790.1ms) | Samples: 9

**Called by:**
- `toResponse` (109)

**Calls:**
- `Response` (100)

### `~findRoute`
`/tmp/keala-all-win.cDctk1/epsilon/node_modules/h3/dist/cache.mjs:500` | Self: 1.1% (46.4ms) | Total: 4.0% (166.0ms) | Samples: 7

**Called by:**
- `handler` (24)

**Calls:**
- `pathname` (8)
- `findRoute` (7)
- `findRoute` (1)
- `get pathname` (1)

### `(anonymous)`
`/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/adapters/bun.mjs:41` | Self: 1.0% (41.8ms) | Total: 1.0% (41.8ms) | Samples: 6

### `toResponse`
`/tmp/keala-all-win.cDctk1/epsilon/node_modules/h3/dist/response.mjs:305` | Self: 1.0% (41.5ms) | Total: 1.0% (41.5ms) | Samples: 6

**Called by:**
- `(anonymous)` (6)

### `prepareResponse`
`/tmp/keala-all-win.cDctk1/epsilon/node_modules/h3/dist/response.mjs:351` | Self: 0.9% (39.9ms) | Total: 0.9% (39.9ms) | Samples: 7

**Called by:**
- `toResponse` (7)

### `get pathname`
`/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/_chunks/_url.mjs:138` | Self: 0.8% (36.3ms) | Total: 0.8% (36.3ms) | Samples: 4

**Called by:**
- `H3Event` (4)

### `H3Event`
`/tmp/keala-all-win.cDctk1/epsilon/node_modules/h3/dist/response.mjs:102` | Self: 0.8% (35.4ms) | Total: 0.8% (36.7ms) | Samples: 3

**Called by:**
- `~request` (4)

**Calls:**
- `includes` (1)

### `URL`
`/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/_chunks/_url.mjs:100` | Self: 0.7% (31.8ms) | Total: 0.7% (31.8ms) | Samples: 1

**Called by:**
- `H3Event` (1)

### `H3Event`
`/tmp/keala-all-win.cDctk1/epsilon/node_modules/h3/dist/response.mjs:95` | Self: 0.6% (26.2ms) | Total: 0.6% (26.2ms) | Samples: 3

**Called by:**
- `~request` (3)

### `anonymous`
`[native code]` | Self: 0.5% (24.1ms) | Total: 2.7% (112.2ms) | Samples: 16

**Called by:**
- `get WriteStream` (16)
- `internal:fs/streams` (14)
- `node:stream` (12)
- `internal:stream` (11)
- `internal:streams/compose` (9)
- `internal:streams/pipeline` (8)
- `internal:streams/duplex` (5)
- `(anonymous)` (4)
- `internal:streams/destroy` (3)
- `internal:errors` (3)
- `node:url` (2)
- `internal:streams/legacy` (2)
- `internal:stream` (1)
- `internal:streams/end-of-stream` (1)
- `internal:streams/operators` (1)
- `node:fs` (1)
- `internal:streams/readable` (1)
- `internal:validators` (1)

**Calls:**
- `internal:fs/streams` (14)
- `node:stream` (12)
- `internal:stream` (11)
- `internal:streams/compose` (9)
- `internal:streams/pipeline` (8)
- `internal:streams/duplex` (5)
- `internal:streams/destroy` (3)
- `internal:errors` (3)
- `internal:streams/legacy` (2)
- `internal:stream` (1)
- `internal:fs/binding` (1)
- `internal:streams/end-of-stream` (1)
- `internal:shared` (1)
- `internal:streams/operators` (1)
- `node:fs` (1)
- `internal:streams/readable` (1)
- `internal:primordials` (1)
- `internal:primordials` (1)
- `node:events` (1)
- `node:fs` (1)
- `internal:validators` (1)

### `toNativeResponse`
`/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/_chunks/_utils2.mjs` | Self: 0.4% (20.3ms) | Total: 0.4% (20.3ms) | Samples: 1

### `URL`
`/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/_chunks/_url.mjs:90` | Self: 0.4% (18.7ms) | Total: 0.4% (18.7ms) | Samples: 2

**Called by:**
- `H3Event` (2)

### `prepareResponse`
`/tmp/keala-all-win.cDctk1/epsilon/node_modules/h3/dist/response.mjs` | Self: 0.4% (17.1ms) | Total: 0.4% (17.1ms) | Samples: 2

**Called by:**
- `toResponse` (2)

### `routeHandler`
`/tmp/keala-all-win.cDctk1/epsilon/node_modules/h3/dist/cache.mjs:423` | Self: 0.3% (16.0ms) | Total: 0.3% (16.0ms) | Samples: 2

**Called by:**
- `(anonymous)` (2)

### `~request`
`/tmp/keala-all-win.cDctk1/epsilon/node_modules/h3/dist/cache.mjs` | Self: 0.2% (11.5ms) | Total: 0.2% (11.5ms) | Samples: 2

**Called by:**
- `(anonymous)` (2)

### `~request`
`/tmp/keala-all-win.cDctk1/epsilon/node_modules/h3/dist/cache.mjs:403` | Self: 0.2% (11.2ms) | Total: 0.2% (11.2ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `(anonymous)`
`/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/adapters/bun.mjs:52` | Self: 0.2% (10.9ms) | Total: 66.0% (2.71s) | Samples: 1

**Calls:**
- `~request` (191)
- `toResponse` (119)
- `~request` (34)
- `toResponse` (6)
- `bound fetch` (5)
- `~request` (2)
- `~request` (1)
- `toResponse` (1)

### `handler`
`/tmp/keala-all-win.cDctk1/epsilon/node_modules/h3/dist/cache.mjs:386` | Self: 0.2% (10.1ms) | Total: 0.6% (26.1ms) | Samples: 1

**Called by:**
- `~request` (2)
- `bound handler` (1)

**Calls:**
- `(anonymous)` (2)

### `e`
`/tmp/keala-all-win.cDctk1/epsilon/node_modules/rou3/dist/index.mjs:2` | Self: 0.1% (6.8ms) | Total: 0.1% (6.8ms) | Samples: 4

**Called by:**
- `H3Event` (4)

### `prepareResponse`
`/tmp/keala-all-win.cDctk1/epsilon/node_modules/h3/dist/response.mjs:374` | Self: 0.1% (6.2ms) | Total: 0.2% (8.2ms) | Samples: 3

**Called by:**
- `toResponse` (4)

**Calls:**
- `prepareResponseBody` (1)

### `toNativeResponse`
`/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/_chunks/_utils2.mjs:57` | Self: 0.1% (6.1ms) | Total: 0.1% (6.1ms) | Samples: 2

### `URL`
`/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/_chunks/_url.mjs` | Self: 0.1% (4.9ms) | Total: 0.1% (4.9ms) | Samples: 1

**Called by:**
- `H3Event` (1)

### `toResponse`
`/tmp/keala-all-win.cDctk1/epsilon/node_modules/h3/dist/response.mjs:314` | Self: 0.0% (3.2ms) | Total: 0.0% (3.2ms) | Samples: 1

**Called by:**
- `(anonymous)` (1)

### `findRoute`
`/tmp/keala-all-win.cDctk1/epsilon/node_modules/rou3/dist/index.mjs:682` | Self: 0.0% (3.1ms) | Total: 0.0% (3.1ms) | Samples: 1

**Called by:**
- `~findRoute` (1)

### `get pathname`
`/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/_chunks/_url.mjs` | Self: 0.0% (2.1ms) | Total: 0.0% (2.1ms) | Samples: 1

**Called by:**
- `~findRoute` (1)

### `prepareResponseBody`
`/tmp/keala-all-win.cDctk1/epsilon/node_modules/h3/dist/response.mjs` | Self: 0.0% (2.0ms) | Total: 0.0% (2.0ms) | Samples: 1

**Called by:**
- `prepareResponse` (1)

### `~request`
`/tmp/keala-all-win.cDctk1/epsilon/node_modules/h3/dist/cache.mjs:399` | Self: 0.0% (1.9ms) | Total: 6.6% (273.5ms) | Samples: 2

**Called by:**
- `(anonymous)` (34)

**Calls:**
- `bound handler` (28)
- `handler` (2)
- `handler` (2)

### `e`
`/tmp/keala-all-win.cDctk1/epsilon/node_modules/rou3/dist/index.mjs` | Self: 0.0% (1.5ms) | Total: 0.0% (1.5ms) | Samples: 1

**Called by:**
- `H3Event` (1)

### `call`
`[native code]` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `bound call` (1)

### `Writable`
`internal:streams/writable` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `WriteStream` (1)

### `BunServer`
`/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/adapters/bun.mjs` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `serve` (1)

### `includes`
`[native code]` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `H3Event` (1)

### `_add`
`/tmp/keala-all-win.cDctk1/epsilon/node_modules/rou3/dist/index.mjs` | Self: 0.0% (1.2ms) | Total: 0.0% (1.2ms) | Samples: 1

**Called by:**
- `addRoute` (1)

### `node:events`
`node:events:405` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `anonymous` (1)

### `createSafeIterator`
`internal:primordials` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `internal:primordials` (1)

### `on`
`[native code]` | Self: 0.0% (1.1ms) | Total: 0.0% (1.1ms) | Samples: 1

**Called by:**
- `(module)` (1)

### `@lazy`
`[native code]` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `internal:fs/binding` (1)

### `serve`
`[native code]` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `serve` (1)

### `H3`
`/tmp/keala-all-win.cDctk1/epsilon/node_modules/h3/dist/cache.mjs` | Self: 0.0% (1.0ms) | Total: 0.0% (1.0ms) | Samples: 1

**Called by:**
- `(module)` (1)

### `prepareResponse`
`/tmp/keala-all-win.cDctk1/epsilon/node_modules/h3/dist/response.mjs:381` | Self: 0.0% (999us) | Total: 0.0% (999us) | Samples: 1

**Called by:**
- `toResponse` (1)

### `internal:shared`
`internal:shared:33` | Self: 0.0% (932us) | Total: 0.0% (932us) | Samples: 1

**Called by:**
- `anonymous` (1)

### `setName`
`node:fs` | Self: 0.0% (926us) | Total: 0.0% (926us) | Samples: 1

**Called by:**
- `node:fs` (1)

### `Headers`
`[native code]` | Self: 0.0% (926us) | Total: 0.0% (926us) | Samples: 1

**Called by:**
- `FrozenHeaders` (1)

### `handler`
`/tmp/keala-all-win.cDctk1/epsilon/node_modules/h3/dist/cache.mjs:381` | Self: 0.0% (918us) | Total: 4.0% (166.9ms) | Samples: 1

**Called by:**
- `bound handler` (23)
- `~request` (2)

**Calls:**
- `~findRoute` (24)

### `internal:streams/end-of-stream`
`internal:streams/end-of-stream:17` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `anonymous` (1)

### `node:fs`
`node:fs:8` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `anonymous` (1)

### `(module)`
`/tmp/keala-all-win.cDctk1/epsilon/bench/framework-compare/server.mjs:114` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Calls:**
- `on` (1)

### `(module)`
`/tmp/keala-all-win.cDctk1/epsilon/bench/framework-compare/server.mjs:98` | Self: 0.0% (0us) | Total: 0.0% (2.2ms) | Samples: 0

**Calls:**
- `serve` (2)

### `toResponse`
`/tmp/keala-all-win.cDctk1/epsilon/node_modules/h3/dist/response.mjs:309` | Self: 0.0% (0us) | Total: 20.8% (856.4ms) | Samples: 0

**Called by:**
- `(anonymous)` (119)
- `bound fetch` (4)

**Calls:**
- `prepareResponse` (109)
- `prepareResponse` (7)
- `prepareResponse` (4)
- `prepareResponse` (2)
- `prepareResponse` (1)

### `internal:streams/duplex`
`internal:streams/duplex:2` | Self: 0.0% (0us) | Total: 0.1% (5.3ms) | Samples: 0

**Called by:**
- `anonymous` (5)

**Calls:**
- `anonymous` (5)

### `(module)`
`/tmp/keala-all-win.cDctk1/epsilon/node_modules/h3/dist/response.mjs:409` | Self: 0.0% (0us) | Total: 0.0% (926us) | Samples: 0

**Calls:**
- `FrozenHeaders` (1)

### `(anonymous)`
`/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/_chunks/_utils.mjs:6` | Self: 0.0% (0us) | Total: 0.5% (24.6ms) | Samples: 0

**Called by:**
- `(module)` (21)

**Calls:**
- `(anonymous)` (21)

### `internal:primordials`
`internal:primordials:83` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `makeSafe` (1)

### `node:url`
`node:url:2` | Self: 0.0% (0us) | Total: 0.1% (7.2ms) | Samples: 0

**Calls:**
- `anonymous` (2)

### `internal:streams/legacy`
`internal:streams/legacy:2` | Self: 0.0% (0us) | Total: 0.0% (2.1ms) | Samples: 0

**Called by:**
- `anonymous` (2)

**Calls:**
- `anonymous` (2)

### `bound call`
`[native code]` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `makeSafe` (1)

**Calls:**
- `call` (1)

### `WriteStream`
`internal:fs/streams:259` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `(anonymous)` (1)

**Calls:**
- `Writable` (1)

### `get WriteStream`
`node:fs:644` | Self: 0.0% (0us) | Total: 0.4% (19.1ms) | Samples: 0

**Called by:**
- `(anonymous)` (16)

**Calls:**
- `anonymous` (16)

### `internal:stream`
`internal:stream:2` | Self: 0.0% (0us) | Total: 0.2% (12.2ms) | Samples: 0

**Called by:**
- `anonymous` (11)

**Calls:**
- `anonymous` (11)

### `(module)`
`/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/_chunks/_url.mjs:185` | Self: 0.0% (0us) | Total: 1.2% (52.0ms) | Samples: 0

**Calls:**
- `(anonymous)` (1)

### `(module)`
`/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/_chunks/_utils.mjs:6` | Self: 0.0% (0us) | Total: 0.5% (24.6ms) | Samples: 0

**Calls:**
- `(anonymous)` (21)

### `~addRoute`
`/tmp/keala-all-win.cDctk1/epsilon/node_modules/h3/dist/cache.mjs:505` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `on` (1)

**Calls:**
- `addRoute` (1)

### `internal:fs/binding`
`internal:fs/binding:3` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `@lazy` (1)

### `(anonymous)`
`/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/_chunks/_url.mjs:78` | Self: 0.0% (0us) | Total: 1.2% (52.0ms) | Samples: 0

**Called by:**
- `(module)` (1)

**Calls:**
- `lazyInherit` (1)

### `H3Event`
`/tmp/keala-all-win.cDctk1/epsilon/node_modules/h3/dist/response.mjs:96` | Self: 0.0% (0us) | Total: 0.2% (8.4ms) | Samples: 0

**Called by:**
- `~request` (5)

**Calls:**
- `e` (4)
- `e` (1)

### `(module)`
`/tmp/keala-all-win.cDctk1/epsilon/bench/framework-compare/server.mjs:83` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Calls:**
- `on` (1)

### `BunServer`
`/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/adapters/bun.mjs:69` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `serve` (1)

**Calls:**
- `serve` (1)

### `internal:stream`
`internal:stream:46` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `anonymous` (1)

### `internal:validators`
`internal:validators:2` | Self: 0.0% (0us) | Total: 0.0% (932us) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `anonymous` (1)

### `H3Event`
`/tmp/keala-all-win.cDctk1/epsilon/node_modules/h3/dist/response.mjs:101` | Self: 0.0% (0us) | Total: 2.0% (84.4ms) | Samples: 0

**Called by:**
- `~request` (16)

**Calls:**
- `pathname` (12)
- `get pathname` (4)

### `(anonymous)`
`/tmp/keala-all-win.cDctk1/epsilon/node_modules/h3/dist/cache.mjs:416` | Self: 0.0% (0us) | Total: 0.3% (16.0ms) | Samples: 0

**Called by:**
- `handler` (2)

**Calls:**
- `routeHandler` (2)

### `addRoute`
`/tmp/keala-all-win.cDctk1/epsilon/node_modules/rou3/dist/index.mjs:407` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `~addRoute` (1)

**Calls:**
- `_add` (1)

### `(module)`
`/tmp/keala-all-win.cDctk1/epsilon/bench/framework-compare/server.mjs:100` | Self: 0.0% (0us) | Total: 0.0% (3.9ms) | Samples: 0

**Calls:**
- `URL` (2)

### `node:fs`
`node:fs:679` | Self: 0.0% (0us) | Total: 0.0% (926us) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `setName` (1)

### `FrozenHeaders`
`[native code]` | Self: 0.0% (0us) | Total: 0.0% (926us) | Samples: 0

**Called by:**
- `(module)` (1)

**Calls:**
- `Headers` (1)

### `makeSafe`
`internal:primordials:35` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `internal:primordials` (1)

**Calls:**
- `bound call` (1)

### `(module)`
`/tmp/keala-all-win.cDctk1/epsilon/bench/framework-compare/server.mjs:81` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Calls:**
- `H3` (1)

### `node:stream`
`node:stream:2` | Self: 0.0% (0us) | Total: 0.3% (13.5ms) | Samples: 0

**Called by:**
- `anonymous` (12)

**Calls:**
- `anonymous` (12)

### `~request`
`/tmp/keala-all-win.cDctk1/epsilon/node_modules/h3/dist/cache.mjs:389` | Self: 0.0% (0us) | Total: 36.6% (1.50s) | Samples: 0

**Called by:**
- `(anonymous)` (191)
- `bound fetch` (1)

**Calls:**
- `H3Event` (158)
- `H3Event` (16)
- `H3Event` (6)
- `H3Event` (5)
- `H3Event` (4)
- `H3Event` (3)

### `serve`
`/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/adapters/bun.mjs:72` | Self: 0.0% (0us) | Total: 0.0% (1.0ms) | Samples: 0

**Called by:**
- `BunServer` (1)

**Calls:**
- `serve` (1)

### `internal:streams/compose`
`internal:streams/compose:2` | Self: 0.0% (0us) | Total: 0.2% (10.0ms) | Samples: 0

**Called by:**
- `anonymous` (9)

**Calls:**
- `anonymous` (9)

### `internal:streams/operators`
`internal:streams/operators:2` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `anonymous` (1)

### `internal:streams/readable`
`internal:streams/readable:14` | Self: 0.0% (0us) | Total: 0.0% (966us) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `anonymous` (1)

### `internal:errors`
`internal:errors:2` | Self: 0.0% (0us) | Total: 0.0% (3.4ms) | Samples: 0

**Called by:**
- `anonymous` (3)

**Calls:**
- `anonymous` (3)

### `on`
`/tmp/keala-all-win.cDctk1/epsilon/node_modules/h3/dist/cache.mjs:484` | Self: 0.0% (0us) | Total: 0.0% (1.2ms) | Samples: 0

**Called by:**
- `(module)` (1)

**Calls:**
- `~addRoute` (1)

### `internal:fs/streams`
`internal:fs/streams:2` | Self: 0.0% (0us) | Total: 0.3% (15.8ms) | Samples: 0

**Called by:**
- `anonymous` (14)

**Calls:**
- `anonymous` (14)

### `serve`
`/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/adapters/bun.mjs:7` | Self: 0.0% (0us) | Total: 0.0% (2.2ms) | Samples: 0

**Called by:**
- `(module)` (2)

**Calls:**
- `BunServer` (1)
- `BunServer` (1)

### `bound fetch`
`[native code]` | Self: 0.0% (0us) | Total: 0.2% (8.2ms) | Samples: 0

**Called by:**
- `(anonymous)` (5)

**Calls:**
- `toResponse` (4)
- `~request` (1)

### `internal:primordials`
`internal:primordials:54` | Self: 0.0% (0us) | Total: 0.0% (1.1ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `createSafeIterator` (1)

### `(anonymous)`
`[native code]` | Self: 0.0% (0us) | Total: 0.5% (24.6ms) | Samples: 0

**Called by:**
- `(anonymous)` (21)

**Calls:**
- `get WriteStream` (16)
- `anonymous` (4)
- `WriteStream` (1)

### `internal:streams/pipeline`
`internal:streams/pipeline:2` | Self: 0.0% (0us) | Total: 0.2% (8.7ms) | Samples: 0

**Called by:**
- `anonymous` (8)

**Calls:**
- `anonymous` (8)

### `internal:streams/destroy`
`internal:streams/destroy:2` | Self: 0.0% (0us) | Total: 0.0% (3.4ms) | Samples: 0

**Called by:**
- `anonymous` (3)

**Calls:**
- `anonymous` (3)

## Files

| Self% | Self | File |
|------:|-----:|------|
| 55.9% | 2.30s | `[native code]` |
| 22.2% | 914.3ms | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/h3/dist/response.mjs` |
| 9.0% | 372.7ms | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/_chunks/_url.mjs` |
| 7.7% | 320.3ms | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/adapters/bun.mjs` |
| 2.4% | 99.3ms | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/h3/dist/cache.mjs` |
| 1.8% | 76.2ms | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/rou3/dist/index.mjs` |
| 0.6% | 26.5ms | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/_chunks/_utils2.mjs` |
| 0.0% | 1.2ms | `internal:streams/writable` |
| 0.0% | 1.1ms | `node:events` |
| 0.0% | 1.1ms | `internal:primordials` |
| 0.0% | 932us | `internal:shared` |
| 0.0% | 926us | `node:fs` |
