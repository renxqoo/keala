# CPU Profile

| Duration | Samples | Interval | Functions |
|----------|---------|----------|----------|
| 96.1ms | 26 | 1.0ms | 56 |

**Top 10:** `getOwnPropertyDescriptors` 56.1%, `anonymous` 18.2%, `(anonymous)` 9.5%, `(module)` 2.4%, `indexPattern` 1.3%, `(anonymous)` 1.2%, `node:fs` 1.2%, `createDecorators` 1.1%, `startBunServer` 1.1%, `node:events` 1.1%

## Hot Functions (Self Time)

| Self% | Self | Total% | Total | Function | Location |
|------:|-----:|-------:|------:|----------|----------|
| 56.1% | 54.0ms | 56.1% | 54.0ms | `getOwnPropertyDescriptors` | `[native code]` |
| 18.2% | 17.5ms | 100.0% | 102.5ms | `anonymous` | `[native code]` |
| 9.5% | 9.2ms | 9.5% | 9.2ms | `(anonymous)` | `/tmp/keala-all-win.cDctk1/epsilon/bench/framework-compare/server.mjs` |
| 2.4% | 2.3ms | 2.4% | 2.3ms | `(module)` | `/tmp/keala-all-win.cDctk1/epsilon/bench/framework-compare/server.mjs:14` |
| 1.3% | 1.2ms | 1.3% | 1.2ms | `indexPattern` | `/tmp/keala-all-win.cDctk1/epsilon/dist/router/router.js` |
| 1.2% | 1.2ms | 20.8% | 20.0ms | `(anonymous)` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/_chunks/_utils.mjs:6` |
| 1.2% | 1.1ms | 1.2% | 1.1ms | `node:fs` | `node:fs:12` |
| 1.1% | 1.1ms | 1.1% | 1.1ms | `createDecorators` | `/tmp/keala-all-win.cDctk1/epsilon/dist/core/context/decorate.js` |
| 1.1% | 1.1ms | 1.1% | 1.1ms | `startBunServer` | `/tmp/keala-all-win.cDctk1/epsilon/dist/adapters/bun.js` |
| 1.1% | 1.0ms | 1.1% | 1.0ms | `node:events` | `node:events:405` |
| 1.1% | 1.0ms | 1.1% | 1.0ms | `asyncWrap` | `node:fs/promises` |
| 1.0% | 1.0ms | 1.0% | 1.0ms | `makeBitMapDescriptor` | `internal:streams/writable:17` |
| 1.0% | 1.0ms | 1.0% | 1.0ms | `getHighWaterMark` | `internal:streams/state` |
| 1.0% | 1.0ms | 1.0% | 1.0ms | `freeze` | `[native code]` |
| 1.0% | 985us | 1.0% | 985us | `createSafeIterator` | `internal:primordials` |
| 0.9% | 935us | 0.9% | 935us | `serve` | `[native code]` |

## Call Tree (Total Time)

| Total% | Total | Self% | Self | Function | Location |
|-------:|------:|------:|-----:|----------|----------|
| 100.0% | 102.5ms | 18.2% | 17.5ms | `anonymous` | `[native code]` |
| 56.1% | 54.0ms | 0.0% | 0us | `(module)` | `/tmp/keala-all-win.cDctk1/epsilon/dist/core/context/context.js:94` |
| 56.1% | 54.0ms | 0.0% | 0us | `mergeProtos` | `/tmp/keala-all-win.cDctk1/epsilon/dist/core/context/context.js:19` |
| 56.1% | 54.0ms | 56.1% | 54.0ms | `getOwnPropertyDescriptors` | `[native code]` |
| 20.8% | 20.0ms | 0.0% | 0us | `(module)` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/_chunks/_utils.mjs:6` |
| 20.8% | 20.0ms | 1.2% | 1.2ms | `(anonymous)` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/_chunks/_utils.mjs:6` |
| 19.5% | 18.8ms | 0.0% | 0us | `(anonymous)` | `[native code]` |
| 15.9% | 15.3ms | 0.0% | 0us | `get WriteStream` | `node:fs:644` |
| 14.6% | 14.1ms | 0.0% | 0us | `internal:fs/streams` | `internal:fs/streams:2` |
| 12.3% | 11.9ms | 0.0% | 0us | `node:stream` | `node:stream:2` |
| 12.3% | 11.9ms | 0.0% | 0us | `internal:stream` | `internal:stream:2` |
| 10.2% | 9.8ms | 0.0% | 0us | `internal:streams/compose` | `internal:streams/compose:2` |
| 10.2% | 9.8ms | 0.0% | 0us | `internal:streams/pipeline` | `internal:streams/pipeline:2` |
| 9.5% | 9.2ms | 0.0% | 0us | `#serve` | `/tmp/keala-all-win.cDctk1/epsilon/dist/core/app.js:224` |
| 9.5% | 9.2ms | 0.0% | 0us | `(anonymous)` | `/tmp/keala-all-win.cDctk1/epsilon/dist/adapters/bun.js:55` |
| 9.5% | 9.2ms | 0.0% | 0us | `dispatchDirect` | `/tmp/keala-all-win.cDctk1/epsilon/dist/core/dispatch.js:171` |
| 9.5% | 9.2ms | 9.5% | 9.2ms | `(anonymous)` | `/tmp/keala-all-win.cDctk1/epsilon/bench/framework-compare/server.mjs` |
| 6.9% | 6.7ms | 0.0% | 0us | `internal:streams/duplex` | `internal:streams/duplex:2` |
| 6.3% | 6.0ms | 0.0% | 0us | `node:url` | `node:url:2` |
| 6.3% | 6.0ms | 0.0% | 0us | `internal:validators` | `internal:validators:2` |
| 2.4% | 2.3ms | 2.4% | 2.3ms | `(module)` | `/tmp/keala-all-win.cDctk1/epsilon/bench/framework-compare/server.mjs:14` |
| 2.3% | 2.2ms | 0.0% | 0us | `internal:streams/legacy` | `internal:streams/legacy:2` |
| 2.1% | 2.0ms | 0.0% | 0us | `listen` | `/tmp/keala-all-win.cDctk1/epsilon/dist/core/app.js:257` |
| 2.1% | 2.0ms | 0.0% | 0us | `(module)` | `/tmp/keala-all-win.cDctk1/epsilon/bench/framework-compare/server.mjs:42` |
| 2.0% | 1.9ms | 0.0% | 0us | `internal:errors` | `internal:errors:2` |
| 2.0% | 1.9ms | 0.0% | 0us | `internal:streams/destroy` | `internal:streams/destroy:2` |
| 1.3% | 1.2ms | 0.0% | 0us | `bindDef` | `/tmp/keala-all-win.cDctk1/epsilon/dist/router/router.js:131` |
| 1.3% | 1.2ms | 0.0% | 0us | `(module)` | `/tmp/keala-all-win.cDctk1/epsilon/bench/framework-compare/server.mjs:26` |
| 1.3% | 1.2ms | 1.3% | 1.2ms | `indexPattern` | `/tmp/keala-all-win.cDctk1/epsilon/dist/router/router.js` |
| 1.3% | 1.2ms | 0.0% | 0us | `routeShortcut` | `/tmp/keala-all-win.cDctk1/epsilon/dist/core/registration.js:29` |
| 1.3% | 1.2ms | 0.0% | 0us | `registerDef` | `/tmp/keala-all-win.cDctk1/epsilon/dist/router/router.js:313` |
| 1.2% | 1.1ms | 1.2% | 1.1ms | `node:fs` | `node:fs:12` |
| 1.1% | 1.1ms | 1.1% | 1.1ms | `createDecorators` | `/tmp/keala-all-win.cDctk1/epsilon/dist/core/context/decorate.js` |
| 1.1% | 1.1ms | 0.0% | 0us | `Keala` | `/tmp/keala-all-win.cDctk1/epsilon/dist/core/app.js:77` |
| 1.1% | 1.1ms | 0.0% | 0us | `(module)` | `/tmp/keala-all-win.cDctk1/epsilon/bench/framework-compare/server.mjs:24` |
| 1.1% | 1.1ms | 1.1% | 1.1ms | `startBunServer` | `/tmp/keala-all-win.cDctk1/epsilon/dist/adapters/bun.js` |
| 1.1% | 1.0ms | 1.1% | 1.0ms | `node:events` | `node:events:405` |
| 1.1% | 1.0ms | 1.1% | 1.0ms | `asyncWrap` | `node:fs/promises` |
| 1.1% | 1.0ms | 0.0% | 0us | `node:fs/promises` | `node:fs/promises:137` |
| 1.0% | 1.0ms | 1.0% | 1.0ms | `makeBitMapDescriptor` | `internal:streams/writable:17` |
| 1.0% | 1.0ms | 0.0% | 0us | `internal:streams/writable` | `internal:streams/writable:39` |
| 1.0% | 1.0ms | 0.0% | 0us | `internal:streams/operators` | `internal:streams/operators:2` |
| 1.0% | 1.0ms | 1.0% | 1.0ms | `getHighWaterMark` | `internal:streams/state` |
| 1.0% | 1.0ms | 0.0% | 0us | `Writable` | `internal:streams/writable:181` |
| 1.0% | 1.0ms | 0.0% | 0us | `WritableState` | `internal:streams/writable:139` |
| 1.0% | 1.0ms | 0.0% | 0us | `WriteStream` | `internal:fs/streams:259` |
| 1.0% | 1.0ms | 0.0% | 0us | `makeSafe` | `internal:primordials:53` |
| 1.0% | 1.0ms | 1.0% | 1.0ms | `freeze` | `[native code]` |
| 1.0% | 1.0ms | 0.0% | 0us | `internal:primordials` | `internal:primordials:83` |
| 1.0% | 985us | 0.0% | 0us | `internal:primordials` | `internal:primordials:54` |
| 1.0% | 985us | 1.0% | 985us | `createSafeIterator` | `internal:primordials` |
| 1.0% | 963us | 0.0% | 0us | `internal:streams/readable` | `internal:streams/readable:2` |
| 0.9% | 935us | 0.9% | 935us | `serve` | `[native code]` |
| 0.9% | 935us | 0.0% | 0us | `startBunServer` | `/tmp/keala-all-win.cDctk1/epsilon/dist/adapters/bun.js:222` |
| 0.9% | 935us | 0.0% | 0us | `(anonymous)` | `/tmp/keala-all-win.cDctk1/epsilon/dist/adapters/bun.js:57` |
| 0.9% | 935us | 0.0% | 0us | `serve` | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/adapters/bun.mjs:72` |

## Function Details

### `getOwnPropertyDescriptors`
`[native code]` | Self: 56.1% (54.0ms) | Total: 56.1% (54.0ms) | Samples: 1

**Called by:**
- `mergeProtos` (1)

### `anonymous`
`[native code]` | Self: 18.2% (17.5ms) | Total: 100.0% (102.5ms) | Samples: 11

**Called by:**
- `get WriteStream` (14)
- `internal:fs/streams` (13)
- `internal:stream` (11)
- `node:stream` (11)
- `internal:streams/pipeline` (9)
- `internal:streams/compose` (9)
- `internal:streams/duplex` (6)
- `internal:streams/destroy` (2)
- `(anonymous)` (2)
- `internal:errors` (2)
- `internal:streams/legacy` (2)
- `node:url` (1)
- `internal:validators` (1)
- `internal:streams/readable` (1)
- `internal:streams/operators` (1)

**Calls:**
- `internal:fs/streams` (13)
- `node:stream` (11)
- `internal:stream` (11)
- `internal:streams/pipeline` (9)
- `internal:streams/compose` (9)
- `internal:streams/duplex` (6)
- `internal:streams/destroy` (2)
- `internal:streams/legacy` (2)
- `internal:errors` (2)
- `node:fs` (1)
- `internal:streams/writable` (1)
- `internal:streams/operators` (1)
- `node:fs/promises` (1)
- `internal:primordials` (1)
- `internal:primordials` (1)
- `node:events` (1)
- `internal:streams/readable` (1)
- `internal:validators` (1)

### `(anonymous)`
`/tmp/keala-all-win.cDctk1/epsilon/bench/framework-compare/server.mjs` | Self: 9.5% (9.2ms) | Total: 9.5% (9.2ms) | Samples: 1

**Called by:**
- `dispatchDirect` (1)

### `(module)`
`/tmp/keala-all-win.cDctk1/epsilon/bench/framework-compare/server.mjs:14` | Self: 2.4% (2.3ms) | Total: 2.4% (2.3ms) | Samples: 1

### `indexPattern`
`/tmp/keala-all-win.cDctk1/epsilon/dist/router/router.js` | Self: 1.3% (1.2ms) | Total: 1.3% (1.2ms) | Samples: 1

**Called by:**
- `bindDef` (1)

### `(anonymous)`
`/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/_chunks/_utils.mjs:6` | Self: 1.2% (1.2ms) | Total: 20.8% (20.0ms) | Samples: 1

**Called by:**
- `(module)` (18)

**Calls:**
- `(anonymous)` (17)

### `node:fs`
`node:fs:12` | Self: 1.2% (1.1ms) | Total: 1.2% (1.1ms) | Samples: 1

**Called by:**
- `anonymous` (1)

### `createDecorators`
`/tmp/keala-all-win.cDctk1/epsilon/dist/core/context/decorate.js` | Self: 1.1% (1.1ms) | Total: 1.1% (1.1ms) | Samples: 1

**Called by:**
- `Keala` (1)

### `startBunServer`
`/tmp/keala-all-win.cDctk1/epsilon/dist/adapters/bun.js` | Self: 1.1% (1.1ms) | Total: 1.1% (1.1ms) | Samples: 1

**Called by:**
- `listen` (1)

### `node:events`
`node:events:405` | Self: 1.1% (1.0ms) | Total: 1.1% (1.0ms) | Samples: 1

**Called by:**
- `anonymous` (1)

### `asyncWrap`
`node:fs/promises` | Self: 1.1% (1.0ms) | Total: 1.1% (1.0ms) | Samples: 1

**Called by:**
- `node:fs/promises` (1)

### `makeBitMapDescriptor`
`internal:streams/writable:17` | Self: 1.0% (1.0ms) | Total: 1.0% (1.0ms) | Samples: 1

**Called by:**
- `internal:streams/writable` (1)

### `getHighWaterMark`
`internal:streams/state` | Self: 1.0% (1.0ms) | Total: 1.0% (1.0ms) | Samples: 1

**Called by:**
- `WritableState` (1)

### `freeze`
`[native code]` | Self: 1.0% (1.0ms) | Total: 1.0% (1.0ms) | Samples: 1

**Called by:**
- `makeSafe` (1)

### `createSafeIterator`
`internal:primordials` | Self: 1.0% (985us) | Total: 1.0% (985us) | Samples: 1

**Called by:**
- `internal:primordials` (1)

### `serve`
`[native code]` | Self: 0.9% (935us) | Total: 0.9% (935us) | Samples: 1

**Called by:**
- `serve` (1)

### `node:fs/promises`
`node:fs/promises:137` | Self: 0.0% (0us) | Total: 1.1% (1.0ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `asyncWrap` (1)

### `internal:streams/readable`
`internal:streams/readable:2` | Self: 0.0% (0us) | Total: 1.0% (963us) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `anonymous` (1)

### `get WriteStream`
`node:fs:644` | Self: 0.0% (0us) | Total: 15.9% (15.3ms) | Samples: 0

**Called by:**
- `(anonymous)` (14)

**Calls:**
- `anonymous` (14)

### `internal:primordials`
`internal:primordials:83` | Self: 0.0% (0us) | Total: 1.0% (1.0ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `makeSafe` (1)

### `(module)`
`/tmp/keala-all-win.cDctk1/epsilon/dist/core/context/context.js:94` | Self: 0.0% (0us) | Total: 56.1% (54.0ms) | Samples: 0

**Calls:**
- `mergeProtos` (1)

### `(module)`
`/tmp/keala-all-win.cDctk1/epsilon/bench/framework-compare/server.mjs:26` | Self: 0.0% (0us) | Total: 1.3% (1.2ms) | Samples: 0

**Calls:**
- `routeShortcut` (1)

### `internal:streams/legacy`
`internal:streams/legacy:2` | Self: 0.0% (0us) | Total: 2.3% (2.2ms) | Samples: 0

**Called by:**
- `anonymous` (2)

**Calls:**
- `anonymous` (2)

### `WritableState`
`internal:streams/writable:139` | Self: 0.0% (0us) | Total: 1.0% (1.0ms) | Samples: 0

**Called by:**
- `Writable` (1)

**Calls:**
- `getHighWaterMark` (1)

### `(module)`
`/tmp/keala-all-win.cDctk1/epsilon/bench/framework-compare/server.mjs:42` | Self: 0.0% (0us) | Total: 2.1% (2.0ms) | Samples: 0

**Calls:**
- `listen` (2)

### `internal:streams/destroy`
`internal:streams/destroy:2` | Self: 0.0% (0us) | Total: 2.0% (1.9ms) | Samples: 0

**Called by:**
- `anonymous` (2)

**Calls:**
- `anonymous` (2)

### `(module)`
`/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/_chunks/_utils.mjs:6` | Self: 0.0% (0us) | Total: 20.8% (20.0ms) | Samples: 0

**Calls:**
- `(anonymous)` (18)

### `internal:primordials`
`internal:primordials:54` | Self: 0.0% (0us) | Total: 1.0% (985us) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `createSafeIterator` (1)

### `mergeProtos`
`/tmp/keala-all-win.cDctk1/epsilon/dist/core/context/context.js:19` | Self: 0.0% (0us) | Total: 56.1% (54.0ms) | Samples: 0

**Called by:**
- `(module)` (1)

**Calls:**
- `getOwnPropertyDescriptors` (1)

### `Keala`
`/tmp/keala-all-win.cDctk1/epsilon/dist/core/app.js:77` | Self: 0.0% (0us) | Total: 1.1% (1.1ms) | Samples: 0

**Called by:**
- `(module)` (1)

**Calls:**
- `createDecorators` (1)

### `(anonymous)`
`[native code]` | Self: 0.0% (0us) | Total: 19.5% (18.8ms) | Samples: 0

**Called by:**
- `(anonymous)` (17)

**Calls:**
- `get WriteStream` (14)
- `anonymous` (2)
- `WriteStream` (1)

### `WriteStream`
`internal:fs/streams:259` | Self: 0.0% (0us) | Total: 1.0% (1.0ms) | Samples: 0

**Called by:**
- `(anonymous)` (1)

**Calls:**
- `Writable` (1)

### `internal:streams/pipeline`
`internal:streams/pipeline:2` | Self: 0.0% (0us) | Total: 10.2% (9.8ms) | Samples: 0

**Called by:**
- `anonymous` (9)

**Calls:**
- `anonymous` (9)

### `makeSafe`
`internal:primordials:53` | Self: 0.0% (0us) | Total: 1.0% (1.0ms) | Samples: 0

**Called by:**
- `internal:primordials` (1)

**Calls:**
- `freeze` (1)

### `internal:fs/streams`
`internal:fs/streams:2` | Self: 0.0% (0us) | Total: 14.6% (14.1ms) | Samples: 0

**Called by:**
- `anonymous` (13)

**Calls:**
- `anonymous` (13)

### `internal:errors`
`internal:errors:2` | Self: 0.0% (0us) | Total: 2.0% (1.9ms) | Samples: 0

**Called by:**
- `anonymous` (2)

**Calls:**
- `anonymous` (2)

### `(anonymous)`
`/tmp/keala-all-win.cDctk1/epsilon/dist/adapters/bun.js:55` | Self: 0.0% (0us) | Total: 9.5% (9.2ms) | Samples: 0

**Calls:**
- `#serve` (1)

### `internal:streams/operators`
`internal:streams/operators:2` | Self: 0.0% (0us) | Total: 1.0% (1.0ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `anonymous` (1)

### `internal:streams/compose`
`internal:streams/compose:2` | Self: 0.0% (0us) | Total: 10.2% (9.8ms) | Samples: 0

**Called by:**
- `anonymous` (9)

**Calls:**
- `anonymous` (9)

### `internal:streams/writable`
`internal:streams/writable:39` | Self: 0.0% (0us) | Total: 1.0% (1.0ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `makeBitMapDescriptor` (1)

### `serve`
`/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/adapters/bun.mjs:72` | Self: 0.0% (0us) | Total: 0.9% (935us) | Samples: 0

**Called by:**
- `(anonymous)` (1)

**Calls:**
- `serve` (1)

### `listen`
`/tmp/keala-all-win.cDctk1/epsilon/dist/core/app.js:257` | Self: 0.0% (0us) | Total: 2.1% (2.0ms) | Samples: 0

**Called by:**
- `(module)` (2)

**Calls:**
- `startBunServer` (1)
- `startBunServer` (1)

### `#serve`
`/tmp/keala-all-win.cDctk1/epsilon/dist/core/app.js:224` | Self: 0.0% (0us) | Total: 9.5% (9.2ms) | Samples: 0

**Called by:**
- `(anonymous)` (1)

**Calls:**
- `dispatchDirect` (1)

### `node:stream`
`node:stream:2` | Self: 0.0% (0us) | Total: 12.3% (11.9ms) | Samples: 0

**Called by:**
- `anonymous` (11)

**Calls:**
- `anonymous` (11)

### `bindDef`
`/tmp/keala-all-win.cDctk1/epsilon/dist/router/router.js:131` | Self: 0.0% (0us) | Total: 1.3% (1.2ms) | Samples: 0

**Called by:**
- `registerDef` (1)

**Calls:**
- `indexPattern` (1)

### `startBunServer`
`/tmp/keala-all-win.cDctk1/epsilon/dist/adapters/bun.js:222` | Self: 0.0% (0us) | Total: 0.9% (935us) | Samples: 0

**Called by:**
- `listen` (1)

**Calls:**
- `(anonymous)` (1)

### `internal:validators`
`internal:validators:2` | Self: 0.0% (0us) | Total: 6.3% (6.0ms) | Samples: 0

**Called by:**
- `anonymous` (1)

**Calls:**
- `anonymous` (1)

### `internal:stream`
`internal:stream:2` | Self: 0.0% (0us) | Total: 12.3% (11.9ms) | Samples: 0

**Called by:**
- `anonymous` (11)

**Calls:**
- `anonymous` (11)

### `Writable`
`internal:streams/writable:181` | Self: 0.0% (0us) | Total: 1.0% (1.0ms) | Samples: 0

**Called by:**
- `WriteStream` (1)

**Calls:**
- `WritableState` (1)

### `(anonymous)`
`/tmp/keala-all-win.cDctk1/epsilon/dist/adapters/bun.js:57` | Self: 0.0% (0us) | Total: 0.9% (935us) | Samples: 0

**Called by:**
- `startBunServer` (1)

**Calls:**
- `serve` (1)

### `internal:streams/duplex`
`internal:streams/duplex:2` | Self: 0.0% (0us) | Total: 6.9% (6.7ms) | Samples: 0

**Called by:**
- `anonymous` (6)

**Calls:**
- `anonymous` (6)

### `dispatchDirect`
`/tmp/keala-all-win.cDctk1/epsilon/dist/core/dispatch.js:171` | Self: 0.0% (0us) | Total: 9.5% (9.2ms) | Samples: 0

**Called by:**
- `#serve` (1)

**Calls:**
- `(anonymous)` (1)

### `routeShortcut`
`/tmp/keala-all-win.cDctk1/epsilon/dist/core/registration.js:29` | Self: 0.0% (0us) | Total: 1.3% (1.2ms) | Samples: 0

**Called by:**
- `(module)` (1)

**Calls:**
- `registerDef` (1)

### `node:url`
`node:url:2` | Self: 0.0% (0us) | Total: 6.3% (6.0ms) | Samples: 0

**Calls:**
- `anonymous` (1)

### `(module)`
`/tmp/keala-all-win.cDctk1/epsilon/bench/framework-compare/server.mjs:24` | Self: 0.0% (0us) | Total: 1.1% (1.1ms) | Samples: 0

**Calls:**
- `Keala` (1)

### `registerDef`
`/tmp/keala-all-win.cDctk1/epsilon/dist/router/router.js:313` | Self: 0.0% (0us) | Total: 1.3% (1.2ms) | Samples: 0

**Called by:**
- `routeShortcut` (1)

**Calls:**
- `bindDef` (1)

## Files

| Self% | Self | File |
|------:|-----:|------|
| 76.4% | 73.5ms | `[native code]` |
| 12.0% | 11.5ms | `/tmp/keala-all-win.cDctk1/epsilon/bench/framework-compare/server.mjs` |
| 1.3% | 1.2ms | `/tmp/keala-all-win.cDctk1/epsilon/dist/router/router.js` |
| 1.2% | 1.2ms | `/tmp/keala-all-win.cDctk1/epsilon/node_modules/srvx/dist/_chunks/_utils.mjs` |
| 1.2% | 1.1ms | `node:fs` |
| 1.1% | 1.1ms | `/tmp/keala-all-win.cDctk1/epsilon/dist/core/context/decorate.js` |
| 1.1% | 1.1ms | `/tmp/keala-all-win.cDctk1/epsilon/dist/adapters/bun.js` |
| 1.1% | 1.0ms | `node:events` |
| 1.1% | 1.0ms | `node:fs/promises` |
| 1.0% | 1.0ms | `internal:streams/writable` |
| 1.0% | 1.0ms | `internal:streams/state` |
| 1.0% | 985us | `internal:primordials` |
