#!/bin/sh
exec /usr/local/bin/bun --cpu-prof --cpu-prof-md --cpu-prof-dir=/tmp/keala-all-win.cDctk1/bun-profile "$@"
