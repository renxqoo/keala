import { IncomingMessage } from 'node:http';
import { Socket } from 'node:net';
import { EventEmitter } from 'node:events';
import assert from 'node:assert/strict';
const root=process.env.KEALA_PROBE_BUNDLE ?? '/Users/wrr/work/bun-koa';
const appRoot=process.env.KEALA_PROBE_ROOT ?? root;
const framework=process.argv[2];
let native,socket,handle;
if(framework==='keala') {
 const {Keala}=await import(appRoot+'/dist/index.js');
 const {listen}=await import(appRoot+'/dist/adapters/node.js');
 class Observed extends IncomingMessage { constructor(s){super(s);native=s.server;socket=s;} }
 const app=new Keala({env:'production'});app.get('/',c=>c.text('Hello World'));
 handle=await listen(app,{port:0,hostname:'127.0.0.1',http:{IncomingMessage:Observed}}).ready();
 assert.equal(await(await fetch('http://127.0.0.1:'+handle.port+'/')).text(),'Hello World');
} else {
 const {Hono}=await import(root+'/node_modules/hono/dist/index.js');
 const {serve}=await import(root+'/node_modules/@hono/node-server/dist/index.mjs');
 const app=new Hono();app.get('/',c=>c.text('Hello World'));
 native=serve({fetch:app.fetch,port:0,hostname:'127.0.0.1'});
 socket=new Socket();
}
const [handler]=native.listeners('request');assert.equal(native.listeners('request').length,1);
let sink=0,last;
class Output extends EventEmitter {
 constructor(req){super();this.req=req;this.socket=req.socket;this.destroyed=false;this.headersSent=false;this.writableEnded=false;this.writableFinished=false;}
 writeHead(status,reason,headers){this.statusCode=status;this.headers=typeof reason==='string'?headers:reason;this.headersSent=true;return this;}
 end(body){last=body;sink+=body?.length??0;this.writableEnded=this.writableFinished=true;return this;}
}
const incoming=new IncomingMessage(socket);incoming.method='GET';incoming.url='/';incoming.httpVersion='1.1';incoming.httpVersionMajor=1;incoming.headers={host:'bench'};incoming.rawHeaders=['Host','bench'];
const batch=async count=>{for(let n=0;n<count;n+=1000){for(let i=0;i<1000;i++)handler(incoming,new Output(incoming));await new Promise(setImmediate);}};
try {
 await batch(100000);assert.equal(last,'Hello World');
 const samples=[];
 for(let round=1;round<=5;round++) {const before=process.cpuUsage(),time=performance.now();await batch(200000);const cpu=process.cpuUsage(before);samples.push({round,ns:1000*(cpu.user+cpu.system)/200000,elapsed:performance.now()-time});}
 console.log(JSON.stringify({framework,samples,sink,last}));
} finally {socket.destroy();if(handle)handle.stop(true);else native.closeAllConnections();native.close();}
