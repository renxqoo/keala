import type { Application } from "../core/app.ts";
import { nativeRoutesAllowed } from "../core/native-policy.ts";
import type { PreparedRoute } from "../core/request-url.ts";

export type NativeRouteFetch = (
  request: Request,
  server: unknown,
  prepared?: PreparedRoute,
) => Response | Promise<Response>;

/**
 * Compile ordinary literal paths into Bun's native matching table. Every
 * callback still enters the shared Keala dispatcher and lifecycle. Methods,
 * middleware and route metadata are selected from the live target.
 */
export const buildStaticNativeRoutes = (
  app: Application,
  fetch: NativeRouteFetch,
  requestPrototype: object,
  readUrl: (source: Request) => string,
): Record<string, NativeRouteFetch> => {
  const routes: Record<string, NativeRouteFetch> = Object.create(null);
  let nativePrototype: object | undefined;
  const urlGetter = Object.getOwnPropertyDescriptor(requestPrototype, "url")?.get;
  for (const path of app.router.staticMap.keys()) {
    // Leave encoding, dot segments and native pattern syntax to the JS
    // matcher. Bun's native literal table matches these paths byte-for-byte.
    if (!/^\/(?:[A-Za-z0-9_-]+(?:\/[A-Za-z0-9_-]+)*)?$/.test(path)) continue;
    let prepared: PreparedRoute | undefined;
    routes[path] = (request, server) => {
      // Native routes provide a BunRequest subclass with params/cookies and
      // a different clone(). Restore the ordinary fetch Request surface.
      const prototype = Object.getPrototypeOf(request) as object;
      if (prototype !== nativePrototype) {
        if (
          Object.getPrototypeOf(prototype) !== requestPrototype ||
          !Object.hasOwn(prototype, "params") ||
          !Object.hasOwn(prototype, "cookies") ||
          Object.hasOwn(prototype, "constructor")
        )
          return fetch(request, server);
        nativePrototype = prototype;
      }
      if (Object.hasOwn(request, "url")) return fetch(request, server);
      Object.setPrototypeOf(request, requestPrototype);
      if (Object.getOwnPropertyDescriptor(requestPrototype, "url")?.get !== urlGetter) {
        return fetch(request, server);
      }
      const match = app.router.staticMap.get(path)?.staticMatch;
      if (match == null || !nativeRoutesAllowed(app)) return fetch(request, server);
      if (prepared?.match !== match) prepared = { path, match, readUrl };
      return fetch(request, server, prepared);
    };
  }
  return routes;
};

/** A fetch-only native reload must replace ordinary static callbacks too. */
export const preserveFetchReload = (
  server: { reload(options: Record<string, unknown>): void },
  originalRoutes: Record<string, unknown>,
): void => {
  const original = server.reload;
  let compiled = true;
  const reload = function (this: typeof server, options: Record<string, unknown>): void {
    if (this !== server) return original.call(this, options);
    if (compiled && typeof options["fetch"] === "function" && options["routes"] === undefined) {
      original.call(this, { ...options, routes: originalRoutes });
      compiled = false;
    } else {
      original.call(this, options);
      if (options["routes"] !== undefined) compiled = false;
    }
  };
  try {
    Object.defineProperty(server, "reload", { configurable: true, writable: true, value: reload });
  } catch {
    // A sealed/custom native handle cannot intercept reload: retain serving
    // compatibility by withdrawing the transparent route optimization.
    original.call(server, { routes: originalRoutes });
  }
};
