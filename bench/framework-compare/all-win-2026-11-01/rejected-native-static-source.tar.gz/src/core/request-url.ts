import type { RouteMatch } from "../router/router.ts";
import { splitPathSearch } from "../utils/url.ts";
import type { ContextState } from "./context/state.ts";

/** Prefill routing and public URL views without a temporary match tuple. */
export const primeRequestUrl = (c: ContextState, url: string): string => {
  let start = 0;
  if (url.charCodeAt(0) !== 47) {
    const scheme = url.indexOf("://");
    start = scheme === -1 ? 0 : url.indexOf("/", scheme + 3);
    if (start === -1) {
      c.pathValue = "/";
      c.urlValue = "/";
      return "/";
    }
  }
  const query = url.indexOf("?", start);
  const hash = url.indexOf("#", start);
  const sawQuery = query !== -1 && (hash === -1 || query < hash);
  const end = sawQuery ? query : hash;
  const rawPath = end === -1 ? url.slice(start) : url.slice(start, end);
  const path = rawPath.length === 0 ? "/" : rawPath;
  const view = sawQuery ? url.slice(start, hash === -1 ? url.length : hash) : path;
  c.pathValue = path;
  c.urlValue = sawQuery && rawPath.length === 0 ? "/" + view : view;
  return path;
};

/** A native exact-path match; method selection stays in the shared dispatcher. */
export interface PreparedRoute {
  readonly path: string;
  readonly match: RouteMatch;
  readonly readUrl: (source: Request) => string;
}

/** Materialize the original native URL only when an API observes its query/view. */
export const materializeDeferredUrl = (c: ContextState): string | undefined => {
  const source = c.deferredUrlSourceValue;
  const read = c.deferredUrlReaderValue;
  if (source === null || read === null) return undefined;
  const [path, search] = splitPathSearch(read(source));
  c.urlValue = path + search;
  c.deferredUrlSourceValue = null;
  c.deferredUrlReaderValue = null;
  return c.urlValue;
};
