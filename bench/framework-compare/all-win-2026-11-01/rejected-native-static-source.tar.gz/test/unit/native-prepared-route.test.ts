import { describe, expect, it, vi } from "vitest";
import { Keala } from "../../src/core/app.ts";
import type { Context } from "../../src/core/context/context.ts";
import { HANDLE_REQUEST_SOURCE } from "../../src/core/application.ts";
import type { PreparedRoute } from "../../src/core/request-url.ts";
import { preserveFetchReload } from "../../src/adapters/bun-routes.ts";

const urlGetter = Object.getOwnPropertyDescriptor(Request.prototype, "url")!.get!;
const prepared = (app: Keala, path: string): PreparedRoute => ({
  path,
  match: app.router.staticMap.get(path)!.staticMatch!,
  readUrl: (source) => urlGetter.call(source) as string,
});

describe("native prepared routes", () => {
  it("defers the original URL while preserving query snapshots after raw mutations", async () => {
    const app = new Keala({ env: "test" });
    let context: Context | undefined;
    app.get("user", "/user", (c) => {
      context = c;
      return c.text(c.path);
    });
    const raw = new Request("http://example.test/user?a=1&a=2#fragment");
    const hint = prepared(app, "/user");
    const read = vi.fn(hint.readUrl);
    const response = await app[HANDLE_REQUEST_SOURCE](raw, undefined, { ...hint, readUrl: read });
    expect(await response.text()).toBe("/user");
    expect(read).not.toHaveBeenCalled();
    expect(context!.routePath).toBe("/user");
    expect(context!.routeName).toBe("user");
    Object.defineProperty(raw, "url", {
      configurable: true,
      value: "http://changed.test/wrong?b=3",
    });
    context!.rawRequest = new Request("http://reassigned.test/also-wrong?c=4");
    expect(context!.querystring).toBe("a=1&a=2");
    expect(context!.url).toBe("/user?a=1&a=2");
    expect(context!.queries("a")).toEqual(["1", "2"]);
    expect(read).toHaveBeenCalledTimes(1);
    expect(context!.deferredUrlSourceValue).toBeNull();
    expect(app.inFlight).toBe(0);
  });

  it("keeps the ordinary c.url source-read side effect even when memoized", async () => {
    const app = new Keala({ env: "test" });
    app.get("/user", (c) => {
      Object.defineProperty(c.raw, "url", {
        get() {
          throw new Error("url-getter");
        },
      });
      expect(c.query("a")).toBe("1");
      expect(() => c.url).toThrow("url-getter");
      return c.text("ok");
    });
    const response = await app[HANDLE_REQUEST_SOURCE](
      new Request("http://example.test/user?a=1"),
      undefined,
      prepared(app, "/user"),
    );
    expect(await response.text()).toBe("ok");
  });

  it.each(["GET", "HEAD", "POST", "OPTIONS", "PATCH"])(
    "shares %s method and middleware behavior",
    async (method) => {
      const app = new Keala({ env: "test" });
      app.use(async (c, next) => {
        c.setHeader("x-global", "yes");
        await next();
      });
      app.get("/user", (c) => c.text("body"));
      const make = () => new Request("http://example.test/user?q=1", { method });
      const before = await app.handle(make());
      const after = await app[HANDLE_REQUEST_SOURCE](make(), undefined, prepared(app, "/user"));
      expect(after.status).toBe(before.status);
      expect([...after.headers]).toEqual([...before.headers]);
      expect(await after.text()).toBe(await before.text());
      expect(app.inFlight).toBe(0);
    },
  );

  it("clears deferred sources across pooled and ordinary requests", async () => {
    const app = new Keala({ env: "test", pooling: true });
    app.get("/user", (c) => c.text(c.url + ":" + c.query("q")));
    app.get("/other", (c) => c.text(c.url + ":" + c.query("q")));
    for (const [path, q] of [
      ["/user", "1"],
      ["/other", "2"],
    ] as const) {
      const response = await app[HANDLE_REQUEST_SOURCE](
        new Request(`http://example.test${path}?q=${q}`),
        undefined,
        prepared(app, path),
      );
      expect(await response.text()).toBe(`${path}?q=${q}:${q}`);
    }
    expect(await (await app.handle(new Request("http://example.test/user?q=3"))).text()).toBe(
      "/user?q=3:3",
    );
  });

  it("discards a supplied hint when admission policy requires the full gate", async () => {
    const app = new Keala({ env: "test", overload: { maxConcurrency: 1 } });
    app.get("/user", (c) => c.text("wrong"));
    app.get("/other", (c) => c.text("right"));
    const response = await app[HANDLE_REQUEST_SOURCE](
      new Request("http://example.test/other"),
      undefined,
      prepared(app, "/user"),
    );
    expect(await response.text()).toBe("right");
  });
});

describe("transparent native fetch reload", () => {
  it("withdraws automatic routes for fetch-only reload and preserves explicit sinks", () => {
    const calls: Record<string, unknown>[] = [];
    const server = {
      reload(options: Record<string, unknown>) {
        calls.push(options);
      },
    };
    const sinks = { "/sink": new Response("sink") };
    preserveFetchReload(server, sinks);
    const fetch = () => new Response("new");
    const options = Object.freeze({ fetch });
    server.reload(options);
    expect(calls[0]).toEqual({ fetch, routes: sinks });
    server.reload(options);
    expect(calls[1]).toBe(options);
  });
  it("retains explicit routes and borrowed-method receiver semantics", () => {
    const calls: unknown[] = [];
    const server = {
      reload(this: unknown, options: Record<string, unknown>) {
        calls.push([this, options]);
      },
    };
    preserveFetchReload(server, {});
    const explicit = {
      routes: { "/custom": new Response("custom") },
      fetch: () => new Response("new"),
    };
    server.reload(explicit);
    expect(calls[0]).toEqual([server, explicit]);
    const other = { reload: server.reload };
    other.reload({ port: 0 });
    expect(calls[1]).toEqual([other, { port: 0 }]);
  });
  it("withdraws callbacks when the handle cannot intercept reload", () => {
    const reload = vi.fn();
    const server = Object.freeze({ reload });
    preserveFetchReload(server, {});
    expect(reload).toHaveBeenCalledExactlyOnceWith({ routes: {} });
  });
  it("does not commit state when native reload fails", () => {
    const reload = vi.fn().mockImplementationOnce(() => {
      throw new Error("bad options");
    });
    const server = { reload };
    preserveFetchReload(server, {});
    const options = { fetch: () => new Response("new") };
    expect(() => server.reload(options)).toThrow("bad options");
    server.reload(options);
    expect(reload.mock.calls[1]![0]).toHaveProperty("routes", {});
  });
});
