import { fastComparable } from "./pattern.ts";
import type { EligiblePattern } from "./bucket-regex.ts";
import type { RouteMatch } from "./router.ts";
import type { RouteTarget } from "./trie.ts";

export interface SuffixGroup {
  prefix: string;
  cases: Map<string, { target: RouteTarget; names: readonly string[] }>;
}

/** Only one complete, unambiguous bucket is specialized; the full table remains. */
export const compileSuffixGroup = (
  index: Map<string, EligiblePattern>,
  impure: Set<string>,
): SuffixGroup | null => {
  const buckets = new Map<string, EligiblePattern[]>();
  for (const entry of index.values()) {
    const first = entry.segments[0]!.value;
    const entries = buckets.get(first);
    if (entries === undefined) buckets.set(first, [entry]);
    else entries.push(entry);
  }
  let result: SuffixGroup | null = null;
  for (const [first, entries] of buckets) {
    if (entries.length < 2 || impure.has(first)) continue;
    let prefix: string | undefined;
    let name: string | undefined;
    const cases: SuffixGroup["cases"] = new Map();
    let valid = true;
    for (const entry of entries) {
      const segments = entry.segments;
      const at = segments.findIndex((segment) => segment.kind === "param");
      if (
        at < 1 ||
        !fastComparable(segments) ||
        segments.some((segment, i) =>
          i === at
            ? segment.kind !== "param" || segment.optional || segment.pattern !== null
            : segment.kind !== "static",
        )
      ) {
        valid = false;
        break;
      }
      const head =
        "/" +
        segments
          .slice(0, at)
          .map((segment) => segment.value)
          .join("/");
      const paramName = segments[at]!.value;
      const tail = segments.slice(at + 1).map((segment) => segment.value);
      const suffix = tail.length === 0 ? "" : "/" + tail.join("/");
      if (
        (prefix !== undefined && prefix !== head) ||
        (name !== undefined && name !== paramName) ||
        cases.has(suffix)
      ) {
        valid = false;
        break;
      }
      prefix = head;
      name = paramName;
      cases.set(suffix, { target: entry.target, names: Object.freeze([paramName]) });
    }
    if (!valid || prefix === undefined) continue;
    if (result !== null) return null;
    result = { prefix, cases };
  }
  return result;
};

export const matchSuffixGroup = (group: SuffixGroup, path: string): RouteMatch | null => {
  const prefix = group.prefix;
  if (path.endsWith("/") || !path.startsWith(prefix) || path.charCodeAt(prefix.length) !== 47)
    return null;
  const start = prefix.length + 1;
  const slash = path.indexOf("/", start);
  const end = slash === -1 ? path.length : slash;
  if (end <= start) return null;
  const hit = group.cases.get(slash === -1 ? "" : path.slice(slash));
  return hit === undefined
    ? null
    : { target: hit.target, names: hit.names, values: [path.slice(start, end)], offset: 0 };
};
