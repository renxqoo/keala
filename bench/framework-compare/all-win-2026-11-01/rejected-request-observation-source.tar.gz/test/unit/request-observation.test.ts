import { expect, it, vi } from "vitest";
import { Keala } from "../../src/core/app.ts";
import {
  deferRequestObservation,
  type RequestObserver,
} from "../../src/core/request-observation.ts";
import { sourceMethod, sourceRequest, sourceUrl } from "../../src/core/request-source.ts";

const observer = (): RequestObserver & { observe: ReturnType<typeof vi.fn> } => ({
  beforeRead: () => false,
  observe: vi.fn((source) => {
    Object.defineProperty(source, "extension", { value: "ready" });
  }),
});

it("does no exposure work for ordinary internal reads and observes exactly once on delivery", () => {
  const request = new Request("http://example.test/");
  const record = observer();
  deferRequestObservation(request, record);
  expect(sourceMethod(request)).toBe("GET");
  expect(sourceUrl(request)).toBe("http://example.test/");
  expect(record.observe).not.toHaveBeenCalled();
  expect(sourceRequest(request)).toBe(request);
  expect(Reflect.get(request, "extension")).toBe("ready");
  sourceRequest(request);
  expect(record.observe).toHaveBeenCalledExactlyOnceWith(request);
});

it("keeps rawRequest ordinary assignment, c.raw identity, and existing decorator names", async () => {
  const app = new Keala({ env: "test" });
  const service = {};
  app.decorate("requestSourceValue", service);
  const first = new Request("http://example.test/");
  const second = new Request("http://example.test/second");
  const record = observer();
  deferRequestObservation(first, record);
  app.get("/", (c) => {
    expect(Reflect.get(c, "requestSourceValue")).toBe(service);
    expect(c.rawRequest).toBe(first);
    expect(c.raw).toBe(first);
    expect(record.observe).toHaveBeenCalledTimes(1);
    c.rawRequest = second;
    expect(c.rawRequest).toBe(second);
    expect(c.raw).toBe(second);
    return c.text("ok");
  });
  expect(await (await app.handle(first)).text()).toBe("ok");
});

it("observes before handing a pre-context request to an overload handler", async () => {
  const app = new Keala({
    env: "test",
    overload: {
      maxConcurrency: 1,
      handler: (request) => {
        expect(Reflect.get(request, "extension")).toBe("ready");
        return new Response("busy", { status: 429 });
      },
    },
  });
  let release!: () => void;
  let started!: () => void;
  const ready = new Promise<void>((resolve) => {
    started = resolve;
  });
  app.get("/", async (c) => {
    started();
    await new Promise<void>((resolve) => {
      release = resolve;
    });
    return c.text("done");
  });
  const first = app.handle(new Request("http://example.test/"));
  await ready;
  const second = new Request("http://example.test/");
  const record = observer();
  deferRequestObservation(second, record);
  const refused = await app.handle(second);
  expect(refused.status).toBe(429);
  expect(record.observe).toHaveBeenCalledTimes(1);
  release();
  await (await first).text();
});

it("keeps server-owned descriptor values and per-request runtime isolation", async () => {
  const { createBunRequestObserver } = await import("../../src/adapters/bun-request.ts");
  const requestIP = vi.fn(() => ({ address: "127.0.0.1" }));
  const server = { requestIP };
  const waitUntil = () => {};
  const scope = createBunRequestObserver(server, waitUntil, Request.prototype);
  const first = new Request("http://example.test/1");
  const second = new Request("http://example.test/2");
  scope.observe(first);
  scope.observe(second);
  expect(Reflect.get(first, "runtime")).not.toBe(Reflect.get(second, "runtime"));
  expect(Reflect.get(first, "runtime").bun).not.toBe(Reflect.get(second, "runtime").bun);
  expect(Reflect.get(first, "waitUntil")).toBe(waitUntil);
  expect(Reflect.get(first, "ip")).toBe("127.0.0.1");
  expect(requestIP).toHaveBeenCalledWith(first);
  expect(scope.beforeRead(first, "url")).toBe(true); // Node's getter is JavaScript.
  expect(scope.beforeRead(first, "arrayBuffer")).toBe(true);
  expect(scope.beforeRead(first, Symbol("absent"))).toBe(false);
});

it("does not inspect through an initially proxied prototype chain before observation", async () => {
  const { createBunRequestObserver } = await import("../../src/adapters/bun-request.ts");
  let request: Request;
  const seen: boolean[] = [];
  const proxy = new Proxy(Object.prototype, {
    getOwnPropertyDescriptor(target, key) {
      seen.push(Object.hasOwn(request, "runtime"));
      return Reflect.getOwnPropertyDescriptor(target, key);
    },
    getPrototypeOf(target) {
      seen.push(Object.hasOwn(request, "runtime"));
      return Reflect.getPrototypeOf(target);
    },
    get(target, key, receiver) {
      seen.push(Object.hasOwn(request, "runtime"));
      return Reflect.get(target, key, receiver);
    },
  });
  const prototype = Object.create(proxy) as object;
  request = new Request("http://example.test/");
  Object.setPrototypeOf(request, prototype);
  const scope = createBunRequestObserver({ requestIP: () => null }, () => {}, prototype);
  deferRequestObservation(request, scope);
  sourceMethod(request);
  expect(seen.every(Boolean)).toBe(true);
  expect(Object.hasOwn(request, "runtime")).toBe(true);
});
