import { describe, expect, it } from "vitest";
import { Keala } from "../../src/core/app.ts";
import { REQUEST_SOURCE } from "../../src/core/context/state.ts";
import { createBunRequestObserver } from "../../src/adapters/bun-request.ts";
import { deferRequestObservation } from "../../src/core/request-observation.ts";
import {
  sourceMethod,
  sourceUrl,
  sourceHeaders,
  sourceSignal,
  sourceBytes,
} from "../../src/core/request-source.ts";

interface NativeIP {
  requestIP(request: Request): { address: string } | null;
}
const assertExtensions = (request: Request) => {
  expect(Reflect.ownKeys(request)).toEqual(["waitUntil", "runtime", "ip"]);
  expect(Reflect.get(request, "runtime").name).toBe("bun");
  expect(typeof Reflect.get(request, "waitUntil")).toBe("function");
};

describe.skipIf(typeof Bun === "undefined")("Bun Request observation boundaries", () => {
  it("does not materialize unused raw extensions, while keeping early URI capture", async () => {
    const app = new Keala({ env: "test" });
    let source: Request | undefined;
    app.get("/", (c) => {
      source = c[REQUEST_SOURCE] as Request;
      expect(Reflect.ownKeys(source)).toEqual([]);
      expect(c.path).toBe("/");
      const response = c.text("ok");
      expect(Reflect.ownKeys(source)).toEqual([]);
      return response;
    });
    const server = app.listen({ port: 0, hostname: "127.0.0.1" });
    try {
      expect(await (await fetch(`http://127.0.0.1:${server.port}/?q=late`)).text()).toBe("ok");
      expect(source!.url).toBe(`http://127.0.0.1:${server.port}/?q=late`);
    } finally {
      await app.close({ drain: 100 });
    }
  });

  it.each(["url", "method", "headers", "signal"] as const)(
    "exposes before a custom %s getter",
    (key) => {
      const original = Object.getOwnPropertyDescriptor(Request.prototype, key)!;
      const proto = Object.create(Request.prototype) as object;
      let seen = 0;
      Object.defineProperty(proto, key, {
        configurable: true,
        get(this: Request) {
          assertExtensions(this);
          seen++;
          return original.get!.call(this);
        },
      });
      const request = new Request("http://example.test/");
      Object.setPrototypeOf(request, proto);
      deferRequestObservation(
        request,
        createBunRequestObserver({ requestIP: () => null }, () => {}, Request.prototype),
      );
      if (key === "url") sourceUrl(request);
      else if (key === "method") sourceMethod(request);
      else if (key === "headers") sourceHeaders(request);
      else sourceSignal(request);
      expect(seen).toBe(1);
    },
  );

  it("exposes before an internally invoked Request bytes hook", async () => {
    const original = Object.getOwnPropertyDescriptor(Request.prototype, "bytes")!;
    const app = new Keala({ env: "test" });
    app.post("/", async (c) =>
      c.text(new TextDecoder().decode(await sourceBytes(c[REQUEST_SOURCE]))),
    );
    const server = app.listen({ port: 0, hostname: "127.0.0.1" });
    const native = server as unknown as NativeIP;
    let seen = 0;
    try {
      Object.defineProperty(Request.prototype, "bytes", {
        ...original,
        value: function (this: Request) {
          if (native.requestIP(this) !== null) {
            assertExtensions(this);
            seen++;
          }
          return original.value.call(this);
        },
      });
      const response = await fetch(`http://127.0.0.1:${server.port}/`, {
        method: "POST",
        body: "payload",
      });
      expect(await response.text()).toBe("payload");
      expect(seen).toBeGreaterThan(0);
    } finally {
      Object.defineProperty(Request.prototype, "bytes", original);
      await app.close({ drain: 100 });
    }
  });
});
