import { types as utilTypes } from "node:util";
import { createBunRequestObserver } from "./bun-request.ts";
import { deferRequestObservation, type RequestObserver } from "../core/request-observation.ts";
/**
 * Bun adapter: `Bun.serve` glue.
 *
 * The only module in the framework that references the `Bun` global, and only
 * inside function bodies — importing the core under Node (tests) is
 * side-effect free. The serve implementation is injectable for unit tests.
 */

import { serve as serveBun } from "srvx/bun";
import type { ServerOptions as SrvxOptions, ServerRequest } from "srvx";
import { nativeRoutesAllowed } from "../core/native-policy.ts";
import { HANDLE_REQUEST_SOURCE, type NativeApplication } from "../core/application.ts";
import type { Application, WebSocketHandlers } from "../core/app.ts";
import type { Context } from "../core/context/context.ts";
import { buildNativeRoutes } from "../core/sink.ts";
import { consoleFallback } from "../core/error-response.ts";
import type { GracefulStopOptions } from "../core/lifecycle.ts";
import { attachServer, assertCanStart } from "../core/server-slot.ts";
import { toHttpError } from "../http/errors.ts";
import type { ListenOptions, Runtime } from "../types.ts";

/** Minimal structural type of the Bun server handle we expose to users. */
export interface ServerHandle {
  readonly port: number;
  readonly hostname: string;
  readonly url?: URL;
  stop(closeActiveConnections?: boolean): void;
  fetch(request: Request): Promise<Response>;
  /** Hot-reload server options (Bun's actual API — `update` does not exist). */
  reload(options: Record<string, unknown>): void;
  /** R4.6 graceful stop (attached by startBunServer when the handle allows). */
  stopGraceful?(options: GracefulStopOptions): Promise<{ timedOut: boolean }>;
}

export type ServeImplementation = (options: Record<string, unknown>) => ServerHandle;

interface RequestIPHost {
  requestIP(request: Request): { readonly address: string } | null;
}

const transportClosers = new WeakMap<ServerHandle, (force?: boolean) => Promise<void>>();
const nativeBunResponse = (value: Response | Promise<Response>): Response | Promise<Response> => {
  const response = value as Response & { _toNodeResponse?: unknown; _response?: Response };
  if (response?._toNodeResponse) return response._response!;
  const promise = value as Promise<Response>;
  return typeof promise?.then === "function" ? promise.then(nativeBunResponse) : value;
};
const defaultServeImplementation = (): ServeImplementation | undefined =>
  typeof Bun !== "undefined" && typeof Bun.serve === "function"
    ? (options) => {
        const fetch = options["fetch"] as (
          request: Request,
          server: unknown,
        ) => Response | Promise<Response>;
        const transport = serveBun({
          port: options["port"] as number,
          hostname: options["hostname"] as string | undefined,
          // Preserve Bun's native default rather than inheriting process.env.HOST.
          bun: { ...options, hostname: options["hostname"] } as SrvxOptions["bun"],
          silent: true,
          gracefulShutdown: false,
          manual: true,
          fetch: (request: ServerRequest) => fetch(request, request.runtime?.bun?.server),
        });
        const nativeOptions = (transport as unknown as { serveOptions?: Record<string, unknown> })
          .serveOptions;
        if (nativeOptions !== undefined) {
          const requestPrototype = Request.prototype;
          const serveFunction = Bun.serve;
          const serveName = utilTypes.isProxy(serveFunction)
            ? undefined
            : (Object.getOwnPropertyDescriptor(serveFunction, "name")?.value as unknown);
          const nativeServe =
            typeof serveName === "string" &&
            !serveName.startsWith("bound ") &&
            Function.prototype.toString.call(serveFunction).includes("[native code]");
          let observer: RequestObserver | undefined;
          let observedServer: RequestIPHost | undefined;
          nativeOptions["fetch"] = (request: Request, server: RequestIPHost) => {
            if (observer === undefined || observedServer !== server) {
              observedServer = server;
              observer = createBunRequestObserver(server, transport.waitUntil, requestPrototype);
            }
            if (
              nativeServe &&
              !utilTypes.isProxy(request) &&
              Object.getPrototypeOf(request) === requestPrototype
            ) {
              deferRequestObservation(request, observer);
            } else {
              // A wrapped serve or custom Request may expose its receiver
              // before entering Context; keep its eager extension contract.
              observer.observe(request);
            }
            return nativeBunResponse(fetch(request, server));
          };
          void transport.serve();
        }
        const server = transport.bun!.server as unknown as ServerHandle;
        transportClosers.set(server, (force) => transport.close(force));
        return server;
      }
    : undefined;

/**
 * DEAD-23: the plain serve-error 500 envelope, shared by both Bun-adapter
 * sites (the default handler and the hook-failure fallback). Byte-equal to
 * the core funnel's static envelope in error-response.ts, which is not
 * exported for adapter reuse — one local const keeps the two adapter sites
 * from drifting without inverting the core/adapters dependency.
 */
const internalServerErrorEnvelope = (): Response =>
  new Response("Internal Server Error", {
    status: 500,
    headers: { "content-type": "text/plain; charset=utf-8" },
  });

const defaultServeError =
  (app: Application) =>
  (error: Error): Response => {
    // A serve error is a server fault, not a request-path error: it has no
    // context, so the mapper contract does not apply — console fallback only.
    consoleFallback(app, undefined, toHttpError(error));
    return internalServerErrorEnvelope();
  };

/**
 * Start a Bun server for the app. Returns the Bun `Server`.
 *
 * ```ts
 * const server = app.listen(3000, "0.0.0.0", () => console.log("up"))
 * server.stop()
 * ```
 */
export const startBunServer = (
  app: Application,
  options: ListenOptions,
  onListen?: () => void,
  serveImpl?: ServeImplementation,
): ServerHandle => {
  assertCanStart(app);
  const serve = serveImpl ?? defaultServeImplementation();
  if (serve === undefined) {
    throw new Error(
      'listen() requires Bun.serve (Bun >= 1.4). Under Node use startNodeServer from "keala/node", or call app.handle() yourself.',
    );
  }

  // The server handle rides the runtime channel: `c.ip` resolves through
  // `requestIP` without any Bun-specific code in the core. Bun passes the
  // SAME Server object to every fetch call, so the { server } carrier is
  // captured once instead of allocated per request; an identity change
  // (test doubles) re-captures transparently.
  let runtime: Runtime | undefined;
  // Dispatch through the internal entry so synchronous chains stay
  // synchronous: Bun.serve accepts a bare Response, while the public
  // handle() would add a Promise wrap per request. The Node adapter
  // dispatches through the same symbol.
  const nativeApp = app as NativeApplication;
  const fetch = (request: Request, server: RequestIPHost): Response | Promise<Response> => {
    if (runtime === undefined || runtime.server !== server) runtime = { server };
    return nativeApp[HANDLE_REQUEST_SOURCE](request, runtime);
  };

  const serveOptions: Record<string, unknown> = {
    port: options.port ?? 3000,
    fetch,
    // Server-level failures (fetch threw, streaming body crashed) route
    // through the app's error hook and answer a plain 500. The user's
    // callback gets the same containment the Node adapter gives it: a
    // throwing hook falls back to the plain envelope instead of escaping
    // into Bun.serve.
    error: ((error: Error): Response => {
      const handler = options.onServeError ?? defaultServeError(app);
      try {
        return handler(error);
      } catch (hookError) {
        consoleFallback(app, undefined, toHttpError(hookError));
        return internalServerErrorEnvelope();
      }
    }) as (error: Error) => Response,
  };
  // Sunk routes ride the native routing table — matched before `fetch`,
  // with zero JS per request. `nativeRoutes: false` forces JS-only serving.
  if (options.nativeRoutes !== false && nativeRoutesAllowed(app) && app.nativeSinks.size > 0) {
    serveOptions["routes"] = buildNativeRoutes(app.nativeSinks);
  }
  // Websocket handlers install UNCONDITIONALLY: they dispatch through the
  // live wsRoutes map, so `app.ws()` registered after listen() is picked up
  // without a reload (HTTP routes hot-register the same way). Skipping the
  // install when no ws route exists yet would silently dead-end late
  // registrations under Bun (server.upgrade fails without handlers).
  const wsRoutes = app.wsRoutes;
  // R4.6: open sockets tracked for drain — a websocket never settles an HTTP
  // request (the upgrade returns immediately, releasing its slot), so a
  // courtesy 1001 close lets clients reconnect elsewhere instead of eating
  // the drain timeout. Entries leave on close/error.
  const openSockets = new Set<unknown>();
  {
    interface WsData {
      wsKey?: string;
      ctx?: Context;
    }
    const entryFor = (ws: unknown): { handlers: WebSocketHandlers; ctx?: Context } | undefined => {
      const data = (ws as { data?: WsData }).data;
      if (data?.wsKey === undefined) return undefined;
      const handlers = wsRoutes.get(data.wsKey);
      return handlers === undefined ? undefined : { handlers, ctx: data.ctx };
    };
    // A rejecting async ws handler must never become an unhandledRejection
    // (a process-killer under Bun.serve) — rejections route to the app's
    // error hook, mirroring the HTTP chain's floating-next containment. The
    // hook itself can throw (a failing listener, a non-Error value) — that
    // failure must die here too, exactly like defaultServeError below.
    const dispatch = (run: () => unknown): void => {
      void Promise.resolve()
        .then(run)
        .catch((error: unknown) => {
          // ws runtime errors live outside the request funnel (no context,
          // no mapper contract) — the console fallback keeps them visible.
          // The containment itself must never become an unhandledRejection
          // (a process-killer under Bun.serve), so it guards its own body.
          try {
            consoleFallback(app, undefined, toHttpError(error));
          } catch {
            // Even a throwing fallback dies here, quietly.
          }
        });
    };
    // User websocket tuning (maxPayloadLength, backpressureLimit, idle
    // timeout…) rides along; keala's five HANDLERS always win so live
    // wsRoutes dispatch is never silently disconnected by a user override.
    const config = (options.websocket ?? {}) as Record<string, unknown>;
    serveOptions["websocket"] = {
      ...config,
      open: (ws: unknown): void => {
        openSockets.add(ws);
        const entry = entryFor(ws);
        if (entry !== undefined) dispatch(() => entry.handlers.open?.(ws, entry.ctx as Context));
      },
      message: (ws: unknown, message: string | ArrayBuffer): void => {
        const entry = entryFor(ws);
        if (entry !== undefined)
          dispatch(() => entry.handlers.message?.(ws, message, entry.ctx as Context));
      },
      close: (ws: unknown, code: number, reason: string): void => {
        openSockets.delete(ws);
        const entry = entryFor(ws);
        if (entry !== undefined)
          dispatch(() => entry.handlers.close?.(ws, code, reason, entry.ctx as Context));
      },
      drain: (ws: unknown): void => {
        const entry = entryFor(ws);
        if (entry !== undefined) dispatch(() => entry.handlers.drain?.(ws, entry.ctx as Context));
      },
      error: (ws: unknown, error: Error): void => {
        openSockets.delete(ws);
        const entry = entryFor(ws);
        if (entry !== undefined)
          dispatch(() => entry.handlers.error?.(ws, error, entry.ctx as Context));
      },
    };
  }
  if (options.hostname !== undefined) serveOptions["hostname"] = options.hostname;
  if (options.reusePort !== undefined) serveOptions["reusePort"] = options.reusePort;
  if (options.idleTimeout !== undefined) serveOptions["idleTimeout"] = options.idleTimeout;
  if (options.maxRequestBodySize !== undefined) {
    serveOptions["maxRequestBodySize"] = options.maxRequestBodySize;
  }
  if (options.development !== undefined) serveOptions["development"] = options.development;

  const server = serve(serveOptions);
  // R4.6 graceful stop, injected onto the handle: Bun's stop() stops
  // accepting and drains its own in-flight connections; completion of the
  // APPLICATION-side work (handler settle + drain body-holds) arrives via
  // the onSettled callback. Websockets close first (1001) — they never
  // settle an HTTP request.
  const stopGraceful = (grace: GracefulStopOptions): Promise<{ timedOut: boolean }> =>
    new Promise((resolve) => {
      // DEAD-22: the courtesy-1001 sweep, hoisted so the first pass and the
      // finish() re-sweep share one implementation instead of a duplicated
      // inline loop. A ws upgrade admitted BEFORE the drain sweep can still
      // be parking on an await (auth middleware, body read) — its socket
      // only enters openSockets when Bun fires `open` synchronously inside
      // server.upgrade(), long after this first sweep ran. Sweep again at
      // finish() on BOTH paths: finish(false) fires only once inFlight
      // reaches zero, and an upgrade's `open` precedes its settle, so this
      // catches every late socket deterministically — without it the process
      // outlived close() and ignored SIGTERM (R4.10 child-process repro: 3x
      // SIGTERM no-op).
      const sweepLateSockets = (): void => {
        for (const ws of openSockets) {
          try {
            (ws as { close(code?: number, reason?: string): void }).close(
              1001,
              "server shutting down",
            );
          } catch {
            // A dead socket refusing a courtesy close is not worth stopping for.
          }
        }
        openSockets.clear();
      };
      sweepLateSockets();
      let done = false;
      let appSettled = false;
      let transportSettled = true;
      const stopping = transportClosers.get(server)?.() ?? server.stop();
      let timer: ReturnType<typeof setTimeout> | undefined;
      const finish = (timedOut: boolean): void => {
        if (done) return;
        done = true;
        if (timer !== undefined) clearTimeout(timer);
        sweepLateSockets();
        if (timedOut) server.stop(true);
        resolve({ timedOut });
      };
      // Operator escalation (second SIGTERM): kill sockets AND this wait.
      grace.registerForce?.(() => finish(true));
      // Arm the timer BEFORE the settled check (FINDING-5): a finish on the
      // already-settled path must be able to clear it. Infinity never arms
      // (setTimeout clamps it to ~1ms — FINDING-3).
      if (grace.drain !== Number.POSITIVE_INFINITY) {
        timer = setTimeout(() => finish(true), grace.drain);
      }
      const trySettle = (): void => {
        if (appSettled && transportSettled) finish(false);
      };
      if (stopping !== undefined && typeof (stopping as PromiseLike<unknown>).then === "function") {
        transportSettled = false;
        void Promise.resolve(stopping).then(
          () => {
            transportSettled = true;
            trySettle();
          },
          () => finish(true),
        );
      }
      if (
        grace.onSettled(() => {
          appSettled = true;
          sweepLateSockets();
          trySettle();
        })
      )
        appSettled = true;
      trySettle();
    });
  try {
    server.stopGraceful = stopGraceful;
  } catch {
    // A frozen handle: close() falls back to the embedded counter-wait.
  }
  // Register on the app's server slot so app.close() reaches this server no
  // matter how it was started (listen() or a direct startBunServer).
  attachServer(app, server);
  if (onListen !== undefined) {
    // A throwing user callback must never become an uncaughtException
    // (process-killer): it dies loudly in the console instead.
    queueMicrotask(() => {
      try {
        onListen();
      } catch (error) {
        console.error("onListen callback threw:", error);
      }
    });
  }
  return server;
};
