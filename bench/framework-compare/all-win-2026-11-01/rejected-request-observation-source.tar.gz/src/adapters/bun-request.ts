import { types as utilTypes } from "node:util";
import type { RequestObserver } from "../core/request-observation.ts";
import type { RequestSource } from "../core/request-source.ts";

const lookupGetter = Object.getOwnPropertyDescriptor(Object.prototype, "__lookupGetter__")
  ?.value as (this: object, key: PropertyKey) => (() => unknown) | undefined;
const nativeFunction = (value: unknown): boolean => {
  if (typeof value !== "function" || utilTypes.isProxy(value)) return false;
  const name = Object.getOwnPropertyDescriptor(value, "name")?.value as unknown;
  return (
    typeof name === "string" &&
    !name.startsWith("bound ") &&
    Function.prototype.toString.call(value).includes("[native code]")
  );
};

/** A server-owned observer; no request-specific closure exists before exposure. */
export const createBunRequestObserver = (
  server: { requestIP(request: Request): { readonly address: string } | null },
  waitUntil: unknown,
  prototype: object,
): RequestObserver => {
  const inspectable =
    !utilTypes.isProxy(prototype) && Object.getPrototypeOf(prototype) === Object.prototype;
  const descriptors = (inspectable ? Object.getOwnPropertyDescriptors(prototype) : {}) as Record<
    PropertyKey,
    PropertyDescriptor
  >;
  const native = new Set<unknown>();
  for (const key of Reflect.ownKeys(descriptors)) {
    const descriptor = descriptors[key]!;
    for (const value of [descriptor.value, descriptor.get])
      if (nativeFunction(value)) native.add(value);
  }
  const members = new Map(Reflect.ownKeys(descriptors).map((key) => [key, descriptors[key]!]));
  const canInspect = nativeFunction(lookupGetter);
  const parent = Object.getPrototypeOf(prototype) as object | null;
  const wait = { value: waitUntil };
  return {
    beforeRead(source: RequestSource, key: PropertyKey): boolean {
      // A changed parent may itself be a Proxy: do not inspect through it
      // before giving user code the same extended Request it received before.
      if (
        !inspectable ||
        !canInspect ||
        utilTypes.isProxy(source) ||
        Object.getPrototypeOf(source) !== prototype ||
        Object.getPrototypeOf(prototype) !== parent
      )
        return true;
      const member = typeof key === "number" ? String(key) : key;
      const expected = members.get(member);
      const getter = lookupGetter.call(source, key);
      if (getter !== undefined) return getter !== expected?.get || !native.has(getter);
      if (expected?.get !== undefined) return true;
      // With no accessor on the chain, reading the value cannot invoke a
      // Request hook. A replaced method is exposed before it is called.
      const value = (source as unknown as Record<PropertyKey, unknown>)[key];
      return value !== expected?.value || (typeof value === "function" && !native.has(value));
    },
    observe(source: RequestSource): void {
      const request = source as Request;
      Object.defineProperty(request, "waitUntil", wait);
      Object.defineProperty(request, "runtime", {
        enumerable: true,
        value: { name: "bun", bun: { server } },
      });
      Object.defineProperty(request, "ip", {
        enumerable: true,
        configurable: true,
        get() {
          return server?.requestIP(request)?.address;
        },
      });
    },
  };
};
