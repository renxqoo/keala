import type { RequestSource } from "./request-source.ts";

export interface RequestObserver {
  observe(source: RequestSource): void;
  /** A non-native member may hand its receiver to user code. */
  beforeRead(source: RequestSource, key: PropertyKey): boolean;
}

const pending = new WeakMap<RequestSource, RequestObserver>();
let enabled = false;

export const deferRequestObservation = (source: RequestSource, observer: RequestObserver): void => {
  enabled = true;
  pending.set(source, observer);
};

/** Public Request delivery is the single observation boundary for all transports. */
export const observeRequestSource = (source: RequestSource): RequestSource => {
  if (!enabled) return source;
  const observer = pending.get(source);
  if (observer !== undefined) {
    pending.delete(source);
    observer.observe(source);
  }
  return source;
};

/** Preserve prototype hooks: expose extensions before invoking user members. */
export const beforeSourceRead = (source: RequestSource, key: PropertyKey): void => {
  if (!enabled) return;
  const observer = pending.get(source);
  if (observer !== undefined && observer.beforeRead(source, key)) observeRequestSource(source);
};
