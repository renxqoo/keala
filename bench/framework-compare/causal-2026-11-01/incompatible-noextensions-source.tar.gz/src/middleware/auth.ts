/**
 * Request guards — HTTP authentication middleware (handlers layer).
 *
 * - basicAuth: RFC 7617 (case-insensitive scheme, UTF-8-fatal decode,
 *   NUL/whitespace/control rejection, length caps, sanitized realm challenge)
 * - bearerAuth: RFC 6750 (opaque-token validation, error="invalid_token")
 *
 * Credential verification always delegates to the caller's `verify` —
 * never compare plaintext strings with `===`; pair with the password
 * helpers (`keala/helpers/password`) for PBKDF2/argon2 round-trips.
 */

import { statusMessage } from "../http/status.ts";
import type { RouteHandler } from "../router/router.ts";

// ---------------------------------------------------------------------------
// timingSafeEqual — constant-time comparison for secrets (M7)
// ---------------------------------------------------------------------------

const tsencoder = new TextEncoder();

/**
 * Constant-time equality for tokens/secrets. For equal-length inputs every
 * byte is compared (no short-circuit); different lengths are inherently
 * public knowledge (the wire carries them) and return immediately.
 */
export const timingSafeEqual = (a: string | Uint8Array, b: string | Uint8Array): boolean => {
  const bytesA = typeof a === "string" ? tsencoder.encode(a) : a;
  const bytesB = typeof b === "string" ? tsencoder.encode(b) : b;
  if (bytesA.length !== bytesB.length) return false;
  let diff = 0;
  for (let i = 0; i < bytesA.length; i++) {
    diff |= bytesA[i]! ^ bytesB[i]!;
  }
  return diff === 0;
};

// ---------------------------------------------------------------------------
// Basic authentication (RFC 7617)
// ---------------------------------------------------------------------------

export interface BasicAuthOptions {
  /** Accept the credentials; compare hashes, never plaintext with `===`. */
  verify?(username: string, password: string): boolean | Promise<boolean>;
  /** Static credentials (timing-safe — no `verify` needed for simple cases). */
  username?: string;
  password?: string;
  /** Protection space label. Default "Restricted". */
  realm?: string;
}

const MAX_CREDENTIAL_BYTES = 1024;

const decodeBasic = (encoded: string): { username: string; password: string } | null => {
  if (encoded.length === 0 || encoded.length > 2048) return null;
  try {
    // Whitespace is tolerated by some base64 decoders; strip it ourselves.
    const bytes = Buffer.from(encoded.replaceAll(/\s+/g, ""), "base64");
    if (bytes.length === 0 || bytes.length > MAX_CREDENTIAL_BYTES) return null;
    // Invalid UTF-8 credentials are a rejection, not a crash.
    const decoded = new TextDecoder("utf-8", { fatal: true }).decode(bytes);
    if (decoded.includes("\0")) return null;
    const colon = decoded.indexOf(":");
    if (colon <= 0) return null; // no colon, or empty username
    return { username: decoded.slice(0, colon), password: decoded.slice(colon + 1) };
  } catch {
    return null;
  }
};

/** Split an Authorization header into (lowercased scheme, remainder). */
const authScheme = (header: string): { scheme: string; rest: string } => {
  const space = header.indexOf(" ");
  if (space === -1) return { scheme: header.toLowerCase(), rest: "" };
  return { scheme: header.slice(0, space).toLowerCase(), rest: header.slice(space + 1) };
};

/**
 * Realm payload for a WWW-Authenticate challenge. `"` and `\` are stripped:
 * a stray backslash is an escape in a quoted-string (RFC 9110 §5.6.4), so a
 * realm ending in one — `realm="My\"` — used to terminate the quote early
 * and corrupt the challenge (SEC-5). A realm that strips to nothing is a
 * setup error, not a silent empty protection-space label.
 *
 * Shared by every challenge-issuing guard (basic/bearer here, apiKeyAuth in
 * its tier) so the quoted-string rules cannot drift apart.
 */
export const realmPayload = (middleware: string, realm: string | undefined): string => {
  const stripped = (realm ?? "Restricted").replaceAll('"', "").replaceAll("\\", "");
  if (stripped.length === 0) {
    throw new TypeError(`${middleware}: realm must keep characters other than '"' and "\\"`);
  }
  return stripped;
};

export const basicAuth = (options: BasicAuthOptions): RouteHandler => {
  const hasStatic = options.username !== undefined && options.password !== undefined;
  if (hasStatic && typeof options?.verify === "function") {
    throw new TypeError("basicAuth: provide either { username, password } or { verify }, not both");
  }
  if (!hasStatic && typeof options?.verify !== "function") {
    throw new TypeError("basicAuth requires { verify } or { username, password }");
  }
  const realm = realmPayload("basicAuth", options.realm);
  const challenge = `Basic realm="${realm}", charset="UTF-8"`;
  return async (c, next) => {
    // The auth-scheme is case-insensitive per RFC 7617.
    const { scheme, rest } = authScheme(c.header("authorization"));
    let accepted = false;
    if (scheme === "basic") {
      const credentials = decodeBasic(rest.trim());
      if (credentials !== null) {
        if (hasStatic) {
          // Review M7: `&&` short-circuits — a wrong username skips the
          // password comparison, leaking username correctness via timing.
          // Compute both, then combine (the & on booleans is non-short-circuit).
          const userOk = timingSafeEqual(credentials.username, options.username as string);
          const passOk = timingSafeEqual(credentials.password, options.password as string);
          accepted = userOk === passOk && userOk; // both true → true
        } else {
          accepted = await options.verify!(credentials.username, credentials.password);
        }
      }
    }
    if (!accepted) {
      return c.text(statusMessage(401), 401, { "www-authenticate": challenge });
    }
    await next();
  };
};

// ---------------------------------------------------------------------------
// Bearer authentication (RFC 6750)
// ---------------------------------------------------------------------------

export interface BearerAuthOptions {
  /** Accept the token; compare hashes, never plaintext with `===`. */
  verify?(token: string): boolean | Promise<boolean>;
  /** Static token(s) — timing-safe comparison (no `verify` needed). */
  token?: string | string[];
  /** Protection space label. Default "Restricted". */
  realm?: string;
}

const MAX_TOKEN_BYTES = 8192;

/** True for any whitespace or C0 control byte — never valid inside a token.
 * Shared with apiKeyAuth's key grammar so the malformed-credential rules
 * stay identical across guards. */
export const hasWhitespaceOrControl = (value: string): boolean => {
  for (let i = 0; i < value.length; i++) {
    const code = value.charCodeAt(i);
    if (code <= 0x20 || code === 0x7f) return true;
  }
  return false;
};

export const bearerAuth = (options: BearerAuthOptions): RouteHandler => {
  const tokenOption = options.token;
  const hasToken = tokenOption !== undefined;
  const tokens: string[] = Array.isArray(tokenOption)
    ? tokenOption
    : tokenOption !== undefined
      ? [tokenOption]
      : [];
  // Review M7: both paths given → verify is silently dead code. An empty
  // token array silently rejects everything. Both are assembly bugs — loud.
  if (hasToken && typeof options.verify === "function") {
    throw new TypeError("bearerAuth: provide either { token } or { verify }, not both");
  }
  if (hasToken && tokens.length === 0) {
    throw new TypeError("bearerAuth: token array must not be empty");
  }
  if (!hasToken && typeof options?.verify !== "function") {
    throw new TypeError("bearerAuth requires { verify } or { token }");
  }
  const realm = realmPayload("bearerAuth", options.realm);
  const challenge = `Bearer realm="${realm}"`;
  return async (c, next) => {
    const { scheme, rest } = authScheme(c.header("authorization"));
    let token: string | null = null;
    if (scheme === "bearer") {
      const candidate = rest.trim();
      token =
        candidate.length > 0 &&
        candidate.length <= MAX_TOKEN_BYTES &&
        !hasWhitespaceOrControl(candidate)
          ? candidate
          : null;
    }
    // RFC 6750 §3.1 three-way: a PRESENT but malformed token (wrong scheme,
    // internal whitespace, control bytes, empty) is `invalid_request` (400);
    // a well-formed token that FAILS verification is `invalid_token` (401).
    if (token === null) {
      const hasAuth = c.header("authorization").length > 0;
      if (hasAuth) {
        return c.text(statusMessage(400), 400, {
          "www-authenticate": `${challenge}, error="invalid_request"`,
        });
      }
      return c.text(statusMessage(401), 401, { "www-authenticate": challenge });
    }
    const validToken = token as string; // null already returned
    const verifyFn = options.verify as (t: string) => boolean | Promise<boolean>;
    const accepted = hasToken
      ? tokens.some((t) => timingSafeEqual(t, validToken))
      : await verifyFn(validToken);
    if (!accepted) {
      return c.text(statusMessage(401), 401, {
        "www-authenticate": `${challenge}, error="invalid_token"`,
      });
    }
    await next();
  };
};
