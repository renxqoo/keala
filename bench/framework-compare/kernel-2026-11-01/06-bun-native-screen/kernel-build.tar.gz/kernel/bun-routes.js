import { EMPTY_PARAMS, pathOf } from "./router.js";
import { ERROR_REPLY, isPromise, toResponse } from "./reply.js";
const METHODS = new Set([
    "GET",
    "HEAD",
    "POST",
    "PUT",
    "PATCH",
    "DELETE",
    "OPTIONS",
    "TRACE",
    "CONNECT",
]);
const empty = () => ({ routes: Object.create(null), count: 0 });
const pattern = (definition) => {
    const path = definition.path.length > 1 && definition.path.endsWith("/")
        ? definition.path.slice(0, -1)
        : definition.path;
    if (!path.startsWith("/") || /[^\x21-\x7e]/.test(path) || /[%\\?#.]/.test(path))
        return;
    const parts = path === "/" ? [] : path.slice(1).split("/");
    const names = [], native = [];
    let wildcard = false;
    let wildPrefix;
    for (let index = 0; index < parts.length; index++) {
        const part = parts[index];
        if (part.startsWith(":")) {
            const name = part.slice(1);
            if (!/^[A-Za-z_][A-Za-z0-9_]*$/.test(name) || names.includes(name))
                return;
            names.push(name);
            native.push(part);
        }
        else if (part.startsWith("*")) {
            const name = part.slice(1) || "wildcard";
            if (index !== parts.length - 1 ||
                !/^[A-Za-z_][A-Za-z0-9_]*$/.test(name) ||
                names.includes(name))
                return;
            if (!names.length)
                wildPrefix = native.length ? "/" + native.join("/") : "";
            names.push(name);
            native.push("*");
            wildcard = true;
        }
        else {
            if (!/^[A-Za-z0-9_-]+$/.test(part))
                return;
            native.push(part);
        }
    }
    return { path: "/" + native.join("/"), names, wildcard, wildPrefix };
};
// Native URL matching and decoding differ for encoded static literals, malformed
// escapes, dot segments and empty segments. One lazy URL observation guards the
// boundary; ordinary requests still avoid Core selection and parameter matching.
const specialTarget = (url) => {
    if (url.includes("%") || url.includes("\\") || url.includes("/.") || url.includes("#"))
        return true;
    const start = url.indexOf("/", url.indexOf("://") + 3);
    if (start === -1)
        return true;
    const query = url.indexOf("?", start), end = query === -1 ? url.length : query;
    return url.indexOf("//", start) !== -1 || (end - start > 1 && url.charCodeAt(end - 1) === 47);
};
const safe = (value, head) => {
    try {
        return toResponse(value, head);
    }
    catch {
        return toResponse(ERROR_REPLY, head);
    }
};
const finish = (value, head) => {
    if (typeof value !== "string")
        throw new TypeError("text handler must return a string");
    return toResponse(value, head);
};
export const compileBunTextRoutes = (executable) => {
    if (!executable.textRoutes?.length)
        return empty();
    const tables = new Map();
    const bareWildPrefixes = new Set();
    let parameterWild = false;
    for (const definition of executable.textRoutes) {
        if (!METHODS.has(definition.method))
            return empty();
        const compiled = pattern(definition);
        if (!compiled)
            return empty();
        if (compiled.wildcard) {
            if (compiled.wildPrefix === undefined)
                parameterWild = true;
            else
                bareWildPrefixes.add(compiled.wildPrefix);
        }
        let methods = tables.get(compiled.path);
        if (!methods) {
            methods = new Map();
            tables.set(compiled.path, methods);
        }
        if (methods.has(definition.method))
            return empty();
        methods.set(definition.method, {
            handler: definition.handler,
            names: Object.freeze(compiled.names),
            wildcard: compiled.wildcard,
            wildPrefix: compiled.wildPrefix,
        });
    }
    const fail = (error, head) => {
        try {
            const result = executable.fail(error);
            return isPromise(result)
                ? Promise.resolve(result).then((value) => safe(value, head), () => safe(ERROR_REPLY, head))
                : safe(result, head);
        }
        catch {
            return safe(ERROR_REPLY, head);
        }
    };
    const routes = Object.create(null);
    for (const [path, methods] of tables) {
        routes[path] = (request) => {
            const method = request.method, head = method === "HEAD";
            try {
                const plan = methods.get(method);
                // Never let a static path for another method shadow a parameter route.
                // HEAD without an explicit handler must use the core's GET fallback.
                if (!plan)
                    return executable.fetch(request);
                const url = request.url;
                if (specialTarget(url))
                    return executable.fetch(request);
                let params = EMPTY_PARAMS;
                if (plan.wildcard) {
                    // Bun 1.4.4 exposes no wildcard field. Only a literal prefix can be
                    // sliced safely; wildcard prefixes containing params use the core.
                    if (!plan.wildPrefix || parameterWild)
                        return executable.fetch(request);
                    const matchedPath = pathOf(url), prefix = plan.wildPrefix;
                    if (bareWildPrefixes.has(matchedPath) || !matchedPath.startsWith(prefix + "/"))
                        return executable.fetch(request);
                    const owned = Object.create(null);
                    owned[plan.names[0]] = matchedPath.slice(prefix.length + 1);
                    params = owned;
                }
                else if (plan.names.length) {
                    const native = request.params;
                    if (native === null || typeof native !== "object")
                        return executable.fetch(request);
                    const owned = Object.create(null);
                    for (const name of plan.names) {
                        if (!Object.hasOwn(native, name))
                            return executable.fetch(request);
                        const value = native[name];
                        if (typeof value !== "string" || value.length === 0 || /[%\\/\uFFFD]/.test(value))
                            return executable.fetch(request);
                        owned[name] = value; // Native Bun already decoded once; never decode again.
                    }
                    params = owned;
                }
                const result = plan.handler(params);
                return isPromise(result)
                    ? Promise.resolve(result)
                        .then((value) => finish(value, head))
                        .catch((error) => fail(error, head))
                    : finish(result, head);
            }
            catch (error) {
                return fail(error, head);
            }
        };
    }
    // Counts registered NativePath callbacks, not unconditional fast endpoints:
    // method gaps and guarded URL/wildcard cases still use the complete core.
    return { routes, count: tables.size };
};
