import { afterEach, describe, expect, it } from "vitest";
import { request } from "node:http";
import { Kernel, Reply, type Executable } from "../../experimental/kernel/kernel.ts";
import { compileBunTextRoutes } from "../../experimental/kernel/bun-routes.ts";
import type { Params } from "../../experimental/kernel/reply.ts";

const servers: Array<{ stop(force: boolean): Promise<void> }> = [];
const start = (kernel: Kernel) => {
  const executable = kernel.build();
  let fallback = 0;
  const traced: Executable = {
    ...executable,
    fetch(incoming) {
      fallback++;
      return executable.fetch(incoming);
    },
  };
  const compiled = compileBunTextRoutes(traced);
  const server = Bun.serve({
    hostname: "127.0.0.1",
    port: 0,
    routes: compiled.routes,
    fetch: traced.fetch,
  });
  servers.push(server);
  return { port: server.port!, count: compiled.count, fallback: () => fallback };
};
const get = (port: number, path = "/", method = "GET") =>
  new Promise<{
    status: number;
    body: string;
    headers: import("node:http").IncomingHttpHeaders;
  }>((resolve, reject) => {
    const outgoing = request(
      { host: "127.0.0.1", port, path, method, agent: false },
      (incoming) => {
        const chunks: Buffer[] = [];
        incoming.on("data", (chunk: Buffer) => chunks.push(chunk));
        incoming.once("error", reject);
        incoming.once("end", () =>
          resolve({
            status: incoming.statusCode!,
            body: Buffer.concat(chunks).toString(),
            headers: incoming.headers,
          }),
        );
      },
    );
    outgoing.once("error", reject);
    outgoing.setTimeout(2000, () => outgoing.destroy(new Error("HTTP timeout")));
    outgoing.end();
  });
afterEach(async () => {
  await Promise.all(servers.splice(0).map((server) => server.stop(true)));
});

describe.skipIf(!process.versions.bun)("Bun text route lowering", () => {
  it("calls plain handlers per request without core selection or response caching", async () => {
    let calls = 0;
    const executable = new Kernel().text("GET", "/", () => String(++calls)).build();
    const guarded: Executable = {
      ...executable,
      select() {
        throw new Error("native selected core");
      },
      invoke() {
        throw new Error("native invoked core");
      },
      fetch() {
        throw new Error("plain native route fell back");
      },
    };
    const compiled = compileBunTextRoutes(guarded);
    expect(compiled.count).toBe(1);
    const first = compiled.routes["/"]!(new Request("http://test/"));
    const second = compiled.routes["/"]!(new Request("http://test/"));
    expect(first).not.toBe(second);
    expect(await (first as Response).text()).toBe("1");
    expect(await (second as Response).text()).toBe("2");
    const server = start(new Kernel().text("GET", "/", () => String(++calls)));
    expect((await get(server.port)).body).toBe("3");
    expect((await get(server.port)).body).toBe("4");
    expect(calls).toBe(4);
    expect(server.fallback()).toBe(0);
  });

  it("serves the twelve benchmark shapes and owned decoded params", async () => {
    const kernel = new Kernel()
      .text("GET", "/user", () => "user")
      .text("GET", "/user/comments", () => "user/comments")
      .text("GET", "/user/avatar", () => "user/avatar")
      .text("GET", "/user/lookup/username/:username", (p) => p.username!)
      .text("GET", "/user/lookup/email/:address", (p) => p.address!)
      .text("GET", "/event/:id", (p) => p.id!)
      .text("GET", "/event/:id/comments", (p) => p.id!)
      .text("POST", "/event/:id/comment", (p) => `${p.id} comment`)
      .text("GET", "/map/:location/events", (p) => p.location!)
      .text("GET", "/status", () => "status")
      .text("GET", "/very/deeply/nested/route/hello/there", () => "hello there")
      .text("GET", "/static/*", (p) => p.wildcard!);
    const server = start(kernel);
    expect(server.count).toBe(12);
    for (const [method, path, expected] of [
      ["GET", "/user", "user"],
      ["GET", "/user/comments", "user/comments"],
      ["GET", "/user/avatar", "user/avatar"],
      ["GET", "/user/lookup/username/ada", "ada"],
      ["GET", "/user/lookup/email/a%40b.test", "a@b.test"],
      ["GET", "/event/42", "42"],
      ["GET", "/event/42/comments", "42"],
      ["POST", "/event/42/comment", "42 comment"],
      ["GET", "/map/singapore/events", "singapore"],
      ["GET", "/status", "status"],
      ["GET", "/very/deeply/nested/route/hello/there", "hello there"],
      ["GET", "/static/a/b.js", "a/b.js"],
    ])
      expect(await get(server.port, path, method)).toMatchObject({ status: 200, body: expected });
  });

  it("keeps HEAD, OPTIONS, 405 and cross-method static/parameter semantics", async () => {
    const server = start(
      new Kernel()
        .text("GET", "/users/:id", (p) => "id:" + p.id)
        .text("POST", "/users/new", () => "create")
        .text("GET", "/hello", () => "你好")
        .text("HEAD", "/explicit", () => "explicit"),
    );
    expect(await get(server.port, "/users/new")).toMatchObject({ status: 200, body: "id:new" });
    expect(await get(server.port, "/users/new", "POST")).toMatchObject({ body: "create" });
    expect(await get(server.port, "/hello", "HEAD")).toMatchObject({
      status: 200,
      body: "",
      headers: { "content-length": "6" },
    });
    expect(await get(server.port, "/explicit", "HEAD")).toMatchObject({
      status: 200,
      body: "",
      headers: { "content-length": "8" },
    });
    expect(await get(server.port, "/hello", "POST")).toMatchObject({
      status: 405,
      headers: { allow: "GET, HEAD, OPTIONS" },
    });
    expect(await get(server.port, "/hello", "OPTIONS")).toMatchObject({
      status: 204,
      body: "",
      headers: { allow: "GET, HEAD, OPTIONS" },
    });
  });

  it("preserves dead static backtracking, wildcard empty capture and encoded targets", async () => {
    let calls = 0;
    const server = start(
      new Kernel()
        .text("GET", "/fixed/other", () => "static")
        .text("GET", "/:id/end", (p) => p.id!)
        .text("GET", "/files/*tail", (p) => p.tail!)
        .text("GET", "/x/:id", (p) => {
          calls++;
          return p.id!;
        })
        .text("GET", "/*root", (p) => p.root!),
    );
    for (const [path, expected] of [
      ["/fixed/end", "fixed"],
      ["/files", ""],
      ["/files/", ""],
      ["/files/a/b", "a/b"],
      ["/x/a%2Fb", "a/b"],
      ["/x/a%252Fb", "a%2Fb"],
      ["/x/%E4%B8%96%E7%95%8C", "世界"],
      ["/%66ixed/other", "static"],
      ["/public/../fixed/other", "static"],
      ["/public/%2e%2e/fixed/other", "static"],
      ["/public\\..\\fixed\\other", "static"],
    ])
      expect(await get(server.port, path)).toMatchObject({ status: 200, body: expected });
    expect(calls).toBe(3);
    expect(await get(server.port, "/x/%ZZ")).toMatchObject({ status: 400 });
    expect(calls).toBe(3);
  });

  it("slices literal-prefix wildcards without core matching and falls back for bare/parameter prefixes", async () => {
    const server = start(new Kernel().text("GET", "/static/*tail", (p) => p.tail!));
    expect(await get(server.port, "/static/a/b?q=1")).toMatchObject({ body: "a/b" });
    expect(server.fallback()).toBe(0);
    expect(await get(server.port, "/static")).toMatchObject({ body: "" });
    expect(server.fallback()).toBe(1);
    const parameter = start(new Kernel().text("GET", "/x/:id/*tail", (p) => p.id + ":" + p.tail));
    expect(await get(parameter.port, "/x/7/a/b")).toMatchObject({ body: "7:a/b" });
    expect(parameter.fallback()).toBe(1);
  });

  it("does not let a parent wildcard shadow a bare child wildcard or normalized static route", async () => {
    const server = start(
      new Kernel()
        .text("GET", "/files/*tail", (p) => "parent:" + p.tail)
        .text("GET", "/files/child/*tail", (p) => "child:" + p.tail)
        .text("GET", "/files/fixed", () => "fixed"),
    );
    for (const [path, body] of [
      ["/files/child", "child:"],
      ["/files/child/", "child:"],
      ["/files/fixed/", "fixed"],
    ])
      expect(await get(server.port, path)).toMatchObject({ body });
  });

  it("owns async params before native storage can be reused and validates thenables/results", async () => {
    const retained: Params[] = [];
    const server = start(
      new Kernel()
        .text("GET", "/x/:__proto__", async (p) => {
          retained.push(p);
          await new Promise((resolve) => setTimeout(resolve, 2));
          return p.__proto__!;
        })
        .text("GET", "/bad", (() => 7) as unknown as () => string)
        .text(
          "GET",
          "/then",
          () =>
            ({
              // eslint-disable-next-line unicorn/no-thenable -- foreign thenables are explicitly supported
              then(resolve: (value: string) => unknown) {
                return Promise.resolve(resolve("thenable"));
              },
            }) as PromiseLike<string>,
        )
        .text("GET", "/reject", () => Promise.reject(new Error("reject")))
        .onError(() => new Reply("mapped", 502)),
    );
    expect(
      await Promise.all([get(server.port, "/x/one"), get(server.port, "/x/two")]),
    ).toMatchObject([{ body: "one" }, { body: "two" }]);
    expect(retained[0]).not.toBe(retained[1]);
    expect(Object.getPrototypeOf(retained[0])).toBe(null);
    expect(retained.map((p) => p.__proto__).toSorted()).toEqual(["one", "two"]);
    expect(await get(server.port, "/then")).toMatchObject({ body: "thenable" });
    for (const path of ["/bad", "/reject"])
      expect(await get(server.port, path)).toMatchObject({ status: 502, body: "mapped" });
  });

  it("returns an empty table for unsupported apps and never bypasses middleware", async () => {
    for (const path of ["/x/%25", "/x\\y", "/x/../y", "/你好", "/a.b"]) {
      const app = new Kernel().text("GET", path, () => "fallback");
      expect(compileBunTextRoutes(app.build()).count).toBe(0);
    }
    for (const method of ["ALL", "CUSTOM"])
      expect(compileBunTextRoutes(new Kernel().text(method, "/", () => "").build()).count).toBe(0);
    const server = start(
      new Kernel().text("GET", "/private", () => "unsafe").use("/", () => new Reply("denied", 403)),
    );
    expect(server.count).toBe(0);
    expect(await get(server.port, "/private")).toMatchObject({ status: 403, body: "denied" });
    expect(
      compileBunTextRoutes(new Kernel().route("GET", "/", () => new Response("fetch")).build())
        .count,
    ).toBe(0);
  });

  it("falls back before invoking when native captures are absent or malformed", async () => {
    let calls = 0,
      fallback = 0;
    const executable = new Kernel()
      .text("GET", "/x/:id", (p) => {
        calls++;
        return p.id!;
      })
      .build();
    const compiled = compileBunTextRoutes({
      ...executable,
      fetch() {
        fallback++;
        return new Response("fallback");
      },
    });
    for (const params of [undefined, null, { id: 7 }, {}, { id: "" }]) {
      const incoming = Object.assign(new Request("http://test/x/a"), { params });
      expect(await (await compiled.routes["/x/:id"]!(incoming)).text()).toBe("fallback");
    }
    expect([calls, fallback]).toEqual([0, 5]);
  });
});
