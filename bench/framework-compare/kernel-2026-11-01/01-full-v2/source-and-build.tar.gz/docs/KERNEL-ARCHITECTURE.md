# 独立 Kernel 原型：把成本放在需要能力的请求上

这是一套新 API 的可运行实验，入口在 `experimental/kernel`，尚未加入发布包。旧 `src` 和 Keala 对外 API 保留。Hello World 与十二路由是第一阶段的性能验收；它们不能代替通用框架的功能验收。

```ts
import { Kernel, json } from "../experimental/kernel/kernel.ts";
import { listenNode } from "../experimental/kernel/node.ts";

const app = new Kernel()
  .text("GET", "/", () => "Hello World")
  .text("GET", "/user/:id", (params) => params.id!)
  .route("POST", "/echo/:id", async (request, params) =>
    json({ id: params.id, body: await request.text() }),
  )
  .use("/private", async (request, next) => {
    if (!request.headers.has("authorization")) return new Response("denied", { status: 403 });
    return await next();
  });
const server = await listenNode(app, { port: 3000 });
// Bun 对应 listenBun(app, options)，不依赖 srvx。
await server.close(5000);
```

## 选择的架构

构建器拥有注册记录；`build()` 生成封闭的执行计划。执行计划拥有路由表、处理器引用、中间件及错误映射。连接和输出队列由适配器拥有。每个动态匹配的参数袋由该请求独占，不跨请求回收，不把保留的参数指向可复用数组。

路由采用 method → 静态 Map / 分段 trie。静态命中复用固定的匹配结果和只读空参数；动态路径才创建参数对象。trie 优先尝试静态分支，失败后回退参数和末尾通配。选择它是因为模式有限、冲突可检查、无需生成运行时代码。大路由表或复杂表达式是否需要另一种算法，必须另测；本轮只有 1/12 条注册路由。

端点显式声明能力，编译器不分析 `handler.toString()`，也不把看起来恒定的处理器替换成缓存响应。每个请求都会调用处理器：

| 能力                                          | Node                                                                                       | Bun                                                         |
| --------------------------------------------- | ------------------------------------------------------------------------------------------ | ----------------------------------------------------------- |
| `text(method,path,params=>string)`            | 原生 IncomingMessage/ServerResponse，直接写字符串；不创建 Fetch Request、Response、Context | 使用原生 Request，仅在输出时创建 Response；不添加 srvx 扩展 |
| `route(method,path,(Request,params)=>Result)` | 按需构造标准 Fetch Request，包括请求体流和断连 signal                                      | 使用原生 Fetch Request                                      |
| 命中 `.use(prefix, middleware)`               | 提升到 Fetch 执行路径                                                                      | 执行 Fetch 中间件链                                         |

中间件按注册顺序执行，字面前缀具有路径段边界；同一作用域的 404/405 也经过中间件。`next()` 必须 await 或 return；重复调用失败，未观察的分支失败，并等待已启动的分支结束。响应可以是字符串、标准 Response，或者保存状态和响应头快照的 Reply。错误映射失败时回退到固定 500。

Node 执行器把连接、请求体和响应流的善后放在冷支路；纯文本同步请求不安装每请求完成监听器。连接级记录在关闭阶段跟踪物理输出完成，处理排队的 HTTP/1 响应及强制关闭期限。Fetch 流遵守背压，在断连时取消 reader；未读取的上传需排空或结束连接，不能阻塞后续请求。Bun 使用原生服务器的停止和强制停止能力。

## 已比较的方向

| 方向                                            | 收益与代价                                                                 | 本轮处理                         |
| ----------------------------------------------- | -------------------------------------------------------------------------- | -------------------------------- |
| 继续优化旧 Context/srvx 链                      | 兼容现有行为，但原始 Request 扩展、Context、响应兼容等仍是基准路径成本     | 保留旧入口作对照                 |
| 所有平台统一 Fetch 调度                         | API 一致、适配简单；Node 纯文本也需对象转换和 Web 流桥接                   | 用于显式 Fetch 能力              |
| 封闭路由计划 + 分平台执行器                     | 纯文本省掉不需要的通用层；代价是维护两种 transport 行为                    | 本轮候选                         |
| Bun 原生 routes、处理器源码代码生成、静态包缓存 | 有可能再省路由开销，但有解码、HEAD/405、动态处理器副作用和输出生命周期风险 | 暂未采用，不能算作已经实现的收益 |

## 与旧 Keala 的有意差异

- 所有注册需在首次 `build`、`fetch` 或监听前完成；运行中变更需新建快照。
- method-first 匹配。某方法的静态路由不会挡住另一方法的参数路由。HEAD 先显式路由再 GET；支持 ALL、自动 OPTIONS 和 Allow。
- 模式支持静态段、`:name` 和末尾 `*` / `*name`；拒绝可选参数、自定义正则、重复参数名和重复结构。忽略一个末尾斜杠。参数逐段解码，编码斜杠仍在一个参数中，错误编码返回 400。
- 没有旧 Context、动态状态、srvx Raw Request 的 `runtime/ip/waitUntil` 扩展、插件、WebSocket/SSE 专用 API、签名 Cookie 等兼容承诺。标准 Response 可以输出流及多条 Set-Cookie。
- Node 原型仅 HTTP/1，没有 TLS/upgrade、自定义 body 限额、过载保护和处理器 deadline。强制关闭能终止连接，不能中止任意永不结束的用户 JavaScript。
- 不承诺所有低层 HTTP 边界、URL 异常形式或两种运行时的完整一致性。已有行为测试覆盖常用路径及已发现的连接生命周期问题，后续迁移须建立完整合同矩阵。

## 验证与可复现性

运行 `npx vitest run test/experimental` 和 `bun --bun x vitest run test/experimental`。Node 原生适配器测试只在 Node 执行；Bun 原生适配器测试只在 Bun 执行，公共内核测试两边都运行。

本地编译：`npx tsc -p experimental/kernel/tsconfig.build.json --outDir /tmp/your-owned-directory/kernel`。性能打包时向 `pack-remote.mjs` 提供 `BENCH_KERNEL_DIST`，manifest 独立记录原型源码和编译摘要。`BENCH_FRAMEWORKS=kernel,keala,hono,h3` 选择原型和同机对照；原型未打包时该选择会拒绝。实验报告必须说明新 API 能力与旧框架不同，不能宣称旧 API 等价加速或据此承诺生产“全面领先”。

服务器仍采用 `REMOTE.md` 的单任务、限额、资源保护和清理流程；吞吐、延迟、每请求 CPU 都取真实 HTTP 样本，不以路由微基准代替。
