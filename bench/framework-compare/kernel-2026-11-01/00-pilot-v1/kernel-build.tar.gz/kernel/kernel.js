import { compileRoutes, pathOf, } from "./router.js";
import { ERROR_REPLY, PATH_ERROR, isPromise, toResponse, } from "./reply.js";
export { Reply, json } from "./reply.js";
const applies = (prefix, path) => prefix === "/" || path === prefix || path.startsWith(prefix + "/");
const runEndpoint = (selection, request) => {
    if (selection.kind === "miss")
        return selection.reply;
    if (selection.endpoint.kind === "fetch") {
        if (!request)
            throw new TypeError("Fetch endpoint requires Request capability");
        return selection.endpoint.handler(request, selection.params);
    }
    const result = selection.endpoint.handler(selection.params);
    if (typeof result === "string")
        return result;
    if (isPromise(result))
        return Promise.resolve(result).then((value) => {
            if (typeof value !== "string")
                throw new TypeError("text handler must return a string");
            return value;
        });
    throw new TypeError("text handler must return a string");
};
export class Kernel {
    #definitions = [];
    #layers = [];
    #error;
    #built;
    #assertOpen() {
        if (this.#built)
            throw new Error("kernel is sealed; build a new snapshot to change routes");
    }
    text(method, path, handler) {
        this.#assertOpen();
        if (typeof handler !== "function")
            throw new TypeError("handler must be a function");
        this.#definitions.push({
            method: this.#method(method),
            path,
            endpoint: { kind: "text", handler },
        });
        return this;
    }
    route(method, path, handler) {
        this.#assertOpen();
        if (typeof handler !== "function")
            throw new TypeError("handler must be a function");
        this.#definitions.push({
            method: this.#method(method),
            path,
            endpoint: { kind: "fetch", handler },
        });
        return this;
    }
    #method(method) {
        const value = method.toUpperCase();
        if (!/^[A-Z]+$/.test(value))
            throw new TypeError("invalid HTTP method");
        return value;
    }
    use(prefix, middleware) {
        this.#assertOpen();
        if (typeof middleware !== "function")
            throw new TypeError("middleware must be a function");
        if (!prefix.startsWith("/") ||
            prefix.includes("%") ||
            prefix.includes("?") ||
            prefix.includes("#") ||
            prefix.includes("*") ||
            prefix.includes(":"))
            throw new TypeError("middleware prefix must be a literal path");
        this.#layers.push({
            prefix: prefix.length > 1 && prefix.endsWith("/") ? prefix.slice(0, -1) : prefix,
            run: middleware,
        });
        return this;
    }
    onError(handler) {
        this.#assertOpen();
        if (typeof handler !== "function")
            throw new TypeError("error handler must be a function");
        this.#error = handler;
        return this;
    }
    build() {
        if (this.#built)
            return this.#built;
        const lookup = compileRoutes(this.#definitions);
        const select = (method, url) => {
            try {
                return lookup(method, url);
            }
            catch (error) {
                if (error instanceof URIError)
                    return { kind: "miss", path: pathOf(url), reply: PATH_ERROR };
                throw error;
            }
        };
        const layers = this.#layers.slice();
        const errorHandler = this.#error;
        const fail = (error) => {
            if (!errorHandler)
                return ERROR_REPLY;
            try {
                const result = errorHandler(error);
                return isPromise(result) ? Promise.resolve(result).catch(() => ERROR_REPLY) : result;
            }
            catch {
                return ERROR_REPLY;
            }
        };
        let chain = async (request, selection) => toResponse(await runEndpoint(selection, request));
        for (let i = layers.length - 1; i >= 0; i--) {
            const layer = layers[i], downstream = chain;
            chain = async (request, selection) => {
                if (!applies(layer.prefix, selection.path))
                    return downstream(request, selection);
                let advanced = false, observed = false;
                let pending;
                const next = () => {
                    if (advanced)
                        throw new Error("next() called twice");
                    advanced = true;
                    const branch = (pending = downstream(request, selection));
                    void branch.catch(() => undefined);
                    return {
                        then: (ok, bad) => {
                            observed = true;
                            return branch.then(ok, bad);
                        },
                    };
                };
                try {
                    const result = await layer.run(request, next);
                    if (advanced && !observed)
                        throw new Error("next() must be awaited or returned");
                    return toResponse(result);
                }
                finally {
                    // A floated branch may still be reading a body; join it before release.
                    if (pending)
                        await pending.catch(() => undefined);
                }
            };
        }
        const needsRequest = (selection) => (selection.kind === "route" && selection.endpoint.kind === "fetch") ||
            layers.some((layer) => applies(layer.prefix, selection.path));
        const invoke = (selection, request) => {
            if (layers.some((layer) => applies(layer.prefix, selection.path))) {
                if (!request)
                    throw new TypeError("middleware requires Request capability");
                return chain(request, selection);
            }
            return runEndpoint(selection, request);
        };
        const safeResponse = (value, head) => {
            try {
                return toResponse(value, head);
            }
            catch {
                return toResponse(ERROR_REPLY, head);
            }
        };
        const fetch = (request) => {
            const head = request.method === "HEAD";
            try {
                const result = invoke(select(request.method, request.url), request);
                return isPromise(result)
                    ? Promise.resolve(result)
                        .then((value) => toResponse(value, head))
                        .catch((error) => Promise.resolve(fail(error)).then((value) => safeResponse(value, head)))
                    : toResponse(result, head);
            }
            catch (error) {
                const result = fail(error);
                return isPromise(result)
                    ? Promise.resolve(result).then((value) => safeResponse(value, head))
                    : safeResponse(result, head);
            }
        };
        this.#built = Object.freeze({ select, needsRequest, invoke, fail, fetch });
        return this.#built;
    }
    fetch = (request) => this.build().fetch(request);
}
