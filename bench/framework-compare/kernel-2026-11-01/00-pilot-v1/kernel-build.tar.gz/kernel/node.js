/**
 * Experimental native node:http executor. No TLS, upgrades, overload policy,
 * custom body limits or per-handler deadlines. Fetch bodies use standard
 * Request/Response; native text never constructs either object.
 */
import { createServer } from "node:http";
import { Readable } from "node:stream";
import { ERROR_REPLY, PATH_ERROR, Reply, TEXT_TYPE, isPromise } from "./reply.js";
import { nodeDrain } from "./node-drain.js";
const EXCHANGE = Symbol("kernel.fetchExchange");
class InvalidTargetError extends Error {
}
const emptyStatus = (status) => status === 204 || status === 205 || status === 304;
const hasBody = (incoming) => incoming.headers["transfer-encoding"] !== undefined ||
    (incoming.headers["content-length"] !== undefined && incoming.headers["content-length"] !== "0");
const stopBody = (response) => {
    if (response.body !== null)
        void response.body.cancel().catch(() => undefined);
};
/** Fetch-only request state; listeners remain until physical output completes. */
class Exchange {
    controller = new AbortController();
    request;
    incoming;
    out;
    early = false;
    uploadReader;
    constructor(incoming, out, url) {
        this.incoming = incoming;
        this.out = out;
        const headers = new Headers();
        for (let i = 0; i < incoming.rawHeaders.length; i += 2)
            headers.append(incoming.rawHeaders[i], incoming.rawHeaders[i + 1]);
        const method = incoming.method ?? "GET";
        const body = method !== "GET" && method !== "HEAD" && hasBody(incoming)
            ? Readable.toWeb(incoming)
            : undefined;
        this.request = new Request(url, {
            method,
            headers,
            signal: this.controller.signal,
            ...(body === undefined ? {} : { body, duplex: "half" }),
        });
        out[EXCHANGE] = this;
        incoming.once("aborted", this.aborted);
        out.once("finish", this.finished);
        out.once("close", this.closed);
        if (incoming.destroyed || out.destroyed)
            this.aborted();
    }
    aborted = () => {
        if (!this.controller.signal.aborted)
            this.controller.abort(new DOMException("client disconnected", "AbortError"));
        void this.uploadReader?.cancel("client disconnected").catch(() => undefined);
    };
    drainUnread() {
        if (!this.request.body || this.uploadReader)
            return;
        const reader = this.request.body.getReader();
        this.uploadReader = reader;
        void this.drainUpload(reader);
    }
    async drainUpload(reader) {
        try {
            while (!(await reader.read()).done) {
                /* discard an unclaimed body */
            }
        }
        catch {
            this.aborted();
        }
        finally {
            reader.releaseLock();
            this.uploadReader = undefined;
            if (this.out.writableFinished)
                this.incoming.off("aborted", this.aborted);
        }
    }
    finished = () => {
        if (this.early) {
            this.aborted();
            this.incoming.destroy();
        }
        if (!this.uploadReader)
            this.incoming.off("aborted", this.aborted);
        this.out.off("finish", this.finished);
        this.out.off("close", this.closed);
        this.out[EXCHANGE] = undefined;
    };
    closed = () => {
        if (!this.out.writableFinished)
            this.aborted();
        this.finished();
    };
}
const requestUrl = (incoming, port) => {
    const target = incoming.url === "*" ? "/" : (incoming.url ?? "/");
    if (target.startsWith("/"))
        return `http://${incoming.headers.host ?? `127.0.0.1:${port}`}${target}`;
    if (/^https?:\/\//.test(target) && !target.includes("\\"))
        return target;
    throw new InvalidTargetError("unsupported request target");
};
/** Immutable snapshots avoid observing live Headers again after an await. */
const snapshot = (headers, status, head, body) => {
    const output = [];
    for (const [name, value] of headers) {
        if (name === "set-cookie" || name === "transfer-encoding" || name === "connection")
            continue;
        if (emptyStatus(status) && (name === "content-type" || name === "content-length"))
            continue;
        if (name === "content-length" && body && !head)
            continue;
        output.push(name, value);
    }
    for (const cookie of headers.getSetCookie())
        output.push("set-cookie", cookie);
    return output;
};
const waitForDrain = (out) => new Promise((resolve, reject) => {
    const cleanup = () => {
        out.off("drain", drained);
        out.off("close", closed);
        out.off("error", failed);
    };
    const drained = () => {
        cleanup();
        resolve();
    };
    const closed = () => {
        cleanup();
        reject(new Error("client disconnected"));
    };
    const failed = (error) => {
        cleanup();
        reject(error);
    };
    out.once("drain", drained);
    out.once("close", closed);
    out.once("error", failed);
    if (out.destroyed)
        closed();
});
const streamResponse = async (response, out, headers) => {
    const reader = response.body.getReader();
    const cancel = () => {
        void reader.cancel("client disconnected").catch(() => undefined);
    };
    out.once("close", cancel);
    if (out.destroyed)
        cancel();
    try {
        // A producer error before commitment can still use the kernel error mapper.
        let chunk = await reader.read();
        if (out.destroyed)
            return;
        out.writeHead(response.status, response.statusText || undefined, headers);
        while (!chunk.done) {
            if (!out.write(chunk.value))
                await waitForDrain(out);
            chunk = await reader.read();
            if (out.destroyed)
                return;
        }
        out.end();
    }
    catch (error) {
        void reader.cancel(error).catch(() => undefined);
        throw error;
    }
    finally {
        out.off("close", cancel);
        reader.releaseLock();
    }
};
export const listenNode = async (kernel, options = {}) => {
    const executable = kernel.build();
    let port = options.port ?? 3000;
    let closing;
    let resolveClose;
    let forceTimer;
    let stopping = false, forced = false, serverClosed = false, asynchronous = 0;
    const server = createServer(dispatch);
    const drain = nodeDrain(server, checkClose);
    function checkClose() {
        if (!stopping)
            return;
        drain.closeIdle();
        if (serverClosed && (forced || asynchronous === 0)) {
            clearTimeout(forceTimer);
            resolveClose?.({ forced });
            resolveClose = undefined;
        }
    }
    function force() {
        forced = true;
        drain.force();
        checkClose();
    }
    function prepare(incoming, out) {
        // Early replies with an actively consumed upload cannot safely preserve
        // its connection. Unclaimed native bodies are drained without Fetch state.
        const exchange = out[EXCHANGE];
        if (!incoming.readableEnded && hasBody(incoming)) {
            if (exchange?.request.bodyUsed && !exchange.uploadReader) {
                exchange.early = true;
                out.shouldKeepAlive = false;
                out.setHeader("connection", "close");
            }
            else if (exchange)
                exchange.drainUnread();
            else
                incoming.resume();
        }
        if (stopping) {
            out.shouldKeepAlive = false;
            out.setHeader("connection", "close");
        }
    }
    function text(incoming, out, body) {
        if (out.destroyed)
            return;
        prepare(incoming, out);
        out.setHeader("content-type", TEXT_TYPE);
        out.setHeader("content-length", String(Buffer.byteLength(body)));
        out.end(incoming.method === "HEAD" ? undefined : body);
    }
    function write(incoming, out, value) {
        if (out.destroyed) {
            if (value instanceof Response)
                stopBody(value);
            return;
        }
        if (typeof value === "string")
            return text(incoming, out, value);
        const head = incoming.method === "HEAD";
        if (value instanceof Reply) {
            const headers = [];
            for (const [name, content] of value.headers) {
                if (name === "content-length" || name === "transfer-encoding" || name === "connection")
                    continue;
                if (emptyStatus(value.status) && name === "content-type")
                    continue;
                headers.push(name, content);
            }
            if (!emptyStatus(value.status))
                headers.push("content-length", String(Buffer.byteLength(value.body ?? "")));
            prepare(incoming, out);
            out.writeHead(value.status, headers);
            out.end(head ? undefined : (value.body ?? undefined));
            return;
        }
        if (!(value instanceof Response))
            throw new TypeError("invalid handler result");
        if (value.status < 200 || value.status > 599)
            throw new RangeError("invalid response status");
        if (value.bodyUsed || value.body?.locked)
            throw new TypeError("response body is consumed or locked");
        const headers = snapshot(value.headers, value.status, head, value.body !== null);
        prepare(incoming, out);
        if (head || emptyStatus(value.status) || value.body === null) {
            if (!head && !emptyStatus(value.status)) {
                for (let i = headers.length - 2; i >= 0; i -= 2)
                    if (headers[i] === "content-length")
                        headers.splice(i, 2);
                headers.push("content-length", "0");
            }
            stopBody(value);
            out.writeHead(value.status, value.statusText || undefined, headers);
            out.end();
            return;
        }
        return streamResponse(value, out, headers);
    }
    function failed(incoming, out, error, fallback = false) {
        if (out.destroyed)
            return;
        if (out.headersSent) {
            out.destroy();
            return;
        }
        if (fallback) {
            try {
                prepare(incoming, out);
                out.writeHead(500, { "content-type": TEXT_TYPE, "content-length": "21" });
                out.end(incoming.method === "HEAD" ? undefined : "Internal Server Error");
            }
            catch {
                out.destroy();
            }
            return;
        }
        try {
            result(incoming, out, error instanceof InvalidTargetError ? PATH_ERROR : executable.fail(error), true);
        }
        catch {
            result(incoming, out, ERROR_REPLY, true);
        }
    }
    function result(incoming, out, value, fallback = false) {
        try {
            if (isPromise(value)) {
                asynchronous++;
                void Promise.resolve(value)
                    .then((settled) => result(incoming, out, settled, fallback), (error) => failed(incoming, out, error, fallback))
                    .finally(() => {
                    asynchronous--;
                    checkClose();
                });
                return;
            }
            const pending = write(incoming, out, value);
            if (pending) {
                asynchronous++;
                void pending
                    .catch((error) => failed(incoming, out, error, fallback))
                    .finally(() => {
                    asynchronous--;
                    checkClose();
                });
            }
        }
        catch (error) {
            failed(incoming, out, error, fallback);
        }
    }
    function dispatch(incoming, out) {
        drain.track(incoming, out);
        try {
            if (stopping) {
                result(incoming, out, new Reply("Service Unavailable", 503));
                return;
            }
            const target = incoming.url === "*" ? "/" : (incoming.url ?? "/");
            if (!target.startsWith("/") && (!/^https?:\/\//.test(target) || target.includes("\\")))
                throw new InvalidTargetError("unsupported request target");
            const selection = executable.select(incoming.method ?? "GET", target);
            if (!executable.needsRequest(selection)) {
                const value = executable.invoke(selection);
                if (typeof value === "string")
                    text(incoming, out, value);
                else
                    result(incoming, out, value);
            }
            else {
                const exchange = new Exchange(incoming, out, requestUrl(incoming, port));
                result(incoming, out, executable.invoke(selection, exchange.request));
            }
        }
        catch (error) {
            failed(incoming, out, error);
        }
    }
    await new Promise((resolve, reject) => {
        server.once("error", reject);
        server.listen(port, options.hostname, () => {
            server.off("error", reject);
            port = server.address().port;
            resolve();
        });
    });
    return {
        port,
        close(graceMs = 5000) {
            if (!Number.isFinite(graceMs) || graceMs < 0)
                return Promise.reject(new RangeError("invalid graceMs"));
            if (closing) {
                if (graceMs === 0)
                    force();
                return closing;
            }
            stopping = true;
            closing = new Promise((resolve) => {
                resolveClose = resolve;
            });
            forceTimer = setTimeout(force, graceMs);
            drain.start();
            server.close(() => {
                serverClosed = true;
                checkClose();
            });
            checkClose();
            return closing;
        },
    };
};
