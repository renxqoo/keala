import { Reply } from "./reply.js";
export const EMPTY_PARAMS = Object.freeze(Object.create(null));
const node = () => ({ static: new Map() });
const strip = (path) => (path.length > 1 && path.endsWith("/") ? path.slice(0, -1) : path);
const decode = (segment) => (segment.includes("%") ? decodeURIComponent(segment) : segment);
const escaped = (segment) => segment.replaceAll("%", "%25").replaceAll("/", "%2F");
const normalizePath = (path) => {
    // Match the pathname a standard Request exposes, including encoded dots.
    // Ordinary paths avoid constructing a URL.
    if (path.includes("\\") || path.includes("/.") || (path.includes("%") && /%2e/i.test(path))) {
        try {
            return new URL("http://kernel.invalid" + path).pathname;
        }
        catch {
            throw new URIError("invalid request path");
        }
    }
    return path;
};
export const canonical = (path) => path.includes("%")
    ? path
        .split("/")
        .map((x) => escaped(decode(x)))
        .join("/")
    : path;
export const pathOf = (url) => {
    let start = 0;
    if (!url.startsWith("/")) {
        if (url.includes("\\")) {
            try {
                return strip(new URL(url).pathname);
            }
            catch {
                throw new URIError("invalid absolute target");
            }
        }
        const scheme = url.indexOf("://");
        if (scheme === -1)
            return url;
        const authority = scheme + 3;
        start = url.indexOf("/", authority);
        const query = url.indexOf("?", authority), hash = url.indexOf("#", authority);
        if (start === -1 || (query !== -1 && query < start) || (hash !== -1 && hash < start))
            return "/";
    }
    let end = url.length;
    const query = url.indexOf("?", start), hash = url.indexOf("#", start);
    if (query !== -1)
        end = query;
    if (hash !== -1 && hash < end)
        end = hash;
    return strip(normalizePath(url.slice(start, end) || "/"));
};
const pattern = (path) => {
    if (!path.startsWith("/") || path.includes("?") || path.includes("#"))
        throw new TypeError("route must be a path without query or fragment");
    const normalized = strip(path);
    if (normalized === "/")
        return [];
    const names = new Set();
    return normalized
        .slice(1)
        .split("/")
        .map((part, index, all) => {
        if (!part)
            throw new TypeError("empty route segment");
        if (part.startsWith(":")) {
            const name = part.slice(1);
            if (!/^[A-Za-z_$][\w$]*$/.test(name) || names.has(name))
                throw new TypeError("invalid or duplicate parameter");
            names.add(name);
            return { kind: "param", value: name };
        }
        if (part.startsWith("*")) {
            const name = part.slice(1) || "wildcard";
            if (index !== all.length - 1 || !/^[A-Za-z_$][\w$]*$/.test(name) || names.has(name))
                throw new TypeError("invalid wildcard");
            names.add(name);
            return { kind: "wild", value: name };
        }
        if (part.includes("*") || part.includes(":"))
            throw new TypeError("unsupported route syntax");
        return { kind: "static", value: decode(part) };
    });
};
const capture = (plan, values, path) => {
    const params = Object.create(null);
    for (let i = 0; i < plan.names.length; i++)
        params[plan.names[i]] = values[i];
    return { kind: "route", endpoint: plan.endpoint, params, path };
};
const walk = (current, parts, index, values, path) => {
    if (index === parts.length) {
        if (current.plan)
            return capture(current.plan, values, path);
        if (current.wild?.plan)
            return capture(current.wild.plan, [...values, ""], path);
        return null;
    }
    const part = parts[index];
    const fixed = current.static.get(part);
    if (fixed) {
        const found = walk(fixed, parts, index + 1, values, path);
        if (found)
            return found;
    }
    if (current.param && part.length) {
        values.push(part);
        const found = walk(current.param, parts, index + 1, values, path);
        values.pop();
        if (found)
            return found;
    }
    if (current.wild?.plan)
        return capture(current.wild.plan, [...values, parts.slice(index).join("/")], path);
    return null;
};
const find = (table, path) => {
    if (!table)
        return null;
    const exact = table.exact.get(path);
    if (exact)
        return exact;
    const parts = path === "/"
        ? []
        : path
            .slice(1)
            .split("/")
            .map((x) => decode(x));
    return walk(table.root, parts, 0, [], path);
};
/** Method-aware, sealed lookup. Mutable maps remain private to this closure. */
export const compileRoutes = (definitions) => {
    const tables = new Map();
    for (const definition of definitions) {
        const segments = pattern(definition.path);
        let table = tables.get(definition.method);
        if (!table) {
            table = { root: node(), exact: new Map() };
            tables.set(definition.method, table);
        }
        let current = table.root;
        const names = [];
        for (const segment of segments) {
            if (segment.kind === "static") {
                let next = current.static.get(segment.value);
                if (!next) {
                    next = node();
                    current.static.set(segment.value, next);
                }
                current = next;
            }
            else {
                names.push(segment.value);
                if (segment.kind === "param")
                    current = current.param ??= node();
                else
                    current = current.wild ??= node();
            }
        }
        if (current.plan)
            throw new TypeError(`ambiguous duplicate route: ${definition.method} ${definition.path}`);
        const endpoint = Object.freeze({ ...definition.endpoint });
        current.plan = Object.freeze({ endpoint, names: Object.freeze(names) });
        if (!names.length) {
            const path = "/" + segments.map((s) => escaped(s.value)).join("/");
            table.exact.set(path, Object.freeze({ kind: "route", endpoint, params: EMPTY_PARAMS, path }));
        }
    }
    return (rawMethod, url) => {
        const method = rawMethod.toUpperCase(), path = canonical(pathOf(url));
        if (!path.startsWith("/"))
            throw new URIError("unsupported request target");
        let found = find(tables.get(method), path);
        if (!found && method === "HEAD")
            found = find(tables.get("GET"), path);
        if (!found)
            found = find(tables.get("ALL"), path);
        if (found)
            return found;
        const allow = [];
        for (const [verb, table] of tables)
            if (verb !== "ALL" && find(table, path))
                allow.push(verb);
        if (allow.includes("GET") && !allow.includes("HEAD"))
            allow.push("HEAD");
        if (allow.length && !allow.includes("OPTIONS"))
            allow.push("OPTIONS");
        return {
            kind: "miss",
            path,
            reply: allow.length
                ? new Reply(method === "OPTIONS" ? null : "Method Not Allowed", method === "OPTIONS" ? 204 : 405, { allow: allow.toSorted().join(", ") })
                : new Reply("Not Found", 404),
        };
    };
};
