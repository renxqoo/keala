const OWNER = Symbol("kernel.connection");
/** Native HTTP/1 FIFO completion; bound responses pay no per-request listeners. */
export const nodeDrain = (server, changed) => {
    const connections = new Set();
    let draining = false;
    const unwatch = (connection) => {
        connection.watched?.off("finish", wireDone);
        connection.watched?.off("close", wireDone);
        connection.watched = undefined;
    };
    function wireDone() {
        const connection = this[OWNER];
        if (!connection)
            return;
        connection.queued.delete(this);
        if (connection.watched === this)
            unwatch(connection);
        if (draining)
            changed();
    }
    function socketClosed() {
        const connection = this[OWNER];
        if (!connection)
            return;
        unwatch(connection);
        connections.delete(connection);
        connection.queued.clear();
        this[OWNER] = undefined;
        if (draining)
            changed();
    }
    const watch = (connection) => {
        const out = connection.last;
        if (!out || out.writableFinished || out.destroyed || connection.watched === out)
            return;
        unwatch(connection);
        connection.watched = out;
        out[OWNER] = connection;
        out.once("finish", wireDone);
        out.once("close", wireDone);
    };
    server.on("connection", (socket) => {
        const connection = { socket, queued: new Set() };
        socket[OWNER] = connection;
        connections.add(connection);
        socket.once("close", socketClosed);
    });
    const closeIdle = () => {
        for (const connection of connections) {
            const last = connection.last;
            if (connection.queued.size === 0 && (!last || last.writableFinished || last.destroyed))
                connection.socket.destroy();
        }
    };
    // Node's close() calls this method synchronously. Its native idle test can
    // see writableEnded while a large end(body) still has buffered output.
    server.closeIdleConnections = closeIdle;
    return {
        track(incoming, out) {
            const connection = incoming.socket[OWNER];
            if (!connection)
                return;
            if (out.socket === incoming.socket) {
                unwatch(connection);
                connection.last = out;
                if (draining)
                    watch(connection);
            }
            else {
                connection.queued.add(out);
                out[OWNER] = connection;
                // An unassigned response can close before its predecessor finishes;
                // its close must never stand in for FIFO completion of that response.
                out.once("finish", wireDone);
                out.once("close", wireDone);
            }
        },
        start() {
            draining = true;
            for (const connection of connections)
                watch(connection);
            closeIdle();
        },
        closeIdle,
        force() {
            for (const connection of connections)
                connection.socket.destroy();
        },
        get empty() {
            return connections.size === 0;
        },
    };
};
