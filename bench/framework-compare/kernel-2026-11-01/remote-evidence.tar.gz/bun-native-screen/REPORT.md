# wr 服务器：受限资源测试

**因果诊断数据，不作为兼容产品版本排名。**
试验：Bun native route plan lowering; same handler calls and full API fallback；对照类型：none。

本次在服务器直接运行本地编译的 Keala，无 Docker。仅监听 127.0.0.1，每次一个服务进程、一个负载进程；每次采样重启服务。
整个测试 cgroup（包含服务端、客户端、协调进程）CPU 上限 1.5 核、内存 640 MiB、任务数 128；nice=15，CPUWeight=1。
这是共享服务器上的资源受限比较，吞吐和延迟包含 CPU 配额与负载端竞争的影响，不能作为服务端峰值容量。客户端低于 90% 也不排除配额限制。与本地旧结果的参数、机器不同，不能直接计算前后变化。
服务端 CPU/请求取 process.cpuUsage(user+system) 增量除以完成请求数；通过 HTTP 路径外的 IPC 采样，窗口包括负载启动屏障及结束清理。延迟分位数精度为毫秒。
健康监测：最小 MemAvailable 1356.4 MiB；cgroup 内存峰值 83.5 MiB；最后 memory.events {"low":0,"high":0,"max":0,"oom":0,"oom_kill":0,"oom_group_kill":0}。
失败：无；退出后仍存活的测试子进程：0。

| 栈 | Hello req/s | Hello CPU µs/请求 | Hello p99 ms | 12 路由 req/s 几何平均 | 12 路由 CPU µs/请求几何平均 |
| --- | ---: | ---: | ---: | ---: | ---: |
| kernel-bun-native-bun | 22784 | 32.48 | 11 | — | — |
| kernel-regexp-bun | 23864 | 31.70 | 9 | — | — |

十二路由汇总不是混合流量吞吐；CPU 汇总是各路由轮间中位数的几何平均。

# Node 26 / Bun 1.4.4：Keala、Hono、H3 实测

- 测试时间：2026-11-02 01:57:25 → 2026-11-02 01:59:16（Asia/Singapore，UTC+8）。
- 机器：Intel(R) Xeon(R) CPU E5-2680 v4 @ 2.40GHz，2 逻辑 CPU，2 GiB，linux 6.8.0-48-generic x64。
- 版本：Node 26.9.0、Bun 1.4.4；Keala 0.7.3（工作区构建）、Hono 4.13.5、H3 2.0.8；@hono/node-server 2.1.1、srvx 1.0.8。
- 负载：原生 Go 客户端 go1.27.0，50 个总连接，1 个独立客户端进程，HTTP/1.1 keep-alive，pipelining=1。
- 原生客户端复用预热连接，逐请求校验状态与完整正文；到计量截止时停止新请求，最后在途请求排空的完成数及时间均计入实际分母。不能与旧 autocannon 数据直接换算性能变化。
- 仅测试进程固定 CPU：服务端 0，负载与协调进程 1；原服务未调整。
- 每次采样先预热 1 秒，再测 3 秒；4 轮，交错并轮换顺序。表格为轮间中位数，范围为实测 min–max，不代表置信区间。
- Hello World 应用仅注册 GET /；十二路由应用注册完整路由表，每次固定请求其中一条。所有响应状态为 200、语义相同的 text/plain UTF-8，正文逐字节一致；每个压测请求也检查正文。
- 参数必须实际读取并回显；POST 无请求体；/static/* 仅回显后缀，无文件 I/O。H3 用 /static/** 实现多段通配契约。
- Keala 使用默认原生适配器（Bun 为 app.listen，Node 为 keala/node）；Hono 使用 Bun.serve / 官方 Node 适配器；H3 使用官方 serve（srvx）。均为生产模式、单进程服务，无额外中间件。
- 客户端和服务端共用本机；其他系统活动、网络栈和客户端均可能影响结果。客户端任一进程 CPU ≥90% 单核的样本会标记，不能直接解释为服务端极限。
- 主机一分钟负载（测量前后采样）范围：0.56–1.19；若接近或超过逻辑 CPU 数，需注意竞争负载与调度影响。
- 严格计时校验未通过的样本共 0 次，记录原因后重新预热、重新测量，单组合最多尝试 3 次。正文、状态、超时等失败不重试；有效的低吞吐样本不会被删除。
- Git HEAD：f14940b6cdb1912483add39e76617d51246d346e；构建产物 SHA-256：6818d89cac53c9374758c7f938b6432b76257731de528e596359d8997cfa5439。工作区包含未提交修改（清单见 results.json）。
- kernel 是独立实验 API：显式 text 能力、启动时固定路由，无旧 Context/srvx Request 扩展；不代表旧 Keala API 等价替换或生产功能齐全。原型源码 SHA-256：5600bbd0b725bce94b2623364897fb7cf83f155456c35fd55e1ed33bdf6a0b53；构建 SHA-256：cff9afdecc5f5403f784ead35733a5d9a10923d4c4ac150a7d21339bd53a19ff。

## 汇总

十二路由一列为十二条路由各自吞吐中位数的几何平均，仅用于概括；它不是混合流量测试的吞吐量。

| 框架 | 运行时 | Hello World req/s | 十二路由几何平均 req/s |
| --- | --- | ---: | ---: |
| kernel-bun-native | bun | 22,784 | — |
| kernel-regexp | bun | 23,864 | — |

本表是共享主机上的初测。轮间范围重叠时，不能据此确认稳定排名；几百分点的差距需要在空闲环境增加采样后再判断。


## 全部场景吞吐量（req/s）

| 场景 | kernel-bun-native-bun | kernel-regexp-bun |
| --- | ---: | ---: |
| Hello World | 22,784 | 23,864 |
| `GET /user/lookup/username/:username` | 20,180 | 21,249 |
| `GET /static/*` | 20,553 | 20,676 |

## 延迟、波动与样本数

p50 / p99 为每轮请求延迟分位数的中位数，单位 ms；分位数精度为毫秒，0 不表示没有延迟。† 表示检测到客户端 CPU 接近单核上限。

| 场景 | 栈 | 样本数 | req/s 范围 | p50 ms | p99 ms | 客户端受限 |
| --- | --- | ---: | ---: | ---: | ---: | --- |
| hello | kernel-bun-native-bun | 4 | 21,203–23,753 | 1.00 | 11.00 | 否 |
| hello | kernel-regexp-bun | 4 | 22,230–24,811 | 1.00 | 9.00 | 否 |
| route-4 | kernel-bun-native-bun | 4 | 19,410–20,579 | 1.00 | 10.00 | 否 |
| route-4 | kernel-regexp-bun | 4 | 19,927–22,108 | 1.00 | 9.50 | 否 |
| route-12 | kernel-bun-native-bun | 4 | 20,120–21,973 | 1.00 | 11.00 | 否 |
| route-12 | kernel-regexp-bun | 4 | 20,483–22,170 | 1.00 | 10.00 | 否 |

完成 24 次测量、1,553,426 个测量请求；成功样本的错误、超时、非 2xx、正文不匹配均为 0。预热请求不计入此总数。

原始每轮结果、客户端 CPU、版本、源码标识和执行顺序保存在同目录 results.json。


## 每场景服务端 CPU 与配额限制

| 场景 | 栈 | CPU µs/请求中位数 | CPU µs/请求范围 | 配额发生节流的样本数 |
| --- | --- | ---: | ---: | ---: |
| hello | kernel-bun-native-bun | 32.48 | 31.39–35.34 | 4/4 |
| hello | kernel-regexp-bun | 31.70 | 30.32–33.16 | 4/4 |
| route-4 | kernel-bun-native-bun | 38.40 | 37.80–38.93 | 4/4 |
| route-4 | kernel-regexp-bun | 36.30 | 34.68–38.89 | 4/4 |
| route-12 | kernel-bun-native-bun | 37.08 | 35.14–38.36 | 4/4 |
| route-12 | kernel-regexp-bun | 37.12 | 35.14–37.92 | 4/4 |
